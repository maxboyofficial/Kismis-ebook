package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.OfflineBookStorage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kismis", appName)
  }

  @Test
  fun `offline book storage saves reads and deletes compressed text`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val storage = OfflineBookStorage(context)
    storage.clearAll()

    val bookId = "gutendex_1342"
    val content = "CHAPTER I\n\nIt is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife."
    val savedBytes = storage.saveBookText(bookId, content)

    assertTrue(savedBytes > 0L)
    assertTrue(storage.hasBookText(bookId))
    assertEquals(content, storage.readBookText(bookId))
    assertTrue(storage.getTotalStorageBytes() >= savedBytes)

    storage.deleteBookText(bookId)
    assertFalse(storage.hasBookText(bookId))
    assertNull(storage.readBookText(bookId))
  }
}
