package com.example

import com.example.data.local.BundledBooksData
import com.example.data.local.EbookEntity
import com.example.data.local.OfflineBookStorage
import com.example.data.local.PerformanceMode
import com.example.data.remote.GutendexClient
import com.example.data.remote.GutendexResponse
import com.example.data.repository.BookPaginationEngine
import com.example.data.repository.OfflineSyncPhase
import com.example.data.repository.OfflineSyncState
import com.example.tts.TtsVoicePreset
import com.example.ui.components.formatCompactCount
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun bundledBooks_arePopulatedAndPaginateCleanly() {
        val books = BundledBooksData.getInitialBooks()
        assertEquals(1008, books.size)
        assertEquals(1008, books.map { it.id }.distinct().size)
        assertEquals(1008, books.map { it.title }.distinct().size)

        val expectedCategories = listOf(
            "Comedy", "Mystery", "Horror", "Romance", "Adventure",
            "Sci-Fi", "Philosophy", "Drama", "Entertaining", "Fiction"
        )
        expectedCategories.forEach { category ->
            val count = books.count { it.category == category }
            assertTrue("Expected >= 100 books in $category, found $count", count >= 100)
        }

        books.forEach { book ->
            assertTrue("Expected isDownloaded=true for ${book.id}", book.isDownloaded)
            assertTrue("Expected isBundled=true for ${book.id}", book.isBundled)
            assertTrue("Expected non-empty content for ${book.id}", book.contentText.isNotBlank())
            val paginated = BookPaginationEngine.paginate(book.contentText, 18f)
            assertTrue(paginated.chapters.isNotEmpty())
            assertTrue(paginated.pages.isNotEmpty())
            assertEquals(0, paginated.pages.first().pageIndex)
        }
    }

    @Test
    fun ttsPresetsAndPerformanceModes_haveValidDefaults() {
        assertEquals(4, TtsVoicePreset.entries.size)
        assertTrue(TtsVoicePreset.STORYTELLER.rate in 0.7f..1.5f)
        assertTrue(TtsVoicePreset.CALM_NIGHT.pitch < TtsVoicePreset.CRISP_FAST.pitch)
        assertEquals(listOf(PerformanceMode.AUTO, PerformanceMode.LITE, PerformanceMode.FULL), PerformanceMode.entries)
    }

    @Test
    fun offlineSyncHelpers_formatStorageAndExtractIdsCorrectly() {
        assertEquals("0 MB", OfflineBookStorage.formatBytes(0L))
        assertEquals("512 KB", OfflineBookStorage.formatBytes(512 * 1024L))
        assertEquals("2.5 MB", OfflineBookStorage.formatBytes((2.5 * 1024 * 1024).toLong()))
        assertEquals("140 MB", OfflineBookStorage.formatBytes(140L * 1024L * 1024L))

        assertEquals(1342, GutendexClient.extractGutenbergId("gutendex_1342"))
        assertNull(GutendexClient.extractGutenbergId("kismis_bloomsbury_rabbit"))

        val defaultSync = OfflineSyncState()
        assertEquals(OfflineSyncPhase.IDLE, defaultSync.phase)
        assertEquals(1050, defaultSync.targetOfflineCount)
    }

    @Test
    fun customTags_parseAndDeduplicateProperly() {
        val book = EbookEntity(
            id = "test_1",
            title = "Test",
            author = "Author",
            category = "Comedy",
            description = "Desc",
            customTags = "Cozy, Weekend , Cozy, , Late Night",
            shelves = "Romance, British Literature, Romance"
        )
        assertEquals(listOf("Cozy", "Weekend", "Late Night"), book.tagList())
        assertEquals(listOf("Romance", "British Literature"), book.shelfList())
    }

    @Test
    fun gutendexResponse_parsesSummariesEditorsAndCounts() {
        val sampleJson = """
            {
              "count": 79827,
              "next": "https://gutendex.com/books/?page=2",
              "previous": null,
              "results": [
                {
                  "id": 1342,
                  "title": "Pride and Prejudice",
                  "authors": [{"name": "Austen, Jane", "birth_year": 1775, "death_year": 1817}],
                  "summaries": ["Follows Elizabeth Bennet and Mr. Darcy. (This is an automatically generated summary.)"],
                  "editors": [],
                  "translators": [],
                  "subjects": ["Love stories"],
                  "bookshelves": ["Category: Romance"],
                  "languages": ["en"],
                  "copyright": false,
                  "media_type": "Text",
                  "formats": {"text/plain; charset=utf-8": "https://www.gutenberg.org/ebooks/1342.txt.utf-8"},
                  "download_count": 208430
                }
              ]
            }
        """.trimIndent()

        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val parsed = moshi.adapter(GutendexResponse::class.java).fromJson(sampleJson)
        assertNotNull(parsed)
        assertEquals(79827, parsed!!.count)
        assertEquals("https://gutendex.com/books/?page=2", parsed.next)
        val first = parsed.results.first()
        assertEquals(1342, first.id)
        assertEquals(1775, first.authors.first().birthYear)
        assertEquals("en", first.languages.first())
        assertTrue(first.summaries.first().contains("Elizabeth Bennet"))
        assertEquals("208.4K", formatCompactCount(first.downloadCount))
    }
}

