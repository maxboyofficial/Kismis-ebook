package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.io.IOException
import java.util.concurrent.TimeUnit

interface GutendexApi {
    @GET("books")
    suspend fun getBooks(
        @Query("search") search: String? = null,
        @Query("topic") topic: String? = null,
        @Query("languages") languages: String? = "en",
        @Query("sort") sort: String? = "popular",
        @Query("page") page: Int = 1
    ): GutendexResponse
}

object GutendexClient {
    private const val BASE_URL = "https://gutendex.com/"

    val okHttpClient: OkHttpClient by lazy {
        val dispatcher = Dispatcher().apply {
            maxRequests = 24
            maxRequestsPerHost = 10
        }
        OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectionPool(ConnectionPool(12, 2, TimeUnit.MINUTES))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    val api: GutendexApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GutendexApi::class.java)
    }

    suspend fun getBooksWithRetry(
        search: String? = null,
        topic: String? = null,
        languages: String? = "en",
        sort: String? = "popular",
        page: Int = 1,
        maxAttempts: Int = 3
    ): GutendexResponse {
        var lastError: Throwable? = null
        repeat(maxAttempts) { attempt ->
            try {
                return api.getBooks(
                    search = search,
                    topic = topic,
                    languages = languages,
                    sort = sort,
                    page = page
                )
            } catch (t: Throwable) {
                lastError = t
                val retryable = t is IOException || (t is HttpException && (t.code() == 429 || t.code() >= 500))
                if (!retryable || attempt == maxAttempts - 1) throw t
                delay(350L * (attempt + 1))
            }
        }
        throw lastError ?: IllegalStateException("Catalog request failed")
    }

    suspend fun downloadPlainText(url: String): String = withContext(Dispatchers.IO) {
        downloadPlainTextSingle(url)
    }

    suspend fun downloadPlainTextWithFallbacks(
        primaryUrl: String,
        gutenbergId: Int? = null
    ): String = withContext(Dispatchers.IO) {
        val candidateUrls = buildList {
            add(primaryUrl)
            if (gutenbergId != null && gutenbergId > 0) {
                add("https://www.gutenberg.org/cache/epub/$gutenbergId/pg$gutenbergId.txt")
                add("https://www.gutenberg.org/ebooks/$gutenbergId.txt.utf-8")
            }
        }.distinct()

        var lastError: Throwable? = null
        for (url in candidateUrls) {
            repeat(2) { attempt ->
                try {
                    return@withContext downloadPlainTextSingle(url)
                } catch (t: Throwable) {
                    lastError = t
                    if (attempt == 0) {
                        delay(250L)
                    }
                }
            }
        }
        throw lastError ?: IllegalStateException("Could not download plain text from any mirror")
    }

    private fun downloadPlainTextSingle(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "KismisReader/1.0 (Android)")
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("HTTP ${response.code} downloading book text")
            }
            val rawText = response.body?.string()
                ?: throw IllegalStateException("Empty book response")
            val cleaned = cleanGutenbergText(rawText)
            if (cleaned.length < 120) {
                throw IllegalStateException("Downloaded book text is unexpectedly short")
            }
            return cleaned
        }
    }

    fun extractGutenbergId(bookId: String): Int? {
        return bookId.removePrefix("gutendex_").toIntOrNull()
    }

    private fun cleanGutenbergText(raw: String): String {
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
        val startMarker = Regex("""\*\*\*\s*START OF (THE|THIS) PROJECT GUTENBERG EBOOK.*?\*\*\*""", RegexOption.IGNORE_CASE)
        val endMarker = Regex("""\*\*\*\s*END OF (THE|THIS) PROJECT GUTENBERG EBOOK.*?\*\*\*""", RegexOption.IGNORE_CASE)

        val startIndex = startMarker.find(normalized)?.range?.last?.plus(1) ?: 0
        val endIndex = endMarker.find(normalized, startIndex)?.range?.first ?: normalized.length

        val body = normalized.substring(startIndex, endIndex).trim()
        // Cap ultra-massive multi-megabyte volumes smoothly while keeping full readable novels
        return if (body.length > 450_000) body.take(450_000) else body
    }
}

