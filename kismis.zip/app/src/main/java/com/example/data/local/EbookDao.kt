package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface EbookDao {

    /**
     * Metadata-only projections for catalog and library feeds.
     * Avoids pulling up to 450KB `contentText` blobs per book into memory while scrolling 1,000+ items.
     */
    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        ORDER BY isBundled DESC, isDownloaded DESC, lastReadAt DESC, downloadCount DESC, title ASC
        """
    )
    fun observeAllBooks(): Flow<List<EbookEntity>>

    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        WHERE lastReadAt > 0
        ORDER BY lastReadAt DESC
        LIMIT 1
        """
    )
    fun observeContinueReading(): Flow<EbookEntity?>

    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        WHERE isDownloaded = 1
        ORDER BY lastReadAt DESC, downloadCount DESC, title ASC
        """
    )
    fun observeDownloadedBooks(): Flow<List<EbookEntity>>

    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        WHERE isBookmarked = 1
        ORDER BY lastReadAt DESC, title ASC
        """
    )
    fun observeBookmarkedBooks(): Flow<List<EbookEntity>>

    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        WHERE id IN (:ids)
        """
    )
    suspend fun getMetadataByIds(ids: List<String>): List<EbookEntity>

    @Query(
        """
        SELECT id, title, author, category, description, coverResName, coverUrl, textUrl,
               '' AS contentText, isDownloaded, isBundled, isBookmarked, currentPage,
               totalPages, progressPercent, lastReadAt, accentColorHex, customTags,
               downloadCount, language, authorLifespan, shelves
        FROM ebooks
        WHERE isDownloaded = 0 AND textUrl IS NOT NULL AND textUrl != ''
        ORDER BY downloadCount DESC, title ASC
        LIMIT :limit
        """
    )
    suspend fun getUndownloadedSyncCandidates(limit: Int): List<EbookEntity>

    @Query("SELECT * FROM ebooks WHERE id = :bookId LIMIT 1")
    fun observeBookById(bookId: String): Flow<EbookEntity?>

    @Query("SELECT * FROM ebooks WHERE id = :bookId LIMIT 1")
    suspend fun getBookById(bookId: String): EbookEntity?

    @Query("SELECT COUNT(*) FROM ebooks")
    suspend fun getBookCount(): Int

    @Query("SELECT COUNT(*) FROM ebooks WHERE isBundled = 1")
    suspend fun getBundledBookCount(): Int

    @Query("SELECT COUNT(*) FROM ebooks WHERE isDownloaded = 1")
    suspend fun getDownloadedBookCount(): Int

    @Query("SELECT COUNT(*) FROM ebooks WHERE isDownloaded = 1")
    fun observeDownloadedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBook(book: EbookEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(books: List<EbookEntity>)

    @Query("UPDATE ebooks SET isDownloaded = 1, totalPages = :totalPages WHERE id = :bookId")
    suspend fun markBookDownloaded(bookId: String, totalPages: Int)

    @Transaction
    suspend fun markBooksDownloadedBatch(items: List<Pair<String, Int>>) {
        for ((bookId, totalPages) in items) {
            markBookDownloaded(bookId, totalPages)
        }
    }

    @Query(
        """
        UPDATE ebooks
        SET currentPage = :currentPage,
            totalPages = :totalPages,
            progressPercent = :progressPercent,
            lastReadAt = :lastReadAt
        WHERE id = :bookId
        """
    )
    suspend fun updateReadingProgress(
        bookId: String,
        currentPage: Int,
        totalPages: Int,
        progressPercent: Int,
        lastReadAt: Long
    )

    @Query("UPDATE ebooks SET isBookmarked = :isBookmarked WHERE id = :bookId")
    suspend fun setBookmarked(bookId: String, isBookmarked: Boolean)

    @Query("UPDATE ebooks SET customTags = :customTags WHERE id = :bookId")
    suspend fun updateCustomTags(bookId: String, customTags: String)

    @Query("UPDATE ebooks SET category = :category WHERE id = :bookId")
    suspend fun updateCategory(bookId: String, category: String)

    @Query("DELETE FROM ebooks WHERE id = :bookId AND isBundled = 0")
    suspend fun deleteNonBundledBook(bookId: String)

    @Query("DELETE FROM ebooks WHERE isBundled = 0 AND isDownloaded = 0")
    suspend fun deleteUndownloadedStubs()

    @Query("DELETE FROM ebooks WHERE isBundled = 0 AND isDownloaded = 0 AND isBookmarked = 0 AND lastReadAt = 0")
    suspend fun clearUnusedCache()
}

