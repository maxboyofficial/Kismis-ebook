package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ebooks")
data class EbookEntity(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val category: String,
    val description: String,
    val coverResName: String? = null,
    val coverUrl: String? = null,
    val textUrl: String? = null,
    val contentText: String = "",
    val isDownloaded: Boolean = false,
    val isBundled: Boolean = false,
    val isBookmarked: Boolean = false,
    val currentPage: Int = 0,
    val totalPages: Int = 1,
    val progressPercent: Int = 0,
    val lastReadAt: Long = 0L,
    val accentColorHex: Long = 0xFF166EF4L,
    val customTags: String = "",
    val downloadCount: Int = 0,
    val language: String = "en",
    val authorLifespan: String = "",
    val shelves: String = ""
) {
    fun tagList(): List<String> = customTags
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()

    fun shelfList(): List<String> = shelves
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
}
