package com.example.data.local

object BundledBooksData {

    fun getInitialBooks(): List<EbookEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            EbookEntity(
                id = "kismis_bloomsbury_rabbit",
                title = "The Pocket-Watch Rabbit of Bloomsbury",
                author = "Clara Finch",
                category = "Comedy",
                description = "A delightfully absurd comedy about a punctual rabbit who refuses to let London's fog delay afternoon tea.",
                coverResName = "img_cover_wonderland",
                contentText = wonderlandOriginalText,
                isDownloaded = true,
                isBundled = true,
                isBookmarked = true,
                currentPage = 6,
                totalPages = 12,
                progressPercent = 53,
                lastReadAt = now,
                accentColorHex = 0xFF166EF4L,
                customTags = "Weekend Read,Tea Time",
                downloadCount = 150_000,
                language = "EN"
            ),
            EbookEntity(
                id = "kismis_earnest_tea",
                title = "The Art of Earnest Tea",
                author = "Julian Sterling",
                category = "Entertaining",
                description = "Witty drawing-room banter, mistaken identities, and cucumber sandwiches in late-Victorian society.",
                coverResName = "img_cover_earnest",
                contentText = earnestOriginalText,
                isDownloaded = true,
                isBundled = true,
                isBookmarked = false,
                currentPage = 0,
                totalPages = 10,
                progressPercent = 0,
                lastReadAt = 0L,
                accentColorHex = 0xFF1E7E5CL,
                customTags = "Witty,Short Read",
                downloadCount = 140_000,
                language = "EN"
            ),
            EbookEntity(
                id = "kismis_baker_square",
                title = "Gaslight & Alibis at Baker Square",
                author = "Arthur Vale",
                category = "Mystery",
                description = "When a priceless crimson manuscript vanishes during a thunderstorm, every guest holds half a clue.",
                coverResName = "img_cover_sherlock",
                contentText = sherlockOriginalText,
                isDownloaded = true,
                isBundled = true,
                isBookmarked = true,
                currentPage = 0,
                totalPages = 11,
                progressPercent = 0,
                lastReadAt = 0L,
                accentColorHex = 0xFF1E3A8AL,
                customTags = "Late Night,Detective",
                downloadCount = 130_000,
                language = "EN"
            ),
            EbookEntity(
                id = "kismis_chronosphere",
                title = "Chronosphere 1904",
                author = "H. V. Mercer",
                category = "Sci-Fi",
                description = "An eccentric inventor calibrates a brass-and-quartz pendulum that leaps straight into tomorrow's skyline.",
                coverResName = "img_cover_timemachine",
                contentText = timeMachineOriginalText,
                isDownloaded = true,
                isBundled = true,
                isBookmarked = false,
                currentPage = 0,
                totalPages = 11,
                progressPercent = 0,
                lastReadAt = 0L,
                accentColorHex = 0xFF6D28D9L,
                customTags = "Weekend Read,Future",
                downloadCount = 120_000,
                language = "EN"
            )
        ) + BundledClassicsExtra.getAdditionalBooks() + LocalThousandLibrary.getThousandBooks()
    }

    private val wonderlandOriginalText = """
CHAPTER I: THE PUNCTUALITY CRISIS

Barnaby was not an ordinary rabbit, mostly because he owned three waistcoats, a brass barometer, and an encyclopedic knowledge of London omnibus timetables. Every Tuesday at precisely four o'clock, he took tea at the Conservatory of Curious Botany. Unfortunately, London fog had a habit of ignoring timetables altogether.

On this particular Tuesday, Barnaby stood beneath a crimson umbrella outside Russell Square, tapping one velvet-slippered foot against the damp cobblestones. His silver pocket watch ticked with smug precision: 3:52 PM.

"Eight minutes," Barnaby muttered to a passing pigeon. "Eight minutes to cross two parks, dodge three newsboys, and acquire lemon curd tarts. Surely physics can bend just a trifle?"

The pigeon blinked once, unimpressed, and hopped into a puddle.

Barnaby tucked his watch away and noticed something extraordinary beside the iron park gate: a miniature brass keyhole hovering half an inch above the garden hedge, glowing faintly like a warm ember.

"Well," Barnaby said, adjusting his spectacles, "the gate is locked, and manners dictate one ought to use a keyhole if a keyhole volunteers itself."

CHAPTER II: THE GREENHOUSE OF UNASKED QUESTIONS

On the far side of the keyhole lay a botanical conservatory whose glass roof seemed to hold an entire twilight sky. Giant ferns leaned politely out of the pathway as Barnaby marched past, while potted marigolds whispered gossip about yesterday's drizzle.

At the center of the marble hall sat a round cedar table draped in linen. Three chairs were already occupied: by a sleepy tortoise wearing reading glasses, a theatrical cat balancing a sugar spoon on its nose, and a teapot that hummed opera whenever the water neared a boil.

"You are thirty seconds early," the tortoise observed without looking up from his crossword. "That is practically rude."

"I took a shortcut through an unscheduled keyhole," Barnaby replied briskly, claiming the fourth chair. "Has anyone seen the lemon curd tarts?"

The cat flicked its tail toward a tiered porcelain stand. "They arrived five minutes ago, though the teapot insists they are actually miniature hats."

"Preposterous," Barnaby declared, lifting a tart. "Hats rarely crumble with such dignity."

CHAPTER III: THE DEBATE OF THE LOST MINUTE

Halfway through the second pot of Darjeeling, the conservatory clock struck four—and then, after a thoughtful pause, struck four again just to be sure.

"You see!" cried the teapot in a triumphant soprano. "Two four o'clocks! Now nobody can possibly be late!"

The tortoise frowned at his crossword. "If there are two four o'clocks, then five-letter word for 'inevitable delay' becomes six letters: 'repeat.'"

Barnaby consulted his silver watch. True enough, the minute hand had paused politely at twelve, waiting for the scones to cool.

"A civilized arrangement," Barnaby admitted, spreading clotted cream with geometric care. "If London adopted this system, commuter trains would apologize before arriving."

CHAPTER IV: RETURN BY LANTERN LIGHT

When the tarts were reduced to celebratory crumbs and the opera-singing teapot had settled into a soft lullaby, Barnaby rose and bowed to his hosts.

"Same keyhole next Tuesday?" asked the cat, balancing two teaspoons now.

"Only if the fog cooperates," Barnaby smiled.

He stepped back through the warm crimson glow and found himself once more in Russell Square, just as the streetlamps flickered to life along the glistening pavement. His watch resumed its steady tick—4:01 PM—and for the first time in living memory, Barnaby decided being one minute late was rather splendid.
""".trimIndent()

    private val earnestOriginalText = """
CHAPTER I: THE ART OF CONVENIENT COUSINS

In the sunlit drawing room of Belgrave Terrace, Algernon Moncrieff arranged four cucumber sandwiches on a silver platter with the solemn concentration of a general planning an ambush.

"My dear fellow," Algernon said as his friend Jack strode through the tall French windows, "I hope you have not come to be serious before luncheon. Seriousness ruins the digestion."

Jack set down his cane and sighed dramatically. "I am in love, Algernon, which is considerably worse for the appetite than seriousness."

"Good heavens. With someone sensible, I trust? Sensible people are so delightfully predictable."

"With Gwendolen," Jack announced. "Who insists she could never love a man whose name did not carry a certain musical ring. Which is awkward, since in the country I am known as Jack, and only in town do I go by Julian."

Algernon nodded approvingly. "An imaginary town alias! How refreshing. I myself keep an invalid friend in Shropshire named Barnaby who falls conveniently ill whenever Aunt Agatha proposes a tedious dinner."

CHAPTER II: THE BATTLE FOR THE LAST MUFFIN

By half past four, the garden terrace had become a battlefield of polite etiquette. Gwendolen and her spirited friend Cecily sat beneath a striped parasol, comparing notebooks with forensic intensity.

"It appears," Cecily murmured, tapping her fountain pen against her chin, "that both our gentlemen possess remarkably flexible biographies."

"Indeed," Gwendolen replied, lifting her teacup two millimeters higher than strictly necessary. "Yet one must admire the sheer dedication required to sustain two wardrobes for a single weekend."

When Jack and Algernon arrived from the conservatory carrying plates of buttered muffins, neither spoke for a full minute. Instead, both gentlemen reached for the exact same muffin with theatrical grace.

"When one is in trouble," Algernon observed cheerfully, "eating muffins is the only dignified course of action."

"You eat them with far too much composure," Jack snapped, though his eyes betrayed amusement. "One would think you were innocent of any invention."

CHAPTER III: AN UNEXPECTED RECONCILIATION

Truth, as it often does in comedies, arrived dressed in a crisp linen suit and carrying an old leather hatbox. Lady Bracknell swept onto the terrace, inspected the cucumber sandwiches through her lorgnette, and delivered her verdict in three sentences.

"A name," she pronounced, "is merely an ornament unless accompanied by good humor and punctual carriage horses. You boys have demonstrated neither, yet your banter is passable."

With a burst of laughter that broke the afternoon's last pretense, Jack confessed his country name, Algernon retired his fictional invalid in Shropshire, and the silver teapot was refilled for a triumphant fourth round.

"To honesty," Jack toasted with his teacup.

"In moderation," Algernon added smoothly. "Total honesty would put half of London's playwrights out of work."
""".trimIndent()

    private val sherlockOriginalText = """
CHAPTER I: THE MANUSCRIPT IN ROOM FOUR

Rain lashed the tall arched windows of Baker Square as Inspector Vance paced beside the mahogany hearth. On the desk lay an empty velvet book-case, its brass clasp snapped neatly in half.

"Four guests inside the library," Vance said, shaking droplets from his coat. "None left the house. Yet the crimson folio vanished between ten and ten-fifteen."

Arthur Vale knelt beside the carpet, holding a pocket magnifying glass an inch above the Persian weave. He did not glance at the broken clasp. Instead, he studied three faint crescent marks pressed into the polished oak floorboards.

"Look closer, Vance," Vale murmured. "A thief who breaks a brass clasp leaves splinters inward. This clasp was opened with its own key, and then snapped afterward to suggest violence."

"Then why break it at all?"

"Because," Vale said, rising briskly, "someone wished us to look for a burglar outside rather than a collector seated beside the fire."

CHAPTER II: FOUR CUPS OF COLD ESPRESSO

Downstairs in the conservatory parlor, the four houseguests waited with varying degrees of composure. Professor Linwood polished his spectacles; Lady Ashworth sketched nervously on a napkin; young Mr. Thorne checked the corridor clock; and Chef Moreau stood silently near the sideboard.

Vale asked only one question: "Who among you poured a fresh cup after the thunderclap at ten?"

"I never touch coffee after dusk," Lady Ashworth replied instantly.

"I was shelving encyclopedias," Professor Linwood said.

"Wait," Vale smiled softly, lifting the porcelain saucer beside the Professor's elbow. Beneath the rim clung a dried ring of dark espresso and a speck of crimson sealing wax. "You dusted the encyclopedias, Professor, yet your cuff carries wax from the folio's ribbon—and your cup was still warm when the rain began."

CHAPTER III: THE HIDDEN COMPARTMENT

Professor Linwood sank back into the armchair, his shoulders dropping with quiet relief rather than anger.

"I did not steal it to sell," the Professor admitted softly. "The folio contains my late brother's astronomical charts. I only wanted one night to copy his final margin notes before the auction tomorrow."

Vale closed his notebook and returned the magnifying glass to his waistcoat pocket. "A motive of memory, not malice. Yet truth still belongs in daylight."

Together they retrieved the crimson manuscript from behind the grandfather clock in the hall, untouched and dry. Outside, the London storm finally broke, leaving amber streetlamps mirrored across Baker Square.
""".trimIndent()

    private val timeMachineOriginalText = """
CHAPTER I: CALIBRATING THE PENDULUM

Every inventor keeps a drawer of failures, and H. V. Mercer's was overflowing with melted copper coils and stubborn brass gears. Yet tonight, perched upon an oak workbench in his rooftop observatory, the Chronosphere hummed like a tuning fork held against starlight.

Three concentric rings of brushed bronze orbited a teardrop crystal no larger than an apple. Inside the crystal pulsed a pale indigo filament.

"If a clock measures the passage of seconds," Mercer explained to his skeptical assistant, Nora, "then an inverted clock simply asks why seconds must travel single-file."

Nora folded her arms, eyeing the humming rings. "And if the rings disagree with gravity?"

"Then we hold onto our teacups," Mercer grinned, turning the ivory dial one notch clockwise.

CHAPTER II: THE SKYLINE OF TOMORROW

There was no explosion—only the sudden sensation of wind rushing backward through a quiet room. The brick chimneys outside the observatory blurred into silver ribbons, then dissolved into soaring glass spires wrapped in suspended rooftop gardens.

When the bronze rings slowed to a gentle chime, sunlight poured through a dome that had not existed a moment before. Electric gliders drifted silently between ivory towers, and the Thames sparkled clear as mountain glass below.

"Mercer," Nora whispered, peering out over the balcony rail. "The calendar on that transit beacon says 2104."

"Remarkable," Mercer breathed, sketching the spiral bridges furiously in his field journal. "They kept the riverbend—and they finally fixed the fog."

CHAPTER III: A MESSAGE IN QUARTZ

Down in the plaza garden, a curator in a woven silver jacket approached without surprise, holding a small brass pocket watch that looked eerily familiar.

"We wondered when you'd arrive," the curator smiled. "Your observatory logs were preserved in the City Archive a century ago. You promised to bring back tea if our fountains worked."

Mercer laughed aloud, reached into his coat pocket, and produced a slightly rattled tin of Earl Grey.

An hour later, after touring floating libraries whose books projected gentle holographic diagrams into mid-air, Mercer and Nora stepped back inside the bronze rings. One reverse turn of the ivory dial—and the quiet tick of 1904 returned, leaving only a glowing indigo spark and a notebook full of tomorrow.
""".trimIndent()
}
