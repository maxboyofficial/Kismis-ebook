package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [EbookEntity::class],
    version = 3,
    exportSchema = false
)
abstract class KismisDatabase : RoomDatabase() {
    abstract fun ebookDao(): EbookDao

    companion object {
        @Volatile
        private var INSTANCE: KismisDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ebooks ADD COLUMN customTags TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ebooks ADD COLUMN downloadCount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE ebooks ADD COLUMN language TEXT NOT NULL DEFAULT 'en'")
                db.execSQL("ALTER TABLE ebooks ADD COLUMN authorLifespan TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ebooks ADD COLUMN shelves TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getInstance(context: Context): KismisDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KismisDatabase::class.java,
                    "kismis_ebooks.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
