package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GutendexResponse(
    val count: Int = 0,
    val next: String? = null,
    val previous: String? = null,
    val results: List<GutendexBookDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GutendexBookDto(
    val id: Int,
    val title: String,
    val authors: List<GutendexAuthorDto> = emptyList(),
    val summaries: List<String> = emptyList(),
    val editors: List<GutendexAuthorDto> = emptyList(),
    val translators: List<GutendexAuthorDto> = emptyList(),
    val subjects: List<String> = emptyList(),
    val bookshelves: List<String> = emptyList(),
    val languages: List<String> = emptyList(),
    val copyright: Boolean? = null,
    @Json(name = "media_type") val mediaType: String = "Text",
    val formats: Map<String, String> = emptyMap(),
    @Json(name = "download_count") val downloadCount: Int = 0
)

@JsonClass(generateAdapter = true)
data class GutendexAuthorDto(
    val name: String,
    @Json(name = "birth_year") val birthYear: Int? = null,
    @Json(name = "death_year") val deathYear: Int? = null
)
