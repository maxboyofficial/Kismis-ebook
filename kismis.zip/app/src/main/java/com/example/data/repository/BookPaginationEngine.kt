package com.example.data.repository

data class BookChapter(
    val index: Int,
    val title: String,
    val startPageIndex: Int
)

data class BookPage(
    val pageIndex: Int,
    val chapterTitle: String,
    val text: String,
    val isChapterStart: Boolean
)

data class PaginatedBook(
    val chapters: List<BookChapter>,
    val pages: List<BookPage>
)

object BookPaginationEngine {

    private val chapterHeaderRegex = Regex(
        pattern = """^(CHAPTER\s+[IVXLCDM0-9]+.*|ACT\s+[IVXLCDM0-9]+.*|BOOK\s+[IVXLCDM0-9]+.*|PART\s+[IVXLCDM0-9]+.*)$""",
        options = setOf(RegexOption.IGNORE_CASE)
    )

    fun paginate(rawContent: String, fontSizeSp: Float): PaginatedBook {
        if (rawContent.isBlank()) {
            return PaginatedBook(
                chapters = listOf(BookChapter(0, "Chapter I", 0)),
                pages = listOf(BookPage(0, "Chapter I", "No readable text found.", true))
            )
        }

        // Adjust characters per page smoothly based on chosen font size
        val targetCharsPerPage = when {
            fontSizeSp >= 24f -> 720
            fontSizeSp >= 21f -> 900
            fontSizeSp >= 18f -> 1150
            fontSizeSp >= 15f -> 1400
            else -> 1650
        }

        val lines = rawContent.replace("\r\n", "\n").split("\n")
        val sections = mutableListOf<Pair<String, MutableList<String>>>()
        var currentTitle = "Opening"
        var currentParagraphs = mutableListOf<String>()
        val paragraphBuilder = StringBuilder()

        fun flushParagraph() {
            val trimmed = paragraphBuilder.toString().trim()
            if (trimmed.isNotEmpty()) {
                currentParagraphs.add(trimmed)
            }
            paragraphBuilder.clear()
        }

        for (line in lines) {
            val trimmedLine = line.trim()
            if (trimmedLine.isEmpty()) {
                flushParagraph()
            } else if (chapterHeaderRegex.matches(trimmedLine) && trimmedLine.length < 90) {
                flushParagraph()
                if (currentParagraphs.isNotEmpty()) {
                    sections.add(currentTitle to currentParagraphs)
                }
                currentTitle = trimmedLine
                currentParagraphs = mutableListOf()
            } else {
                if (paragraphBuilder.isNotEmpty()) {
                    paragraphBuilder.append(' ')
                }
                paragraphBuilder.append(trimmedLine)
            }
        }
        flushParagraph()
        if (currentParagraphs.isNotEmpty()) {
            sections.add(currentTitle to currentParagraphs)
        }

        if (sections.isEmpty()) {
            sections.add("Chapter I" to mutableListOf(rawContent.trim()))
        }

        val chapters = mutableListOf<BookChapter>()
        val pages = mutableListOf<BookPage>()

        sections.forEachIndexed { chapterIdx, (title, paragraphs) ->
            val chapterStartPage = pages.size
            chapters.add(BookChapter(chapterIdx, title, chapterStartPage))

            val pageBuffer = StringBuilder()
            var isFirstPageOfChapter = true

            fun commitPage() {
                val content = pageBuffer.toString().trim()
                if (content.isNotEmpty()) {
                    pages.add(
                        BookPage(
                            pageIndex = pages.size,
                            chapterTitle = title,
                            text = content,
                            isChapterStart = isFirstPageOfChapter
                        )
                    )
                    isFirstPageOfChapter = false
                }
                pageBuffer.clear()
            }

            for (para in paragraphs) {
                if (para.length > targetCharsPerPage) {
                    // Split very long paragraph cleanly on sentence/word boundaries
                    if (pageBuffer.isNotEmpty()) commitPage()
                    var start = 0
                    while (start < para.length) {
                        val end = (start + targetCharsPerPage).coerceAtMost(para.length)
                        val cut = if (end < para.length) {
                            val lastSpace = para.lastIndexOf(' ', end)
                            if (lastSpace > start + 200) lastSpace else end
                        } else end
                        pageBuffer.append(para.substring(start, cut).trim())
                        commitPage()
                        start = cut + 1
                    }
                } else {
                    if (pageBuffer.length + para.length + 2 > targetCharsPerPage && pageBuffer.isNotEmpty()) {
                        commitPage()
                    }
                    if (pageBuffer.isNotEmpty()) {
                        pageBuffer.append("\n\n")
                    }
                    pageBuffer.append(para)
                }
            }
            if (pageBuffer.isNotEmpty()) {
                commitPage()
            }
        }

        if (pages.isEmpty()) {
            pages.add(BookPage(0, "Chapter I", rawContent.trim(), true))
        }

        return PaginatedBook(chapters = chapters, pages = pages)
    }
}
