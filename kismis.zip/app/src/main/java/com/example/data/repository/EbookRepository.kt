package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.BundledBooksData
import com.example.data.local.EbookDao
import com.example.data.local.EbookEntity
import com.example.data.local.OfflineBookStorage
import com.example.data.remote.GutendexAuthorDto
import com.example.data.remote.GutendexBookDto
import com.example.data.remote.GutendexClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

data class GutendexCatalogPage(
    val books: List<EbookEntity>,
    val totalCount: Int,
    val hasNextPage: Boolean
)

enum class OfflineSyncPhase {
    IDLE,
    INDEXING_CATALOG,
    DOWNLOADING_BOOKS,
    PAUSED_OFFLINE,
    COMPLETED,
    ERROR
}

data class OfflineSyncState(
    val phase: OfflineSyncPhase = OfflineSyncPhase.IDLE,
    val isSyncing: Boolean = false,
    val indexedCount: Int = 0,
    val offlineReadyCount: Int = 0,
    val targetOfflineCount: Int = 1050,
    val storageUsedBytes: Long = 0L,
    val currentBookTitle: String = "",
    val statusMessage: String = ""
)

class EbookRepository(
    private val context: Context,
    private val ebookDao: EbookDao
) {
    private val offlineStorage = OfflineBookStorage(context)

    val allLocalBooks: Flow<List<EbookEntity>> = ebookDao.observeAllBooks()
    val continueReadingBook: Flow<EbookEntity?> = ebookDao.observeContinueReading()
    val downloadedBooks: Flow<List<EbookEntity>> = ebookDao.observeDownloadedBooks()
    val bookmarkedBooks: Flow<List<EbookEntity>> = ebookDao.observeBookmarkedBooks()
    val downloadedBookCount: Flow<Int> = ebookDao.observeDownloadedCount()

    fun observeBook(bookId: String): Flow<EbookEntity?> = ebookDao.observeBookById(bookId)

    fun getOfflineStorageBytes(): Long = offlineStorage.getTotalStorageBytes()

    suspend fun getCachedBookCount(): Int = withContext(Dispatchers.IO) {
        ebookDao.getBookCount()
    }

    suspend fun getDownloadedBookCountSnapshot(): Int = withContext(Dispatchers.IO) {
        ebookDao.getDownloadedBookCount()
    }

    suspend fun ensureBundledBooksSeeded() = withContext(Dispatchers.IO) {
        ebookDao.deleteUndownloadedStubs()
        if (ebookDao.getBundledBookCount() < 1008) {
            BundledBooksData.getInitialBooks()
                .chunked(200)
                .forEach { batch ->
                    ebookDao.insertAllIgnore(batch)
                }
        }
    }

    suspend fun cacheCatalogMetadata(books: List<EbookEntity>) = withContext(Dispatchers.IO) {
        if (books.isNotEmpty()) {
            ebookDao.insertAllIgnore(books)
        }
    }

    suspend fun readBookTextIfAvailable(book: EbookEntity): String? = withContext(Dispatchers.IO) {
        if (book.contentText.isNotBlank()) return@withContext book.contentText
        val dbCopy = ebookDao.getBookById(book.id)
        if (dbCopy != null && dbCopy.contentText.isNotBlank()) return@withContext dbCopy.contentText
        offlineStorage.readBookText(book.id)
    }

    suspend fun fetchGutendexBatch(
        startPage: Int,
        pageCount: Int,
        searchQuery: String? = null,
        categoryFilter: String? = null,
        languageFilter: String? = "en",
        sortOrder: String = "popular"
    ): Result<GutendexCatalogPage> = withContext(Dispatchers.IO) {
        runCatching {
            val results = coroutineScope {
                (startPage until (startPage + pageCount)).map { pageNum ->
                    async {
                        fetchGutendexCatalog(
                            searchQuery = searchQuery,
                            categoryFilter = categoryFilter,
                            languageFilter = languageFilter,
                            sortOrder = sortOrder,
                            page = pageNum
                        ).getOrNull()
                    }
                }.awaitAll().filterNotNull()
            }
            if (results.isEmpty()) {
                throw IllegalStateException("Unable to fetch catalog batch from Gutendex")
            }
            val merged = results.flatMap { it.books }.distinctBy { it.id }
            val total = results.maxOfOrNull { it.totalCount } ?: merged.size
            val hasNext = results.lastOrNull()?.hasNextPage ?: false
            cacheCatalogMetadata(merged)
            GutendexCatalogPage(
                books = merged,
                totalCount = total,
                hasNextPage = hasNext
            )
        }
    }

    suspend fun fetchGutendexCatalog(
        searchQuery: String? = null,
        categoryFilter: String? = null,
        languageFilter: String? = "en",
        sortOrder: String = "popular",
        page: Int = 1
    ): Result<GutendexCatalogPage> = withContext(Dispatchers.IO) {
        runCatching {
            val topic = when (categoryFilter?.lowercase()) {
                null, "all" -> null
                "comedy" -> "humor"
                "entertaining" -> "short stories"
                "mystery" -> "crime"
                "sci-fi" -> "science fiction"
                "drama" -> "drama"
                else -> categoryFilter.lowercase()
            }
            val langParam = languageFilter
                ?.takeIf { it.isNotBlank() && !it.equals("All", ignoreCase = true) }
                ?.lowercase()

            val response = GutendexClient.getBooksWithRetry(
                search = searchQuery?.takeIf { it.isNotBlank() },
                topic = topic,
                languages = langParam,
                sort = sortOrder,
                page = page
            )

            val candidateIds = response.results.map { "gutendex_${it.id}" }
            val existingMap = if (candidateIds.isEmpty()) {
                emptyMap()
            } else {
                ebookDao.getMetadataByIds(candidateIds).associateBy { it.id }
            }

            val books = response.results.mapNotNull { dto ->
                val textUrl = pickBestTextUrl(dto.formats) ?: return@mapNotNull null
                val bookId = "gutendex_${dto.id}"
                val existing = existingMap[bookId]
                val primaryCreator = dto.authors.firstOrNull() ?: dto.editors.firstOrNull()
                val authorText = when {
                    dto.authors.isNotEmpty() -> cleanAuthor(dto.authors.first().name)
                    dto.editors.isNotEmpty() -> "Ed. ${cleanAuthor(dto.editors.first().name)}"
                    else -> "Classic Author"
                }
                val mappedCategory = mapGutendexCategory(dto, categoryFilter)
                EbookEntity(
                    id = bookId,
                    title = cleanTitle(dto.title),
                    author = authorText,
                    category = existing?.category ?: mappedCategory,
                    description = cleanSummary(dto),
                    coverResName = existing?.coverResName,
                    coverUrl = dto.formats["image/jpeg"],
                    textUrl = textUrl,
                    contentText = "",
                    isDownloaded = existing?.isDownloaded ?: false,
                    isBundled = false,
                    isBookmarked = existing?.isBookmarked ?: false,
                    currentPage = existing?.currentPage ?: 0,
                    totalPages = existing?.totalPages ?: 1,
                    progressPercent = existing?.progressPercent ?: 0,
                    lastReadAt = existing?.lastReadAt ?: 0L,
                    accentColorHex = existing?.accentColorHex ?: pickAccentForId(dto.id),
                    customTags = existing?.customTags ?: "",
                    downloadCount = dto.downloadCount,
                    language = dto.languages.firstOrNull()?.uppercase() ?: "EN",
                    authorLifespan = formatLifespan(primaryCreator),
                    shelves = extractShelves(dto)
                )
            }

            GutendexCatalogPage(
                books = books,
                totalCount = response.count,
                hasNextPage = response.next != null
            )
        }
    }

    /**
     * Two-phase resumable offline archive sync:
     * 1) Indexes ~1,270 popular books from Gutendex (resuming from cached page offset).
     * 2) Downloads full book texts in parallel into gzip-compressed local files and commits
     *    SQLite download flags in smooth 16-book transactions so 1,000+ books work fully offline.
     */
    suspend fun syncThousandBooksOffline(
        targetOfflineCount: Int = 1050,
        languageFilter: String = "EN",
        concurrency: Int = 8,
        onProgress: (OfflineSyncState) -> Unit
    ): OfflineSyncState = withContext(Dispatchers.IO) {
        val targetIndexed = targetOfflineCount + 220
        var indexedCount = ebookDao.getBookCount()
        var offlineCount = ebookDao.getDownloadedBookCount()

        if (offlineCount >= targetOfflineCount) {
            val done = OfflineSyncState(
                phase = OfflineSyncPhase.COMPLETED,
                isSyncing = false,
                indexedCount = indexedCount,
                offlineReadyCount = offlineCount,
                targetOfflineCount = targetOfflineCount,
                storageUsedBytes = getOfflineStorageBytes(),
                statusMessage = "$offlineCount e-books ready offline"
            )
            onProgress(done)
            return@withContext done
        }

        // Phase 1: Index enough catalog entries (with smart page resume)
        if (indexedCount < targetIndexed) {
            var pageCursor = (((indexedCount - 8).coerceAtLeast(0)) / 32) + 1
            var consecutiveCatalogFailures = 0
            val chunkPages = concurrency.coerceIn(3, 5)

            while (indexedCount < targetIndexed && pageCursor <= 56) {
                onProgress(
                    OfflineSyncState(
                        phase = OfflineSyncPhase.INDEXING_CATALOG,
                        isSyncing = true,
                        indexedCount = indexedCount,
                        offlineReadyCount = offlineCount,
                        targetOfflineCount = targetOfflineCount,
                        storageUsedBytes = getOfflineStorageBytes(),
                        statusMessage = "Indexing catalog ($indexedCount / $targetIndexed books)…"
                    )
                )

                val batchRes = fetchGutendexBatch(
                    startPage = pageCursor,
                    pageCount = chunkPages,
                    languageFilter = languageFilter
                )
                indexedCount = ebookDao.getBookCount()
                val pageData = batchRes.getOrNull()
                if (pageData == null) {
                    consecutiveCatalogFailures++
                    if (consecutiveCatalogFailures >= 2 && indexedCount <= offlineCount + 20) {
                        val paused = OfflineSyncState(
                            phase = OfflineSyncPhase.PAUSED_OFFLINE,
                            isSyncing = false,
                            indexedCount = indexedCount,
                            offlineReadyCount = offlineCount,
                            targetOfflineCount = targetOfflineCount,
                            storageUsedBytes = getOfflineStorageBytes(),
                            statusMessage = "Paused offline — $offlineCount books saved"
                        )
                        onProgress(paused)
                        return@withContext paused
                    }
                    if (consecutiveCatalogFailures >= 2) break
                    pageCursor += 1
                    continue
                }
                consecutiveCatalogFailures = 0
                if (!pageData.hasNextPage) break
                pageCursor += chunkPages
            }
        }

        // Phase 2: Download full plain-text e-books in bounded parallel worker pool
        val pendingMarks = mutableListOf<Pair<String, Int>>()
        val marksMutex = Mutex()
        val offlineCounter = AtomicInteger(offlineCount)
        val consecutiveNetFailures = AtomicInteger(0)
        val abortNetwork = AtomicBoolean(false)

        suspend fun flushMarks(forceReportTitle: String = "") {
            val batch = marksMutex.withLock {
                if (pendingMarks.isEmpty()) emptyList()
                else pendingMarks.toList().also { pendingMarks.clear() }
            }
            if (batch.isNotEmpty()) {
                ebookDao.markBooksDownloadedBatch(batch)
            }
            val currentOffline = ebookDao.getDownloadedBookCount()
            offlineCounter.set(currentOffline)
            onProgress(
                OfflineSyncState(
                    phase = OfflineSyncPhase.DOWNLOADING_BOOKS,
                    isSyncing = true,
                    indexedCount = indexedCount,
                    offlineReadyCount = currentOffline,
                    targetOfflineCount = targetOfflineCount,
                    storageUsedBytes = getOfflineStorageBytes(),
                    currentBookTitle = forceReportTitle,
                    statusMessage = "Saving books offline ($currentOffline / $targetOfflineCount)…"
                )
            )
        }

        try {
            var pass = 0
            while (offlineCounter.get() < targetOfflineCount && !abortNetwork.get() && pass < 3) {
                pass++
                val remainingNeeded = (targetOfflineCount - offlineCounter.get()).coerceAtLeast(1)
                val candidates = ebookDao.getUndownloadedSyncCandidates(remainingNeeded + 90)
                if (candidates.isEmpty()) {
                    // Fetch additional catalog pages if existing candidates were exhausted
                    val nextPage = ((indexedCount - 8).coerceAtLeast(0) / 32) + 1
                    val extra = fetchGutendexBatch(
                        startPage = nextPage,
                        pageCount = 4,
                        languageFilter = languageFilter
                    ).getOrNull()
                    indexedCount = ebookDao.getBookCount()
                    if (extra == null || extra.books.isEmpty()) break
                    continue
                }

                val channel = Channel<EbookEntity>(Channel.UNLIMITED)
                candidates.forEach { channel.trySend(it) }
                channel.close()

                coroutineScope {
                    val workerCount = concurrency.coerceIn(3, 10)
                    repeat(workerCount) {
                        launch {
                            for (book in channel) {
                                if (abortNetwork.get() || offlineCounter.get() >= targetOfflineCount) {
                                    break
                                }
                                val url = book.textUrl ?: continue
                                try {
                                    val totalPages = if (offlineStorage.hasBookText(book.id)) {
                                        book.totalPages.coerceAtLeast(10)
                                    } else {
                                        val downloaded = GutendexClient.downloadPlainTextWithFallbacks(
                                            primaryUrl = url,
                                            gutenbergId = GutendexClient.extractGutenbergId(book.id)
                                        )
                                        offlineStorage.saveBookText(book.id, downloaded)
                                        estimatePagesFast(downloaded)
                                    }
                                    consecutiveNetFailures.set(0)
                                    val newCount = offlineCounter.incrementAndGet()

                                    var shouldFlush = false
                                    marksMutex.withLock {
                                        pendingMarks.add(book.id to totalPages)
                                        if (pendingMarks.size >= 16 || newCount >= targetOfflineCount) {
                                            shouldFlush = true
                                        }
                                    }
                                    if (shouldFlush) {
                                        flushMarks(book.title)
                                    } else if (newCount % 4 == 0) {
                                        onProgress(
                                            OfflineSyncState(
                                                phase = OfflineSyncPhase.DOWNLOADING_BOOKS,
                                                isSyncing = true,
                                                indexedCount = indexedCount,
                                                offlineReadyCount = newCount.coerceAtMost(targetOfflineCount),
                                                targetOfflineCount = targetOfflineCount,
                                                storageUsedBytes = getOfflineStorageBytes(),
                                                currentBookTitle = book.title,
                                                statusMessage = "Saving books offline ($newCount / $targetOfflineCount)…"
                                            )
                                        )
                                    }
                                } catch (ce: CancellationException) {
                                    throw ce
                                } catch (_: Throwable) {
                                    if (consecutiveNetFailures.incrementAndGet() >= 14) {
                                        abortNetwork.set(true)
                                    }
                                }
                            }
                        }
                    }
                }
                flushMarks()
            }
        } finally {
            withContext(NonCancellable) {
                val leftover = marksMutex.withLock {
                    if (pendingMarks.isEmpty()) emptyList()
                    else pendingMarks.toList().also { pendingMarks.clear() }
                }
                if (leftover.isNotEmpty()) {
                    ebookDao.markBooksDownloadedBatch(leftover)
                }
            }
        }

        val finalOffline = ebookDao.getDownloadedBookCount()
        val finalIndexed = ebookDao.getBookCount()
        val finalBytes = getOfflineStorageBytes()
        val finalPhase = when {
            finalOffline >= targetOfflineCount -> OfflineSyncPhase.COMPLETED
            abortNetwork.get() -> OfflineSyncPhase.PAUSED_OFFLINE
            else -> OfflineSyncPhase.PAUSED_OFFLINE
        }
        val finalState = OfflineSyncState(
            phase = finalPhase,
            isSyncing = false,
            indexedCount = finalIndexed,
            offlineReadyCount = finalOffline,
            targetOfflineCount = targetOfflineCount,
            storageUsedBytes = finalBytes,
            statusMessage = if (finalPhase == OfflineSyncPhase.COMPLETED) {
                "$finalOffline e-books ready offline (${OfflineBookStorage.formatBytes(finalBytes)})"
            } else {
                "Paused at $finalOffline / $targetOfflineCount offline (${OfflineBookStorage.formatBytes(finalBytes)})"
            }
        )
        onProgress(finalState)
        finalState
    }

    suspend fun ensureBookReadyForReading(book: EbookEntity): Result<EbookEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val cached = ebookDao.getBookById(book.id)
                val base = cached ?: book

                val existingText = when {
                    base.contentText.isNotBlank() -> base.contentText
                    else -> offlineStorage.readBookText(base.id)
                }

                if (!existingText.isNullOrBlank()) {
                    val now = System.currentTimeMillis()
                    if (cached == null) {
                        ebookDao.upsertBook(
                            base.copy(
                                isDownloaded = true,
                                lastReadAt = now,
                                totalPages = base.totalPages.coerceAtLeast(estimatePagesFast(existingText))
                            )
                        )
                    } else {
                        ebookDao.updateReadingProgress(
                            bookId = base.id,
                            currentPage = base.currentPage,
                            totalPages = base.totalPages.coerceAtLeast(estimatePagesFast(existingText)),
                            progressPercent = base.progressPercent,
                            lastReadAt = now
                        )
                    }
                    return@runCatching base.copy(
                        contentText = existingText,
                        isDownloaded = true,
                        lastReadAt = now
                    )
                }

                val url = base.textUrl
                    ?: throw IllegalStateException("This e-book has no downloadable plain text format.")
                val downloadedText = GutendexClient.downloadPlainTextWithFallbacks(
                    primaryUrl = url,
                    gutenbergId = GutendexClient.extractGutenbergId(base.id)
                )
                offlineStorage.saveBookText(base.id, downloadedText)
                val pageEstimate = estimatePagesFast(downloadedText)
                val now = System.currentTimeMillis()

                // Store metadata + download flag in Room while keeping bulky full text compressed on disk
                ebookDao.upsertBook(
                    base.copy(
                        contentText = "",
                        isDownloaded = true,
                        totalPages = pageEstimate,
                        lastReadAt = now
                    )
                )
                base.copy(
                    contentText = downloadedText,
                    isDownloaded = true,
                    totalPages = pageEstimate,
                    lastReadAt = now
                )
            }
        }

    suspend fun downloadBookForOffline(book: EbookEntity): Result<EbookEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val cached = ebookDao.getBookById(book.id)
                val base = cached ?: book

                val existingText = when {
                    base.contentText.isNotBlank() -> base.contentText
                    else -> offlineStorage.readBookText(base.id)
                }
                if (!existingText.isNullOrBlank()) {
                    val pageEstimate = base.totalPages.coerceAtLeast(estimatePagesFast(existingText))
                    if (cached == null || !cached.isDownloaded) {
                        ebookDao.upsertBook(
                            base.copy(
                                isDownloaded = true,
                                totalPages = pageEstimate
                            )
                        )
                    }
                    return@runCatching base.copy(
                        contentText = existingText,
                        isDownloaded = true,
                        totalPages = pageEstimate
                    )
                }

                val url = base.textUrl
                    ?: throw IllegalStateException("This e-book has no downloadable plain text format.")
                val downloadedText = GutendexClient.downloadPlainTextWithFallbacks(
                    primaryUrl = url,
                    gutenbergId = GutendexClient.extractGutenbergId(base.id)
                )
                offlineStorage.saveBookText(base.id, downloadedText)
                val pageEstimate = estimatePagesFast(downloadedText)
                ebookDao.upsertBook(
                    base.copy(
                        contentText = "",
                        isDownloaded = true,
                        totalPages = pageEstimate
                    )
                )
                base.copy(
                    contentText = downloadedText,
                    isDownloaded = true,
                    totalPages = pageEstimate
                )
            }
        }

    suspend fun updateProgress(
        bookId: String,
        currentPage: Int,
        totalPages: Int
    ) = withContext(Dispatchers.IO) {
        val safeTotal = totalPages.coerceAtLeast(1)
        val safePage = currentPage.coerceIn(0, safeTotal - 1)
        val percent = if (safeTotal <= 1) {
            100
        } else {
            (((safePage + 1).toFloat() / safeTotal.toFloat()) * 100f).toInt().coerceIn(1, 100)
        }
        ebookDao.updateReadingProgress(
            bookId = bookId,
            currentPage = safePage,
            totalPages = safeTotal,
            progressPercent = percent,
            lastReadAt = System.currentTimeMillis()
        )
    }

    suspend fun toggleBookmark(book: EbookEntity) = withContext(Dispatchers.IO) {
        val existing = ebookDao.getBookById(book.id)
        if (existing == null) {
            ebookDao.upsertBook(book.copy(isBookmarked = true))
        } else {
            ebookDao.setBookmarked(book.id, !existing.isBookmarked)
        }
    }

    suspend fun updateCustomTags(book: EbookEntity, tags: List<String>) = withContext(Dispatchers.IO) {
        val normalized = tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString(",")
        val existing = ebookDao.getBookById(book.id)
        if (existing == null) {
            ebookDao.upsertBook(book.copy(customTags = normalized))
        } else {
            ebookDao.updateCustomTags(book.id, normalized)
        }
    }

    suspend fun updateCategory(book: EbookEntity, newCategory: String) = withContext(Dispatchers.IO) {
        val cleaned = newCategory.trim().ifBlank { "Fiction" }
        val existing = ebookDao.getBookById(book.id)
        if (existing == null) {
            ebookDao.upsertBook(book.copy(category = cleaned))
        } else {
            ebookDao.updateCategory(book.id, cleaned)
        }
    }

    suspend fun removeBook(bookId: String) = withContext(Dispatchers.IO) {
        offlineStorage.deleteBookText(bookId)
        ebookDao.deleteNonBundledBook(bookId)
    }

    suspend fun clearUnusedCache() = withContext(Dispatchers.IO) {
        ebookDao.clearUnusedCache()
    }

    suspend fun importLocalTextBook(uri: Uri, fallbackName: String): Result<EbookEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                    it.readText()
                } ?: throw IllegalStateException("Could not read selected file")
                val cleaned = text.trim()
                require(cleaned.isNotEmpty()) { "Selected file is empty" }
                val paginated = BookPaginationEngine.paginate(cleaned, 18f)
                val bookId = "imported_${UUID.randomUUID()}"
                offlineStorage.saveBookText(bookId, cleaned)
                val title = fallbackName.substringBeforeLast('.').ifBlank { "Imported e-Book" }
                val book = EbookEntity(
                    id = bookId,
                    title = title,
                    author = "Imported Document",
                    category = "Imported",
                    description = "Imported from device storage",
                    contentText = "",
                    isDownloaded = true,
                    isBundled = false,
                    isBookmarked = false,
                    currentPage = 0,
                    totalPages = paginated.pages.size,
                    progressPercent = 0,
                    lastReadAt = System.currentTimeMillis(),
                    accentColorHex = 0xFF166EF4L
                )
                ebookDao.upsertBook(book)
                book.copy(contentText = cleaned)
            }
        }

    private fun estimatePagesFast(text: String): Int {
        return (text.length / 1150).coerceAtLeast(1)
    }

    private fun pickBestTextUrl(formats: Map<String, String>): String? {
        return formats["text/plain; charset=utf-8"]
            ?: formats["text/plain; charset=us-ascii"]
            ?: formats["text/plain"]
            ?: formats.entries.firstOrNull { it.key.startsWith("text/plain") }?.value
    }

    private fun cleanTitle(raw: String): String {
        return raw.substringBefore(";").trim().take(72)
    }

    private fun cleanAuthor(raw: String): String {
        val cleaned = raw.replace(" (Translator)", "", ignoreCase = true).trim()
        val parts = cleaned.split(",").map { it.trim() }
        return if (parts.size >= 2 && !parts[0].equals("Marcus Aurelius", ignoreCase = true)) {
            "${parts[1]} ${parts[0]}"
        } else {
            parts.firstOrNull() ?: cleaned
        }
    }

    private fun cleanSummary(dto: GutendexBookDto): String {
        val rawSummary = dto.summaries.firstOrNull()
        if (!rawSummary.isNullOrBlank()) {
            return rawSummary
                .replace(Regex("""\s*\(This is an automatically generated summary\.\)\s*""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }
        return dto.subjects.take(3).joinToString(" • ")
            .ifBlank { "Public domain classic from Project Gutenberg" }
    }

    private fun formatLifespan(person: GutendexAuthorDto?): String {
        if (person == null) return ""
        val birth = person.birthYear
        val death = person.deathYear
        if (birth == null && death == null) return ""
        fun formatYear(year: Int?): String = when {
            year == null -> "?"
            year < 0 -> "${-year} BC"
            else -> year.toString()
        }
        return "${formatYear(birth)}–${formatYear(death)}"
    }

    private fun extractShelves(dto: GutendexBookDto): String {
        val cleanedShelves = dto.bookshelves
            .map { it.removePrefix("Category: ").trim() }
            .filter { it.isNotBlank() }
        val cleanedSubjects = dto.subjects
            .map { it.substringBefore(" -- ").trim() }
            .filter { it.isNotBlank() && it.length <= 28 }
        return (cleanedShelves + cleanedSubjects)
            .distinct()
            .take(5)
            .joinToString(",")
    }

    private fun mapGutendexCategory(dto: GutendexBookDto, activeFilter: String?): String {
        if (!activeFilter.isNullOrBlank() && activeFilter != "All") return activeFilter
        val joined = (dto.subjects + dto.bookshelves).joinToString(" ").lowercase()
        return when {
            "humor" in joined || "comedy" in joined || "humorous" in joined || "satire" in joined -> "Comedy"
            "crime" in joined || "mystery" in joined || "detective" in joined -> "Mystery"
            "horror" in joined || "gothic" in joined -> "Horror"
            "science fiction" in joined || "science-fiction" in joined || "sci-fi" in joined -> "Sci-Fi"
            "romance" in joined || "love stories" in joined -> "Romance"
            "adventure" in joined -> "Adventure"
            "philosophy" in joined || "ethics" in joined || "politics" in joined -> "Philosophy"
            "drama" in joined || "plays" in joined || "tragedies" in joined -> "Drama"
            "short stories" in joined || "wit" in joined || "children" in joined -> "Entertaining"
            else -> "Fiction"
        }
    }

    private fun pickAccentForId(id: Int): Long {
        val accents = listOf(
            0xFF166EF4L,
            0xFFFF6B1AL,
            0xFF059669L,
            0xFF2563EBL,
            0xFFEA580CL,
            0xFF0891B2L
        )
        return accents[kotlin.math.abs(id) % accents.size]
    }
}

