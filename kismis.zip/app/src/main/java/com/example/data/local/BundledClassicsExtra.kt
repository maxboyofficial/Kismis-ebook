package com.example.data.local

object BundledClassicsExtra {

    fun getAdditionalBooks(): List<EbookEntity> = listOf(
        EbookEntity(
            id = "kismis_harbor_letters",
            title = "Letters from Harbor House",
            author = "Eleanor Vance",
            category = "Romance",
            description = "Two neighbors separated by a salt-washed seawall exchange handwritten book notes across an unforgettable autumn.",
            contentText = harborLettersText,
            isDownloaded = true,
            isBundled = true,
            isBookmarked = false,
            currentPage = 0,
            totalPages = 8,
            progressPercent = 0,
            lastReadAt = 0L,
            accentColorHex = 0xFFFF6B1AL,
            customTags = "Warm,Autumn",
            downloadCount = 41200,
            language = "EN",
            shelves = "Romance,Epistolary"
        ),
        EbookEntity(
            id = "kismis_fog_lighthouse",
            title = "The Keeper of Point Sable",
            author = "Marcus Thorne",
            category = "Horror",
            description = "Every seventh tide, the brass bell beneath Point Sable lighthouse rings without a hand to pull its rope.",
            contentText = lighthouseText,
            isDownloaded = true,
            isBundled = true,
            isBookmarked = false,
            currentPage = 0,
            totalPages = 8,
            progressPercent = 0,
            lastReadAt = 0L,
            accentColorHex = 0xFF1E293BL,
            customTags = "Atmospheric,Late Night",
            downloadCount = 38400,
            language = "EN",
            shelves = "Gothic Fiction,Horror"
        ),
        EbookEntity(
            id = "kismis_ridgeway_compass",
            title = "Beyond the Blue Meridian",
            author = "Nadia Okafor",
            category = "Adventure",
            description = "An expedition across uncharted alpine ridges follows a nineteenth-century brass sextant and a torn journal page.",
            contentText = meridianText,
            isDownloaded = true,
            isBundled = true,
            isBookmarked = false,
            currentPage = 0,
            totalPages = 8,
            progressPercent = 0,
            lastReadAt = 0L,
            accentColorHex = 0xFF059669L,
            customTags = "Journey,Expedition",
            downloadCount = 34900,
            language = "EN",
            shelves = "Adventure,Travel"
        ),
        EbookEntity(
            id = "kismis_quiet_courtyard",
            title = "Notes from a Quiet Courtyard",
            author = "Kenji Takahashi",
            category = "Philosophy",
            description = "Short morning meditations on stillness, craftsmanship, attention, and the art of reading slowly.",
            contentText = courtyardText,
            isDownloaded = true,
            isBundled = true,
            isBookmarked = false,
            currentPage = 0,
            totalPages = 8,
            progressPercent = 0,
            lastReadAt = 0L,
            accentColorHex = 0xFF166EF4L,
            customTags = "Mindful,Essays",
            downloadCount = 29750,
            language = "EN",
            shelves = "Philosophy & Ethics,Essays"
        )
    )

    private val harborLettersText = """
CHAPTER I: MARGINALIA ON PAGE FORTY

The paperback arrived on a Tuesday morning, propped inside the dry cedar mailbox between a seed catalog and the tide table. Inside the front cover, someone had penciled a neat bracket around a stanza about October rain and written in small, steady cursive: "Better read beside a kettle."

Claire carried the book up the stone steps of Harbor House, set the kettle on, and stared across the low brick wall dividing her garden from the cottage next door. Smoke curled briskly from its chimney.

CHAPTER II: THE RETURN MARGIN

By Friday she had answered in pencil on page ninety-two, noting that the author exaggerated the chill of coastal wind but understood everything about salt on windowpanes. She tucked the book inside a waxed paper sleeve and balanced it on the brick wall before the afternoon ferry sounded its horn.

When dusk settled over the cove, the book had vanished, replaced by two russet pears and a folded card bearing a single line: "Next chapter awaits beside the breakwater at five."

CHAPTER III: THE SEAWALL BENCH

They met not as strangers, for three chapters of shared annotations had already introduced every preference and disagreement between them. Over thermoses of spiced tea, the harbor lights flickered awake across the water, turning the grey bay into liquid copper.
    """.trimIndent()

    private val lighthouseText = """
CHAPTER I: THE SEVENTH TIDE

No keeper at Point Sable had ever logged the lower bell chamber twice in the same week, yet the bronze clapper struck three clear notes at midnight while the gale rattled the storm shutters.

Julian checked the lantern mechanism first. The Fresnel lens turned with oily, indifferent precision, casting twin beams out across black swells that broke fifty feet below the granite sill.

CHAPTER II: STAIRWELL ECHOES

Halfway down the spiral iron steps, the salt air turned sharply cold, carrying the scent of wet cedar and old lamp wick. On the landing lay a brass key stamped 1889—older than any door remaining in the tower.

When the bell sounded a fourth time, not from above but from directly beneath the floorboards, Julian set his lantern down and knelt beside the rusted hatchway.

CHAPTER III: DAYLIGHT ON GRANITE

By dawn the storm cleared to glass-calm water, revealing the sunken breakwater stone where the original bell had once hung to guide herring boats safely home through winter fog.
    """.trimIndent()

    private val meridianText = """
CHAPTER I: THE BRASS SEXTANT

At twelve thousand feet, air behaves like cold crystal, sharpening every ridge until distant peaks seem close enough to touch. Nadia unstrapped the leather case and checked the tarnished vernier scale once more.

Three generations of cartographers had dismissed the pass east of Monte Bruma as solid granite. Yet the faded 1894 sketch showed a narrow saddle catching the solstice sun precisely at noon.

CHAPTER II: THE STONE CAIRN

Two hours before dusk, beneath an overhang shielded from the glacier wind, their ice axes struck stacked slate—no natural scree, but a deliberate cairn built shoulder-high. Inside a copper tin rested a dry oilcloth packet filled with pressed alpine gentians and clear compass bearings down to the emerald valley below.
    """.trimIndent()

    private val courtyardText = """
BOOK I: ON ATTENTION

Before opening any volume, clear the table of three unnecessary things. A quiet surface invites a quiet mind, and a quiet mind notices the cadence hidden inside ordinary sentences.

We often hurry through pages as though arriving at the back cover were the purpose of a journey. Yet nobody listens to a sonata merely to reach the final chord.

BOOK II: ON CRAFT AND PATIENCE

A cedar carpenter measures twice not out of doubt, but out of respect for the grain. In the same way, a thoughtful reader pauses at an unfamiliar phrase, turning it toward the window light until its shape grows clear.

Small daily habits outlast grand resolutions: ten unhurried pages before sleep will quietly carry you across libraries.
    """.trimIndent()
}
