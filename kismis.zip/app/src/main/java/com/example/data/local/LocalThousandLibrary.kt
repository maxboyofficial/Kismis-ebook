package com.example.data.local

/**
 * Generates 1,000 distinct, multi-chapter offline e-books across all 10 genres
 * so Kismis ships with 1,008 full readable books stored directly in the local
 * Room database on first launch without any network sync or internet dependency.
 */
object LocalThousandLibrary {

    private data class GenreBlueprint(
        val category: String,
        val shelves: String,
        val accentColors: List<Long>,
        val leadMotifs: List<String>,
        val placeMotifs: List<String>,
        val protagonists: List<String>,
        val companions: List<String>,
        val artifacts: List<String>,
        val conflicts: List<String>,
        val authors: List<Pair<String, String>>,
        val tags: List<String>
    )

    private val blueprints = listOf(
        GenreBlueprint(
            category = "Comedy",
            shelves = "Humor,Satire,Wit",
            accentColors = listOf(0xFFFF6B1AL, 0xFF166EF4L, 0xFFEA580CL),
            leadMotifs = listOf(
                "The Umbrella of", "Three Teapots in", "The Mislaid Hat of", "A Polite Chaos at",
                "Tuesday Troubles in", "The Mayor's Cat of", "Two Left Shoes in", "The Punctual Goat of",
                "A Slight Exaggeration at", "Breakfast Diplomacy in"
            ),
            placeMotifs = listOf(
                "Bloomsbury Square", "Puddlewick Fair", "Cranberry Lane", "Upper Finchley",
                "the Regent Conservatory", "Old Bramble Station", "Silver Kettle Inn", "Hedgehog Hollow",
                "Piccadilly Terrace", "Maple Cross"
            ),
            protagonists = listOf("Barnaby Finch", "Harriet Plumb", "Oliver Wink", "Beatrice Crumble", "Nigel Pimm"),
            companions = listOf("Cousin Penelope", "Inspector Bunce", "Lady Lavender", "Mr. Chivers", "Aunt Agatha"),
            artifacts = listOf("an oversized brass gong", "a velvet biscuit tin", "seven identical top hats", "a stubborn grandfather clock", "a misplaced parrot"),
            conflicts = listOf(
                "must win a village baking contest before the bishop notices the missing prize",
                "attempts to host two rival uncles in the same drawing room without either recognizing the other",
                "accidentally swaps luggage with an opera troupe moments before curtain rise",
                "tries to return a borrowed prize cucumber that keeps appearing in the local gazette",
                "organizes a silent charity bazaar that turns into a town-wide brass band parade"
            ),
            authors = listOf(
                "P. G. Mercer" to "1881–1975", "Clara Wode" to "1894–1968", "Arthur Bunting" to "1876–1942",
                "Evelyn Tupp" to "1902–1980", "Miles Chaffinch" to "1888–1955", "Dora Appleby" to "1899–1971",
                "Reginald Crump" to "1872–1939", "Phoebe Lark" to "1908–1986", "Hugh Thimble" to "1885–1961",
                "Mabel Scone" to "1891–1964"
            ),
            tags = listOf("Witty", "Lighthearted", "Weekend Read", "Satire")
        ),
        GenreBlueprint(
            category = "Mystery",
            shelves = "Detective Fiction,Crime,Whodunit",
            accentColors = listOf(0xFF1E3A8AL, 0xFF166EF4L, 0xFF0F172AL),
            leadMotifs = listOf(
                "The Vanishing Key of", "Footprints Beside", "The Locked Ledger at", "Seven Clocks in",
                "A Cipher from", "The Eleventh Witness at", "Shadows Over", "The Brass Alibi of",
                "The Midnight Telegram from", "The Silent Study at"
            ),
            placeMotifs = listOf(
                "Baker Row", "Foghorn Pier", "Rookwood Manor", "Alderney Archive",
                "Chancery Court", "Vesper Crossing", "Blackfriars Walk", "Thornhill Estate",
                "the Old Observatory", "St. Jude Quay"
            ),
            protagonists = listOf("Detective Julian Cross", "Clara Ashworth", "Inspector Miles Vane", "Nora Holloway", "Gideon Pike"),
            companions = listOf("Dr. Sterling", "Constable Reed", "Archivist Vera", "Sergeant Bellamy", "Miss Marlowe"),
            artifacts = listOf("a torn railway stub", "an engraved silver locket", "a ciphered pocket diary", "a wax-sealed envelope", "a mud-stained timetable"),
            conflicts = listOf(
                "reconstructs twenty missing minutes from a snowbound express train timetable",
                "uncovers why every clock in the manor stopped at nineteen minutes past eleven",
                "follows a trail of ledger ink across three riverside bookshops before dawn",
                "exposes a forged inheritance tucked behind an oil portrait in the east gallery",
                "solves how a locked library vault emptied itself without a single footprint outside"
            ),
            authors = listOf(
                "Arthur Vale" to "1859–1930", "Agatha Penn" to "1890–1976", "G. K. Vance" to "1874–1936",
                "Dorothy Greaves" to "1893–1957", "Wilkie Rook" to "1824–1889", "Josephine Teyton" to "1896–1952",
                "Ngaio Thorne" to "1895–1982", "Edgar Poeley" to "1809–1849", "Margery Fane" to "1904–1966",
                "Freeman Crofts" to "1879–1957"
            ),
            tags = listOf("Detective", "Page Turner", "Late Night", "Puzzle")
        ),
        GenreBlueprint(
            category = "Horror",
            shelves = "Gothic Fiction,Supernatural,Dark Tales",
            accentColors = listOf(0xFF1E293BL, 0xFF7C2D12L, 0xFF334155L),
            leadMotifs = listOf(
                "Whispers Beneath", "The Pale Lantern of", "The Seventh Tide at", "Cold Echoes in",
                "The Hollow Bell of", "Mist Around", "The Candle Keeper at", "Footsteps Above",
                "The Winter Mirror of", "Ashes Along"
            ),
            placeMotifs = listOf(
                "Point Sable", "Ravenscroft Abbey", "Morrow Fen", "Bleakwater Cliffs",
                "the Salt Chapel", "Oakhaven Crypt", "Windermere Moor", "Highgate Cellar",
                "North Pier Tower", "Grimstone Hollow"
            ),
            protagonists = listOf("Marcus Thorne", "Eleanor Blackwood", "Thomas Graves", "Lucia Ward", "Samuel Crane"),
            companions = listOf("the groundskeeper", "Father Kendrick", "Dr. Marrow", "Sister Helene", "Captain Hollis"),
            artifacts = listOf("a tarnished bronze key", "an undated ship log", "a cracked silver mirror", "a soot-stained music box", "an iron weathervane"),
            conflicts = listOf(
                "discovers why the tower bell rings strictly when no living hand touches the rope",
                "deciphers scratch marks hidden behind wallpaper installed a century ago",
                "keeps vigil beside an abbey well whose echoes answer two seconds too late",
                "tracks an unmapped cellar staircase that only appears during coastal fog",
                "reads an ancestor's final journal warning against opening the north shutters"
            ),
            authors = listOf(
                "M. R. Ashford" to "1862–1936", "Mary Shelleyton" to "1797–1851", "Algernon Crowe" to "1869–1951",
                "Sheridan LeFane" to "1814–1873", "Bram Hargreaves" to "1847–1912", "Shirley Vesper" to "1916–1965",
                "Vernon Leech" to "1856–1935", "William Hope" to "1877–1918", "Charlotte Stoker" to "1863–1940",
                "Ambrose Vance" to "1842–1914"
            ),
            tags = listOf("Gothic", "Atmospheric", "Late Night", "Chilling")
        ),
        GenreBlueprint(
            category = "Romance",
            shelves = "Romance,Epistolary,Classic Love",
            accentColors = listOf(0xFFFF6B1AL, 0xFFEA580CL, 0xFF2563EBL),
            leadMotifs = listOf(
                "Letters from", "Autumn Walk to", "The Garden Gate at", "Promises Along",
                "Afternoon Rain in", "A Song for", "Sunlit Windows of", "The Cedar Mailbox at",
                "Moonlight Across", "Two Tickets to"
            ),
            placeMotifs = listOf(
                "Seaglass Manor", "Rosamond Cottage", "Linden Square", "Willowbrook Hall",
                "the Coastal Promenade", "Devonshire Orchard", "Brighton Pier", "Marigold Terrace",
                "Lake Como Villa", "Clover Hill"
            ),
            protagonists = listOf("Eleanor Vance", "Elizabeth Hart", "Julian Brooks", "Clara Bellamy", "Henry Langdon"),
            companions = listOf("Margaret Hollis", "Captain Wentworth", "Sophia Wren", "Theodore Gray", "Lucy Sterling"),
            artifacts = listOf("penciled marginalia in an old novel", "a pressed sprig of lavender", "an unsent harbor postcard", "a hand-painted bookmark", "a shared umbrella"),
            conflicts = listOf(
                "trades handwritten book notes across a brick garden wall throughout an unforgettable autumn",
                "reunites by chance on a rain-swept ferry platform five summers after a missed train",
                "competes politely to restore the town conservatory while hiding unspoken affection",
                "discovers that a childhood pen pal has opened the sunlit bookshop directly opposite hers",
                "navigates family pride and quiet misunderstandings before the winter solstice ball"
            ),
            authors = listOf(
                "Jane Pemberton" to "1775–1817", "Eleanor Bronte" to "1816–1855", "Louisa March" to "1832–1888",
                "Elizabeth Gaskellton" to "1810–1865", "Lucy Montgomery" to "1874–1942", "Georgette Vale" to "1902–1974",
                "E. M. Forsterly" to "1879–1970", "Grace Wharton" to "1862–1937", "Frances Burnett" to "1849–1924",
                "Clara Austen" to "1782–1845"
            ),
            tags = listOf("Warm", "Heartfelt", "Autumn", "Cozy")
        ),
        GenreBlueprint(
            category = "Adventure",
            shelves = "Adventure,Travel,Expedition",
            accentColors = listOf(0xFF059669L, 0xFF0891B2L, 0xFFFF6B1AL),
            leadMotifs = listOf(
                "Beyond the Ridge of", "The Brass Compass of", "Voyage Toward", "Sails Over",
                "The Lost Trail of", "Storms Across", "Cartographer's Map to", "Gold and Salt at",
                "The Horizon Line of", "Caravan Through"
            ),
            placeMotifs = listOf(
                "the Blue Meridian", "Cape Tempest", "Emerald Archipelago", "High Atlas Pass",
                "Coral Harbor", "Timberwolf Canyon", "the Southern Fjords", "Redwood Basin",
                "Silver Strait", "Copper Valley"
            ),
            protagonists = listOf("Nadia Okafor", "Captain Edmund Drake", "Rowan Calder", "Elena Vasquez", "Arthur Sterling"),
            companions = listOf("Navigator Mateo", "Quartermaster Lin", "Dr. Osei", "Scout Tenzin", "First Mate Jonah"),
            artifacts = listOf("a nineteenth-century brass sextant", "a saltwater-stained chart", "a folded copper astrolabe", "an alpine survey notebook", "a carved cedar oar"),
            conflicts = listOf(
                "charts an unrecorded mountain pass before early winter snows seal the valley",
                "steers a sturdy two-masted brigantine around reef shoals in pursuit of a lost survey ship",
                "crosses three sunlit river gorges using only star bearings and an ancestor's field diary",
                "rescues a stranded botanical expedition along the windswept cliffs of the southern archipelago",
                "races rival treasure seekers to verify an ancient maritime route across calm trade winds"
            ),
            authors = listOf(
                "Robert L. Verne" to "1850–1894", "Jules Verneley" to "1828–1905", "Jack Callaghan" to "1876–1916",
                "Joseph Conradson" to "1857–1924", "H. Rider Haggardson" to "1856–1925", "Amelia Earharton" to "1897–1937",
                "Isabella Birdwell" to "1831–1904", "Ernest Shackleton" to "1874–1922", "Rafael Sabatini" to "1875–1950",
                "Daniel Defoeton" to "1660–1731"
            ),
            tags = listOf("Expedition", "Journey", "High Seas", "Courage")
        ),
        GenreBlueprint(
            category = "Sci-Fi",
            shelves = "Science Fiction,Speculative,Futurism",
            accentColors = listOf(0xFF166EF4L, 0xFF6D28D9L, 0xFF0891B2L),
            leadMotifs = listOf(
                "Chronosphere of", "Orbit Above", "The Glass Astrolabe in", "Signals from",
                "The Starlight Engine of", "Echoes of Tomorrow in", "The Meridian Station at", "Aether Loom of",
                "The Martian Garden near", "Helios Relay over"
            ),
            placeMotifs = listOf(
                "New Greenwich", "Kepler Basin", "Station Aurora", "Titan Spire",
                "Cassiopeia Ridge", "Caldera Nine", "Orbital Arch", "Lagrange Haven",
                "Vega Colony", "Solaris Dome"
            ),
            protagonists = listOf("H. V. Mercer", "Dr. Maya Chen", "Aris Kael", "Sora Takahashi", "Elena Rostova"),
            companions = listOf("Engineer Petrov", "Archivist Unit Seven", "Pilot Niamh", "Astrophysicist Tariq", "Commander Vance"),
            artifacts = listOf("a quartz-and-brass pendulum", "a crystalline star chart", "a humming gravity gyroscope", "a quantum tape reel", "an atmospheric prism"),
            conflicts = listOf(
                "calibrates a temporal pendulum that reveals glimpses of a sky built centuries ahead",
                "decodes a harmonic radio pulse echoing between two quiet moons in deep orbit",
                "restarts an abandoned orbital greenhouse keeping humanity's rarest seeds alive",
                "pilots a solar-sail courier craft across magnetic currents toward the outer relays",
                "uncovers blueprints left inside an ancient lunar vault beneath frozen basalt"
            ),
            authors = listOf(
                "H. G. Wellsworth" to "1866–1946", "Karel Capekson" to "1890–1938", "Olaf Stapledon" to "1886–1950",
                "J. H. Rosny" to "1856–1940", "Charlotte Gilman" to "1860–1935", "Yevgeny Zamyatin" to "1884–1937",
                "Edwin Abbott" to "1838–1926", "E. E. Smithson" to "1890–1965", "Leigh Brackett" to "1915–1978",
                "Stanley Weinbaum" to "1902–1935"
            ),
            tags = listOf("Future", "Space", "Invention", "Mind-Bending")
        ),
        GenreBlueprint(
            category = "Philosophy",
            shelves = "Philosophy & Ethics,Essays,Wisdom",
            accentColors = listOf(0xFF0F766EL, 0xFF166EF4L, 0xFF1E3A8AL),
            leadMotifs = listOf(
                "Notes from", "Meditations at", "On Stillness and", "The Quiet Art of",
                "Letters Concerning", "Morning Walk Through", "Reflections Beside", "The Measured Life in",
                "Discourse on", "Pages from"
            ),
            placeMotifs = listOf(
                "Cypress Courtyard", "Cedar Grove", "the Stoic Portico", "Olive Terrace",
                "Mountain Hermitage", "Stone Library", "Autumn Commons", "Lantern Pavilion",
                "Harbor Steps", "the Willow Bench"
            ),
            protagonists = listOf("Kenji Takahashi", "Marcus Antonius", "Sophia Al-Mansoor", "Julian Seneca", "Clara Montaigne"),
            companions = listOf("the stone mason", "Elder Lin", "a young apprentice", "Professor Hale", "the ferryman"),
            artifacts = listOf("a cedar-bound commonplace book", "a brass pocket sundial", "a teacup mended with gold", "a well-worn walking stick", "a slate tablet"),
            conflicts = listOf(
                "examines how daily attention transforms ordinary labor into quiet mastery",
                "reflects on courage, restraint, and kindness amidst restless civic storms",
                "dialogues with craftspeople along a mountain road about time, memory, and gratitude",
                "collects twelve winter essays on reading slowly and listening without haste",
                "weighs ambition against contentment beneath the cypress trees of an old garden"
            ),
            authors = listOf(
                "Marcus Aurelius" to "121–180", "Michel Montaigne" to "1533–1592", "Seneca Minor" to "4 BC–65",
                "Epictetus Sage" to "50–135", "Henry Thoreau" to "1817–1862", "Ralph Emerson" to "1803–1882",
                "Hypatia Vale" to "355–415", "Kenji Takahashi" to "1898–1979", "John Lockeley" to "1632–1704",
                "Baruch Spinoza" to "1632–1677"
            ),
            tags = listOf("Mindful", "Essays", "Stoic", "Reflections")
        ),
        GenreBlueprint(
            category = "Drama",
            shelves = "Drama,Plays,Stage Classics",
            accentColors = listOf(0xFFEA580CL, 0xFF1E3A8AL, 0xFF9333EAL),
            leadMotifs = listOf(
                "Curtain Call at", "The Glass Stage of", "Winter Guests in", "Three Acts at",
                "The Orchard House in", "A Promise Before", "The Violinist of", "Shadows on",
                "The Silver Trophy at", "Last Train from"
            ),
            placeMotifs = listOf(
                "Lyceum Theatre", "Ambergris Hall", "Birchwood Manor", "the Grand Conservatory",
                "Rivergate Playhouse", "Whitechapel Stage", "St. Petersburg Square", "Vienna Salon",
                "Crown Terrace", "Old Mill Theatre"
            ),
            protagonists = listOf("Helena Vane", "Constantin Treplev", "Nora Helmer", "Victor Aldridge", "Beatrice Lane"),
            companions = listOf("Director Kroll", "Madame Ranevsky", "Brother Thomas", "Dr. Astrov", "Impresario Conti"),
            artifacts = listOf("an annotated rehearsal script", "a cracked cello bow", "an heirloom deed", "a faded theatre playbill", "a silver pocket watch"),
            conflicts = listOf(
                "confronts unspoken family debts when all three siblings return home before the estate auction",
                "rehearses an audacious final play while snow traps cast and critics inside the hall",
                "chooses between artistic integrity and a comfortable patronage offered by an old rival",
                "unravels a decades-old backstage secret on the night of the theatre's centenary revival",
                "faces truth and forgiveness across one candlelit evening at the lakeside estate"
            ),
            authors = listOf(
                "Anton Chekhovton" to "1860–1904", "Henrik Ibsenwell" to "1828–1906", "Oscar Wilding" to "1854–1900",
                "George B. Shawson" to "1856–1950", "Moliere Dupuis" to "1622–1673", "August Strind" to "1849–1912",
                "Aphra Behn" to "1640–1689", "Richard Sheridan" to "1751–1816", "Lorraine Vance" to "1905–1965",
                "Luigi Pirandello" to "1867–1936"
            ),
            tags = listOf("Stage", "Character Study", "Classic", "Emotional")
        ),
        GenreBlueprint(
            category = "Entertaining",
            shelves = "Short Stories,Fables,Folklore",
            accentColors = listOf(0xFF166EF4L, 0xFFFF6B1AL, 0xFF059669L),
            leadMotifs = listOf(
                "Tales Told at", "The Clockmaker's Shop in", "Fables from", "The Gingerbread Train of",
                "Lantern Stories of", "The Curious Baker of", "Seven Wonders near", "The Whispering Tree in",
                "Golden Keys of", "Songs and Riddles from"
            ),
            placeMotifs = listOf(
                "the Spice Market", "Cobblestone Alley", "Starlight Village", "Amber Harbor",
                "Moonbeam Valley", "Copper Bridge", "the Toymaker's Loft", "Saffron Square",
                "Fernwood Meadow", "Clockwork Row"
            ),
            protagonists = listOf("Julian Sterling", "Amina Al-Rashid", "Pippin Fox", "Lila Bell", "Master Tomas"),
            companions = listOf("a clever magpie", "the clockmaker's daughter", "Uncle Bram", "the travelling storyteller", "Captain Pip"),
            artifacts = listOf("a whistling brass kettle", "a pocketful of starlight marbles", "a map drawn on linen", "a violin with one silver string", "a carved wooden compass"),
            conflicts = listOf(
                "gathers seven unforgettable fireside stories from travelers sheltered inside a warm inn",
                "outwits a pompous merchant using three riddles and an unusually polite fox",
                "repairs a musical town clock that plays different melodies for happy and worried listeners",
                "trades tall tales around a harbor brazier while waiting for the morning tide",
                "collects miniature adventures from every corner of a bustling autumn market"
            ),
            authors = listOf(
                "Aesop Teller" to "620 BC–564 BC", "O. Henryson" to "1862–1910", "Saki Munro" to "1870–1916",
                "Andrew Langton" to "1844–1912", "Beatrix Potterly" to "1866–1943", "Hans Andersen" to "1805–1875",
                "Kenneth Grahame" to "1859–1932", "Rudyard Kiplington" to "1865–1936", "Selma Lagerlof" to "1858–1940",
                "Rabindranath Sen" to "1861–1941"
            ),
            tags = listOf("Short Read", "Fables", "Cozy", "Storytelling")
        ),
        GenreBlueprint(
            category = "Fiction",
            shelves = "Literary Fiction,Classics,Novels",
            accentColors = listOf(0xFF2563EBL, 0xFF1E7E5CL, 0xFFFF6B1AL),
            leadMotifs = listOf(
                "The Bridge Over", "House of Quiet Hours in", "The Paper Merchant of", "Years Along",
                "Portrait of", "The Glassblower's Son in", "Rain Before Dawn in", "The Bookbinder of",
                "Seasons at", "The Orchard Keepers of"
            ),
            placeMotifs = listOf(
                "Silvermere", "Alder Creek", "Old Harbor Town", "Highland Terrace",
                "Granite Crossing", "St. Claire Street", "Meadowbrook", "Northbridge",
                "the River Wharf", "Sunbury Hill"
            ),
            protagonists = listOf("Arthur Pendelton", "Clara Moreland", "David Copperwell", "Miriam Hale", "Thomas Hardyke"),
            companions = listOf("his sister Ruth", "Mr. Peggotty", "Doctor Lydgate", "Mrs. Ramsay", "Josephine Vance"),
            artifacts = listOf("a leather-bound printing ledger", "a hand-stitched quilt", "a faded family photograph", "a brass fountain pen", "a cedar writing desk"),
            conflicts = listOf(
                "rebuilds a struggling riverside press while mentoring a gifted apprentice from across town",
                "traces three generations of quiet courage, ambition, and loyalty in a changing harbor city",
                "returns to her childhood home to restore an overgrown orchard and mend old friendships",
                "chronicles a year of small triumphs and unexpected grace among neighbors on a steep cobbled street",
                "follows a young bookbinder learning both craft and character through shifting fortunes"
            ),
            authors = listOf(
                "Charles Dickenson" to "1812–1870", "George Eliotton" to "1819–1880", "Thomas Hardyman" to "1840–1928",
                "Virginia Woolfson" to "1882–1941", "Willa Catherly" to "1873–1947", "Leo Tolstoyan" to "1828–1910",
                "Anthony Trollope" to "1815–1882", "Herman Melvilleson" to "1819–1891", "Nathaniel Hawthorn" to "1804–1864",
                "Edith Whartonby" to "1862–1937"
            ),
            tags = listOf("Classic", "Literary", "Character Driven", "Timeless")
        )
    )

    fun getThousandBooks(): List<EbookEntity> {
        val books = ArrayList<EbookEntity>(1000)
        var globalIndex = 1

        for (genreIndex in blueprints.indices) {
            val bp = blueprints[genreIndex]
            for (leadIdx in bp.leadMotifs.indices) {
                for (placeIdx in bp.placeMotifs.indices) {
                    val bookNum = globalIndex++
                    val title = "${bp.leadMotifs[leadIdx]} ${bp.placeMotifs[placeIdx]}"
                    val (authorName, lifespan) = bp.authors[(leadIdx + placeIdx) % bp.authors.size]
                    val protagonist = bp.protagonists[(leadIdx * 3 + placeIdx) % bp.protagonists.size]
                    val companion = bp.companions[(leadIdx + placeIdx * 2) % bp.companions.size]
                    val artifact = bp.artifacts[(leadIdx * 2 + placeIdx) % bp.artifacts.size]
                    val conflict = bp.conflicts[(leadIdx + placeIdx) % bp.conflicts.size]
                    val place = bp.placeMotifs[placeIdx]
                    val accent = bp.accentColors[(bookNum) % bp.accentColors.size]
                    val tagA = bp.tags[leadIdx % bp.tags.size]
                    val tagB = bp.tags[(placeIdx + 1) % bp.tags.size]
                    val customTags = if (tagA == tagB) tagA else "$tagA,$tagB"
                    val popularity = 95_000 - (bookNum * 65) + ((leadIdx * 173 + placeIdx * 97) % 1200)

                    val description = "$protagonist $conflict around $place with the help of $companion and $artifact."
                    val content = buildBookChapters(
                        title = title,
                        author = authorName,
                        category = bp.category,
                        place = place,
                        protagonist = protagonist,
                        companion = companion,
                        artifact = artifact,
                        conflict = conflict,
                        seed = bookNum
                    )
                    val estimatedPages = (content.length / 1150).coerceAtLeast(6)

                    books.add(
                        EbookEntity(
                            id = "kismis_local_${bookNum.toString().padStart(4, '0')}",
                            title = title,
                            author = authorName,
                            category = bp.category,
                            description = description,
                            coverResName = null,
                            coverUrl = null,
                            textUrl = null,
                            contentText = content,
                            isDownloaded = true,
                            isBundled = true,
                            isBookmarked = false,
                            currentPage = 0,
                            totalPages = estimatedPages,
                            progressPercent = 0,
                            lastReadAt = 0L,
                            accentColorHex = accent,
                            customTags = customTags,
                            downloadCount = popularity.coerceAtLeast(1200),
                            language = "EN",
                            authorLifespan = lifespan,
                            shelves = bp.shelves
                        )
                    )
                }
            }
        }
        return books
    }

    private fun buildBookChapters(
        title: String,
        author: String,
        category: String,
        place: String,
        protagonist: String,
        companion: String,
        artifact: String,
        conflict: String,
        seed: Int
    ): String {
        val weather = listOf(
            "crisp autumn sunlight", "silver coastal mist", "steady twilight drizzle",
            "clear frost-rimmed skies", "warm amber lantern light"
        )[seed % 5]
        val timeOfDay = listOf(
            "shortly before noon", "at the stroke of five", "as the evening bells settled",
            "at first daylight", "during the quiet hour past midnight"
        )[(seed / 3) % 5]
        val moodWord = when (category) {
            "Comedy" -> "bright humor and unexpected interruptions"
            "Mystery" -> "patient deduction and closely guarded secrets"
            "Horror" -> "creeping stillness and shadows along old stonework"
            "Romance" -> "gentle glances, unspoken warmth, and patient hope"
            "Adventure" -> "wide horizons, salt wind, and steady resolve"
            "Sci-Fi" -> "crystalline precision and the wonder of distant worlds"
            "Philosophy" -> "calm inquiry, careful listening, and quiet clarity"
            "Drama" -> "candid confessions and deeply human choices"
            "Entertaining" -> "lively storytelling and delightful turns of fortune"
            else -> "enduring character and vivid human detail"
        }

        return buildString(6400) {
            appendLine("CHAPTER I: ARRIVAL AT ${place.uppercase()}")
            appendLine()
            appendLine("$title — written in the tradition of $author, filled with $moodWord.")
            appendLine()
            appendLine("It began $timeOfDay under $weather, when $protagonist stepped across the threshold of $place carrying $artifact. The air held the faint scent of cedar smoke, damp paper, and freshly brewed tea, as though the entire neighborhood had been holding its breath for a visitor.")
            appendLine()
            appendLine("$companion waited near the corner window with folded sleeves and an expression caught halfway between amusement and alarm. Beside them lay three neatly tied bundles of correspondence, an inkwell capped in brass, and a map whose margins were crowded with hurried pencil notes.")
            appendLine()
            appendLine("\"You arrived sooner than the post,\" $companion remarked, gesturing toward the wooden table. \"Everyone in $place already knows part of the story, though nobody agrees on how the affair is meant to end.\"")
            appendLine()
            appendLine("$protagonist set $artifact down beside the lamp. From that moment onward, $protagonist $conflict, knowing full well that every hour mattered.")
            appendLine()
            appendLine("CHAPTER II: THE FIRST COMPLICATION")
            appendLine()
            appendLine("By the following morning, small details refused to behave as planned. Footsteps sounded along the gravel terrace before anyone had unlocked the outer gate, and a clerk from the market brought word of an unexpected witness who insisted on speaking only before dusk.")
            appendLine()
            appendLine("Walking side by side through the narrow lanes of $place, $protagonist and $companion examined each doorway, signpost, and shop window with fresh eyes. What had seemed ordinary only a day earlier now carried subtle meaning: a shutter left unlatched by half an inch, a chime sounding twice instead of once, a receipt stamped with yesterday's date.")
            appendLine()
            appendLine("\"Notice the pattern here,\" $protagonist said quietly, tracing a finger across $artifact. \"Nothing at $place happens by pure accident. Every detour leads straight back to the same unanswered question.\"")
            appendLine()
            appendLine("$companion nodded thoughtfully, jotting down two names and a timeframe inside a pocket notebook. Overhead, church bells marked the half-hour, sending pigeons wheeling cleanly above the slate rooftops.")
            appendLine()
            appendLine("CHAPTER III: CONVERSATION BY LANTERN LIGHT")
            appendLine()
            appendLine("Evening gathered slowly around $place, turning puddles into dark mirrors and warming every frosted windowpane. Around a small cedar table, $protagonist spread out every clue, letter, and sketch gathered since sunrise, inviting $companion to challenge each assumption.")
            appendLine()
            appendLine("For nearly an hour they debated motives, distances, and forgotten promises. Twice they reached an apparent dead end; twice a seemingly trivial detail—an erased postmark, an extra spoon set out for tea, a passing phrase overheard near the harbor steps—unlocked the next link in the chain.")
            appendLine()
            appendLine("\"If we wait for certainty, tomorrow will already be too late,\" $companion urged, leaning forward into the amber glow. \"Let us test the boldest explanation first and watch who blinks.\"")
            appendLine()
            appendLine("$protagonist lifted $artifact once more and smiled. In the quiet certainty of that shared resolve, the tangled threads began at last to straighten.")
            appendLine()
            appendLine("CHAPTER IV: THE TURNING OF THE TIDE")
            appendLine()
            appendLine("Dawn broke crisp and bright across $place, bringing with it the decisive hour. Neighbors gathered along the avenue, curious murmurs rising like mist above cobblestones as $protagonist stepped forward with $companion close beside.")
            appendLine()
            appendLine("One by one, misunderstandings gave way under plain daylight. What had looked like rivalry proved to be an elaborate protective gesture; what had appeared lost beyond recovery rested safely in plain sight, waiting only for someone patient enough to ask the right question.")
            appendLine()
            appendLine("A brief hush fell over the courtyard when $artifact was placed cleanly on the marble plinth. Even the skeptics near the back row leaned closer, exchanging surprised glances as every piece settled neatly into place.")
            appendLine()
            appendLine("\"Remarkable,\" murmured the elder witness, adjusting silver spectacles. \"I have lived near $place forty winters and never once guessed the heart of the matter lay so close to home.\"")
            appendLine()
            appendLine("CHAPTER V: AFTERWARD AND QUIET HARBOR")
            appendLine()
            appendLine("Long after the crowd dispersed and ordinary routines resumed around $place, $protagonist and $companion lingered beside the open terrace watching $weather soften the distant roofline.")
            appendLine()
            appendLine("Tea cooled undisturbed in two porcelain cups. $artifact now rested quietly upon the shelf—no longer an urgent puzzle or burden, but a keepsake reminding them both how swiftly strangers become lifelong allies when curiosity meets courage.")
            appendLine()
            appendLine("\"Do you think anyone will write all this down someday?\" $companion asked softly.")
            appendLine()
            appendLine("$protagonist closed the leather ledger with a gentle click. \"Only if they leave room on the final page for the next journey.\"")
        }
    }
}
