package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kismis_prefs")

enum class ReaderPaperMode(val label: String) {
    AUTO("Match App"),
    WHITE("White"),
    SEPIA("Sepia"),
    DARK("Dark")
}

enum class ReaderFontStyle(val label: String) {
    SERIF("Lora Serif"),
    SANS("Jakarta Sans"),
    DISPLAY("Playfair")
}

enum class PageTurnMode(val label: String) {
    HORIZONTAL_PAGER("Swipe Pages"),
    VERTICAL_SCROLL("Scroll")
}

enum class PerformanceMode(val label: String) {
    AUTO("Auto"),
    LITE("Lite (Low RAM)"),
    FULL("Full Effects")
}

data class ReaderPreferencesState(
    val themeMode: AppThemeMode = AppThemeMode.LIGHT,
    val readerPaperMode: ReaderPaperMode = ReaderPaperMode.AUTO,
    val fontSizeSp: Float = 18f,
    val lineHeightMultiplier: Float = 1.62f,
    val readerFontStyle: ReaderFontStyle = ReaderFontStyle.SERIF,
    val pageTurnMode: PageTurnMode = PageTurnMode.HORIZONTAL_PAGER,
    val blurIntensity: Float = 1.0f,
    val performanceMode: PerformanceMode = PerformanceMode.AUTO
)

class ReaderPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PAPER_MODE = stringPreferencesKey("paper_mode")
        val FONT_SIZE = floatPreferencesKey("font_size")
        val LINE_HEIGHT = floatPreferencesKey("line_height")
        val FONT_STYLE = stringPreferencesKey("font_style")
        val PAGE_TURN_MODE = stringPreferencesKey("page_turn_mode")
        val BLUR_INTENSITY = floatPreferencesKey("blur_intensity")
        val PERFORMANCE_MODE = stringPreferencesKey("performance_mode")
    }

    val preferencesFlow: Flow<ReaderPreferencesState> = context.dataStore.data.map { prefs ->
        ReaderPreferencesState(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { AppThemeMode.valueOf(it) }.getOrNull() }
                ?: AppThemeMode.LIGHT,
            readerPaperMode = prefs[Keys.PAPER_MODE]?.let { runCatching { ReaderPaperMode.valueOf(it) }.getOrNull() }
                ?: ReaderPaperMode.AUTO,
            fontSizeSp = prefs[Keys.FONT_SIZE] ?: 18f,
            lineHeightMultiplier = prefs[Keys.LINE_HEIGHT] ?: 1.62f,
            readerFontStyle = prefs[Keys.FONT_STYLE]?.let { runCatching { ReaderFontStyle.valueOf(it) }.getOrNull() }
                ?: ReaderFontStyle.SERIF,
            pageTurnMode = prefs[Keys.PAGE_TURN_MODE]?.let { runCatching { PageTurnMode.valueOf(it) }.getOrNull() }
                ?: PageTurnMode.HORIZONTAL_PAGER,
            blurIntensity = prefs[Keys.BLUR_INTENSITY] ?: 1.0f,
            performanceMode = prefs[Keys.PERFORMANCE_MODE]?.let { runCatching { PerformanceMode.valueOf(it) }.getOrNull() }
                ?: PerformanceMode.AUTO
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setReaderPaperMode(mode: ReaderPaperMode) {
        context.dataStore.edit { it[Keys.PAPER_MODE] = mode.name }
    }

    suspend fun setFontSize(sizeSp: Float) {
        context.dataStore.edit { it[Keys.FONT_SIZE] = sizeSp.coerceIn(13f, 28f) }
    }

    suspend fun setLineHeight(multiplier: Float) {
        context.dataStore.edit { it[Keys.LINE_HEIGHT] = multiplier.coerceIn(1.25f, 2.1f) }
    }

    suspend fun setReaderFontStyle(style: ReaderFontStyle) {
        context.dataStore.edit { it[Keys.FONT_STYLE] = style.name }
    }

    suspend fun setPageTurnMode(mode: PageTurnMode) {
        context.dataStore.edit { it[Keys.PAGE_TURN_MODE] = mode.name }
    }

    suspend fun setBlurIntensity(intensity: Float) {
        context.dataStore.edit { it[Keys.BLUR_INTENSITY] = intensity.coerceIn(0.3f, 1.4f) }
    }

    suspend fun setPerformanceMode(mode: PerformanceMode) {
        context.dataStore.edit { it[Keys.PERFORMANCE_MODE] = mode.name }
    }
}
