package com.example.data.local

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Compressed disk store for synced offline e-book texts (`filesDir/offline_books/<id>.txt.gz`).
 * Keeps full book texts out of SQLite rows during 1,000+ book syncs to avoid CursorWindow
 * limits, reduce storage footprint by ~70%, and maintain fast Room query performance.
 */
class OfflineBookStorage(context: Context) {

    private val rootDir: File = File(context.filesDir, "offline_books").apply {
        if (!exists()) mkdirs()
    }

    private fun safeId(bookId: String): String {
        return bookId.replace(Regex("[^a-zA-Z0-9._-]"), "_")
    }

    private fun targetFile(bookId: String): File = File(rootDir, "${safeId(bookId)}.txt.gz")

    fun saveBookText(bookId: String, text: String): Long {
        if (!rootDir.exists()) rootDir.mkdirs()
        val finalFile = targetFile(bookId)
        val tmpFile = File(rootDir, "${safeId(bookId)}.tmp.gz")
        GZIPOutputStream(FileOutputStream(tmpFile)).bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.write(text)
        }
        if (finalFile.exists()) {
            finalFile.delete()
        }
        if (!tmpFile.renameTo(finalFile)) {
            tmpFile.copyTo(finalFile, overwrite = true)
            tmpFile.delete()
        }
        return finalFile.length()
    }

    fun readBookText(bookId: String): String? {
        val file = targetFile(bookId)
        if (!file.exists() || file.length() == 0L) return null
        return runCatching {
            GZIPInputStream(FileInputStream(file)).bufferedReader(Charsets.UTF_8).use { reader ->
                reader.readText()
            }
        }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    fun hasBookText(bookId: String): Boolean {
        val file = targetFile(bookId)
        return file.exists() && file.length() > 32L
    }

    fun deleteBookText(bookId: String) {
        runCatching {
            val file = targetFile(bookId)
            if (file.exists()) file.delete()
        }
    }

    fun getTotalStorageBytes(): Long {
        val files = rootDir.listFiles() ?: return 0L
        var total = 0L
        for (file in files) {
            if (file.isFile && file.name.endsWith(".txt.gz")) {
                total += file.length()
            }
        }
        return total
    }

    fun clearAll() {
        rootDir.listFiles()?.forEach { file ->
            runCatching { file.delete() }
        }
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0L) return "0 MB"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 100.0 -> String.format(Locale.US, "%.0f MB", mb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb.coerceAtLeast(1.0))
            }
        }
    }
}
