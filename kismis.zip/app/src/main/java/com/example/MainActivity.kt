package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.AmbientGlassBackdrop
import com.example.ui.components.FloatingFrostedBottomBar
import com.example.ui.components.FloatingFrostedNavigationRail
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ReaderScreen
import com.example.ui.screens.SearchOverlay
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.KismisTheme
import com.example.ui.viewmodel.KismisViewModel
import com.example.ui.viewmodel.MainTab
import kotlinx.coroutines.delay

private const val ROUTE_MAIN = "main"
private const val ROUTE_READER = "reader/{bookId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KismisViewModel = viewModel()
            KismisApp(viewModel = viewModel)
        }
    }
}

@Composable
fun KismisApp(viewModel: KismisViewModel) {
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()
    val isLiteMode by viewModel.isLiteMode.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val navController = rememberNavController()

    val systemDark = isSystemInDarkTheme()
    val isEffectiveDark = when (preferences.themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> systemDark
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    KismisTheme(themeMode = preferences.themeMode, isLiteMode = isLiteMode) {
        Box(modifier = Modifier.fillMaxSize()) {
            NavHost(
                navController = navController,
                startDestination = ROUTE_MAIN,
                enterTransition = { fadeIn(tween(if (isLiteMode) 0 else 200)) },
                exitTransition = { fadeOut(tween(if (isLiteMode) 0 else 160)) }
            ) {
                composable(ROUTE_MAIN) {
                    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
                    val isSearchOverlayOpen by viewModel.isSearchOverlayOpen.collectAsStateWithLifecycle()

                    val openSearch = remember(viewModel) { { viewModel.openSearchOverlay(true) } }
                    val closeSearch = remember(viewModel) { { viewModel.openSearchOverlay(false) } }
                    val openBook = remember(viewModel, navController) {
                        { book: com.example.data.local.EbookEntity ->
                            viewModel.openBookForReading(book) { bookId ->
                                navController.navigate("reader/${Uri.encode(bookId)}")
                            }
                        }
                    }

                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val isTablet = maxWidth >= 600.dp
                        val contentBottomInset = if (isTablet) 24.dp else 118.dp

                        AmbientGlassBackdrop(blurIntensity = preferences.blurIntensity)

                        val mainContent: @Composable () -> Unit = {
                            FastTabContainer(
                                selectedTab = selectedTab,
                                isLiteMode = isLiteMode,
                                modifier = Modifier.fillMaxSize()
                            ) { tab ->
                                when (tab) {
                                    MainTab.HOME -> {
                                        val homeState by viewModel.homeState.collectAsStateWithLifecycle()
                                        HomeScreen(
                                            state = homeState,
                                            isDarkTheme = isEffectiveDark,
                                            bottomNavInset = contentBottomInset,
                                            onToggleTheme = viewModel::toggleLightDarkTheme,
                                            onSearchQueryChange = viewModel::onSearchQueryChanged,
                                            onToggleFilterExpanded = viewModel::toggleFilterExpanded,
                                            onCategorySelected = viewModel::onCategorySelected,
                                            onLanguageSelected = viewModel::onLanguageSelected,
                                            onRefreshOnline = { viewModel.refreshOnlineCatalog() },
                                            onLoadMoreOnline = viewModel::loadMoreOnlineCatalog,
                                            onUnlockThousandBooks = viewModel::unlockThousandBooksCatalog,
                                            onPauseOfflineSync = viewModel::pauseOfflineSync,
                                            onDownloadOffline = viewModel::downloadBookOffline,
                                            onBookClick = openBook,
                                            onToggleBookmark = viewModel::toggleBookmark
                                        )
                                    }

                                    MainTab.LIBRARY -> {
                                        val downloadedBooks by viewModel.downloadedBooks.collectAsStateWithLifecycle()
                                        val bookmarkedBooks by viewModel.bookmarkedBooks.collectAsStateWithLifecycle()
                                        val allCustomTags by viewModel.allCustomTags.collectAsStateWithLifecycle()
                                        val offlineSyncState by viewModel.offlineSyncState.collectAsStateWithLifecycle()
                                        LibraryScreen(
                                            downloadedBooks = downloadedBooks,
                                            bookmarkedBooks = bookmarkedBooks,
                                            allCustomTags = allCustomTags,
                                            offlineSyncState = offlineSyncState,
                                            bottomNavInset = contentBottomInset,
                                            onBookClick = openBook,
                                            onRemoveDownload = viewModel::removeBookFromDownloads,
                                            onToggleBookmark = viewModel::toggleBookmark,
                                            onUpdateBookTags = viewModel::updateBookTags,
                                            onUpdateBookCategory = viewModel::updateBookCategory,
                                            onImportTextFile = viewModel::importLocalTextFile,
                                            onStartOfflineSync = viewModel::startOfflineThousandSync,
                                            onPauseOfflineSync = viewModel::pauseOfflineSync
                                        )
                                    }

                                    MainTab.SETTINGS -> {
                                        val offlineSyncState by viewModel.offlineSyncState.collectAsStateWithLifecycle()
                                        SettingsScreen(
                                            preferences = preferences,
                                            isHardwareLowRam = viewModel.isHardwareLowRam,
                                            offlineSyncState = offlineSyncState,
                                            bottomNavInset = contentBottomInset,
                                            onThemeModeSelected = viewModel::setThemeMode,
                                            onPaperModeSelected = viewModel::setReaderPaperMode,
                                            onFontSizeChange = viewModel::setFontSize,
                                            onLineHeightChange = viewModel::setLineHeight,
                                            onFontStyleSelected = viewModel::setReaderFontStyle,
                                            onPageTurnModeSelected = viewModel::setPageTurnMode,
                                            onBlurIntensityChange = viewModel::setBlurIntensity,
                                            onPerformanceModeSelected = viewModel::setPerformanceMode,
                                            onStartOfflineSync = viewModel::startOfflineThousandSync,
                                            onPauseOfflineSync = viewModel::pauseOfflineSync,
                                            onClearCache = viewModel::clearUnusedCache
                                        )
                                    }
                                }
                            }
                        }

                        if (isTablet) {
                            Row(modifier = Modifier.fillMaxSize()) {
                                FloatingFrostedNavigationRail(
                                    selectedTab = selectedTab,
                                    onTabSelected = viewModel::selectTab,
                                    onSearchClick = openSearch
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                ) {
                                    mainContent()
                                }
                            }
                        } else {
                            mainContent()

                            FloatingFrostedBottomBar(
                                selectedTab = selectedTab,
                                onTabSelected = viewModel::selectTab,
                                onSearchClick = openSearch,
                                modifier = Modifier.align(Alignment.BottomCenter)
                            )
                        }

                        AnimatedVisibility(
                            visible = isSearchOverlayOpen,
                            enter = slideInVertically(tween(if (isLiteMode) 0 else 210)) { it / 5 } +
                                fadeIn(tween(if (isLiteMode) 0 else 190)),
                            exit = slideOutVertically(tween(if (isLiteMode) 0 else 170)) { it / 5 } +
                                fadeOut(tween(if (isLiteMode) 0 else 150))
                        ) {
                            val homeState by viewModel.homeState.collectAsStateWithLifecycle()
                            SearchOverlay(
                                state = homeState,
                                onQueryChange = viewModel::onSearchQueryChanged,
                                onCategorySelected = viewModel::onCategorySelected,
                                onBookClick = openBook,
                                onClose = closeSearch
                            )
                        }
                    }
                }

                composable(
                    route = ROUTE_READER,
                    arguments = listOf(navArgument("bookId") { type = NavType.StringType }),
                    enterTransition = {
                        val dur = if (isLiteMode) 80 else 220
                        slideInHorizontally(
                            animationSpec = tween(dur, easing = FastOutSlowInEasing),
                            initialOffsetX = { it / 6 }
                        ) + fadeIn(tween(dur))
                    },
                    exitTransition = {
                        val dur = if (isLiteMode) 60 else 170
                        fadeOut(tween(dur))
                    },
                    popEnterTransition = {
                        val dur = if (isLiteMode) 60 else 170
                        fadeIn(tween(dur))
                    },
                    popExitTransition = {
                        val dur = if (isLiteMode) 80 else 200
                        slideOutHorizontally(
                            animationSpec = tween(dur, easing = FastOutSlowInEasing),
                            targetOffsetX = { it / 6 }
                        ) + fadeOut(tween(dur))
                    }
                ) { backStackEntry ->
                    val bookId = Uri.decode(backStackEntry.arguments?.getString("bookId") ?: "")
                    val readerState by viewModel.readerState.collectAsStateWithLifecycle()
                    val ttsState by viewModel.ttsState.collectAsStateWithLifecycle()

                    LaunchedEffect(bookId) {
                        if (bookId.isNotBlank()) {
                            viewModel.loadBookInReaderIfNeeded(bookId)
                        }
                    }
                    ReaderScreen(
                        readerState = readerState,
                        preferences = preferences,
                        ttsState = ttsState,
                        isAppDark = isEffectiveDark,
                        onBack = { navController.popBackStack() },
                        onPageChanged = viewModel::onReaderPageChanged,
                        onToggleBookmark = viewModel::toggleBookmark,
                        onPaperModeChange = viewModel::setReaderPaperMode,
                        onFontSizeChange = viewModel::setFontSize,
                        onLineHeightChange = viewModel::setLineHeight,
                        onFontStyleChange = viewModel::setReaderFontStyle,
                        onPageTurnModeChange = viewModel::setPageTurnMode,
                        onPlayBookFromCurrentPage = viewModel::startTtsFromCurrentPage,
                        onPlaySelectedPassage = viewModel::startTtsForSelection,
                        onToggleTtsPlayPause = viewModel::toggleTtsPlayPause,
                        onSkipNextSentence = viewModel::skipTtsNextSentence,
                        onSkipPreviousSentence = viewModel::skipTtsPreviousSentence,
                        onSkipNextParagraph = viewModel::skipTtsNextParagraph,
                        onSkipPreviousParagraph = viewModel::skipTtsPreviousParagraph,
                        onStopTts = viewModel::stopTts,
                        onTtsRateChange = viewModel::setTtsSpeechRate,
                        onTtsPitchChange = viewModel::setTtsSpeechPitch,
                        onApplyTtsPreset = viewModel::applyTtsPreset,
                        onPreviewTtsVoice = viewModel::previewTtsVoice,
                        onSetTtsSleepTimer = viewModel::setTtsSleepTimer,
                        onSelectTtsVoice = viewModel::selectTtsVoice
                    )
                }
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 86.dp)
            )
        }
    }
}

/**
 * Keeps visited tab destinations alive in the Compose slot table so switching
 * between Home, Library, and Settings preserves scroll positions and skips
 * costly tree teardown/recreation. Inactive settled tabs are omitted from layout
 * placement so they incur zero GPU draw cost, pointer interception, or semantics work.
 */
@Composable
private fun FastTabContainer(
    selectedTab: MainTab,
    isLiteMode: Boolean,
    modifier: Modifier = Modifier,
    tabContent: @Composable (MainTab) -> Unit
) {
    val density = LocalDensity.current
    val slideOffsetPx = with(density) { (if (isLiteMode) 0.dp else 24.dp).toPx() }

    val visitedTabs = remember {
        mutableStateMapOf(
            MainTab.HOME to true,
            selectedTab to true
        )
    }

    LaunchedEffect(selectedTab) {
        visitedTabs[selectedTab] = true
    }

    // Pre-warm Library & Settings once shortly after launch on standard devices
    // so the very first switch to Library or Settings opens instantaneously.
    LaunchedEffect(isLiteMode) {
        if (!isLiteMode) {
            delay(140L)
            visitedTabs[MainTab.LIBRARY] = true
            delay(80L)
            visitedTabs[MainTab.SETTINGS] = true
        }
    }

    var lastTabOrdinal by remember { mutableIntStateOf(selectedTab.ordinal) }
    var slideDirection by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(selectedTab) {
        val targetOrdinal = selectedTab.ordinal
        if (targetOrdinal != lastTabOrdinal) {
            slideDirection = if (targetOrdinal > lastTabOrdinal) 1f else -1f
            lastTabOrdinal = targetOrdinal
        }
    }

    val animDuration = if (isLiteMode) 75 else 175

    Box(modifier = modifier) {
        MainTab.entries.forEach { tab ->
            if (visitedTabs[tab] == true) {
                val isSelected = tab == selectedTab
                val progress by animateFloatAsState(
                    targetValue = if (isSelected) 1f else 0f,
                    animationSpec = tween(
                        durationMillis = animDuration,
                        easing = FastOutSlowInEasing
                    ),
                    label = "fast_tab_${tab.name}"
                )

                val translationX = if (isSelected) {
                    (1f - progress) * slideOffsetPx * slideDirection
                } else {
                    -(1f - progress) * slideOffsetPx * slideDirection
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .zIndex(if (isSelected) 1f else 0f)
                        .layout { measurable, constraints ->
                            if (isSelected || progress > 0.01f) {
                                val placeable = measurable.measure(constraints)
                                layout(placeable.width, placeable.height) {
                                    placeable.placeRelativeWithLayer(0, 0) {
                                        alpha = progress
                                        this.translationX = translationX
                                    }
                                }
                            } else {
                                layout(
                                    if (constraints.hasBoundedWidth) constraints.maxWidth else 0,
                                    if (constraints.hasBoundedHeight) constraints.maxHeight else 0
                                ) {}
                            }
                        }
                ) {
                    tabContent(tab)
                }
            }
        }
    }
}

