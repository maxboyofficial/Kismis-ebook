package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.FormatSize
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.local.PageTurnMode
import com.example.data.local.PerformanceMode
import com.example.data.local.ReaderFontStyle
import com.example.data.local.ReaderPaperMode
import com.example.data.local.ReaderPreferencesState
import com.example.data.repository.OfflineSyncState
import com.example.ui.components.FrostedGlassSurface
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LocalKismisGlassColors
import com.example.ui.theme.PlayfairDisplayFamily

@Composable
fun SettingsScreen(
    preferences: ReaderPreferencesState,
    isHardwareLowRam: Boolean = false,
    offlineSyncState: OfflineSyncState = OfflineSyncState(),
    bottomNavInset: Dp = 112.dp,
    onThemeModeSelected: (AppThemeMode) -> Unit,
    onPaperModeSelected: (ReaderPaperMode) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onLineHeightChange: (Float) -> Unit,
    onFontStyleSelected: (ReaderFontStyle) -> Unit,
    onPageTurnModeSelected: (PageTurnMode) -> Unit,
    onBlurIntensityChange: (Float) -> Unit,
    onPerformanceModeSelected: (PerformanceMode) -> Unit = {},
    onStartOfflineSync: () -> Unit = {},
    onPauseOfflineSync: () -> Unit = {},
    onClearCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val cardWidthModifier = Modifier.widthIn(max = 720.dp).fillMaxWidth()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = bottomNavInset),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(modifier = cardWidthModifier) {
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontFamily = PlayfairDisplayFamily
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Customize themes, frosted glass depth & reading typography",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Theme Mode (White & Dark!)
        item {
            FrostedGlassSurface(
                modifier = cardWidthModifier,
                shape = RoundedCornerShape(24.dp),
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Palette,
                            contentDescription = null,
                            tint = glass.brandBlue
                        )
                        Text(
                            text = "App Theme (White / Dark)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppThemeMode.entries.forEach { mode ->
                            val selected = mode == preferences.themeMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlue else glass.glassSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (selected) glass.brandBlue else glass.glassBorderEnd,
                                        CircleShape
                                    )
                                    .minimumInteractiveComponentSize()
                                    .clickable { onThemeModeSelected(mode) }
                                    .padding(vertical = 10.dp)
                                    .testTag("settings_theme_${mode.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (mode == AppThemeMode.LIGHT) {
                                        Icon(
                                            Icons.Rounded.LightMode,
                                            contentDescription = null,
                                            tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    } else if (mode == AppThemeMode.DARK) {
                                        Icon(
                                            Icons.Rounded.DarkMode,
                                            contentDescription = null,
                                            tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = mode.label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    // Frosted Blur Intensity
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = glass.brandBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Frosted Glass Blur",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "${(preferences.blurIntensity * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = glass.brandBlue
                            )
                        }
                        Slider(
                            value = preferences.blurIntensity,
                            onValueChange = onBlurIntensityChange,
                            valueRange = 0.3f..1.4f,
                            colors = SliderDefaults.colors(
                                thumbColor = glass.brandBlue,
                                activeTrackColor = glass.brandBlue
                            )
                        )
                    }
                }
            }
        }

        // Reading Typography & Paper Defaults
        item {
            FrostedGlassSurface(
                modifier = cardWidthModifier,
                shape = RoundedCornerShape(24.dp),
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FormatSize,
                            contentDescription = null,
                            tint = glass.brandBlue
                        )
                        Text(
                            text = "Reader Defaults",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Font Size
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Font Size", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "${preferences.fontSizeSp.toInt()} sp",
                                style = MaterialTheme.typography.labelMedium,
                                color = glass.brandBlue
                            )
                        }
                        Slider(
                            value = preferences.fontSizeSp,
                            onValueChange = onFontSizeChange,
                            valueRange = 14f..26f,
                            colors = SliderDefaults.colors(
                                thumbColor = glass.brandBlue,
                                activeTrackColor = glass.brandBlue
                            )
                        )
                    }

                    // Line Spacing
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Line Spacing", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                String.format("%.2fx", preferences.lineHeightMultiplier),
                                style = MaterialTheme.typography.labelMedium,
                                color = glass.brandBlue
                            )
                        }
                        Slider(
                            value = preferences.lineHeightMultiplier,
                            onValueChange = onLineHeightChange,
                            valueRange = 1.3f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = glass.brandBlue,
                                activeTrackColor = glass.brandBlue
                            )
                        )
                    }

                    // Font Style
                    Text("Typeface", style = MaterialTheme.typography.bodyMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReaderFontStyle.entries.forEach { style ->
                            val selected = style == preferences.readerFontStyle
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlueSoft else glass.glassSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (selected) glass.brandBlue else glass.glassBorderEnd,
                                        CircleShape
                                    )
                                    .minimumInteractiveComponentSize()
                                    .clickable { onFontStyleSelected(style) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = style.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) glass.brandBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Reader Paper Tone
                    Text("Reader Paper Surface", style = MaterialTheme.typography.bodyMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReaderPaperMode.entries.forEach { paper ->
                            val selected = paper == preferences.readerPaperMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlueSoft else glass.glassSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (selected) glass.brandBlue else glass.glassBorderEnd,
                                        CircleShape
                                    )
                                    .minimumInteractiveComponentSize()
                                    .clickable { onPaperModeSelected(paper) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = paper.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) glass.brandBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Page turn mode
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Swipe,
                            contentDescription = null,
                            tint = glass.brandBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Text("Page Turn Style", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PageTurnMode.entries.forEach { turnMode ->
                            val selected = turnMode == preferences.pageTurnMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlue else glass.glassSurfaceElevated)
                                    .minimumInteractiveComponentSize()
                                    .clickable { onPageTurnModeSelected(turnMode) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = turnMode.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Performance & Low-RAM Optimization
        item {
            FrostedGlassSurface(
                modifier = cardWidthModifier,
                shape = RoundedCornerShape(24.dp),
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Memory,
                                contentDescription = null,
                                tint = glass.brandOrange
                            )
                            Text(
                                text = "Performance & Memory",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (isHardwareLowRam) glass.brandOrangeSoft else glass.brandBlueSoft)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isHardwareLowRam) "Low-RAM Device" else "Standard RAM",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isHardwareLowRam) glass.brandOrange else glass.brandBlue
                            )
                        }
                    }

                    Text(
                        text = "Lite Mode trims heavy shadows, animations, and thumbnail memory for smooth 60fps reading on low-RAM & older phones.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PerformanceMode.entries.forEach { mode ->
                            val selected = mode == preferences.performanceMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandOrange else glass.glassSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (selected) glass.brandOrange else glass.glassBorderEnd,
                                        CircleShape
                                    )
                                    .minimumInteractiveComponentSize()
                                    .clickable { onPerformanceModeSelected(mode) }
                                    .padding(vertical = 10.dp)
                                    .testTag("settings_perf_${mode.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Built-In Local e-Book Database
        item {
            val readyCount = offlineSyncState.offlineReadyCount.coerceAtLeast(1008)
            FrostedGlassSurface(
                modifier = cardWidthModifier.testTag("settings_offline_sync_card"),
                shape = RoundedCornerShape(24.dp),
                contentPadding = 16.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DownloadDone,
                        contentDescription = null,
                        tint = glass.brandBlue
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Built-In Local e-Book Database",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "$readyCount built-in offline e-books stored in app database — zero internet needed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Catalog & Cache
        item {
            FrostedGlassSurface(
                modifier = cardWidthModifier.testTag("clear_cache_card"),
                shape = RoundedCornerShape(24.dp),
                onClick = onClearCache,
                contentPadding = 16.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Clear Unused Cache",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Keeps all 1,008+ built-in, bookmarked & saved books safe",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.CleaningServices,
                        contentDescription = "Clear cache",
                        tint = glass.brandBlue
                    )
                }
            }
        }
    }
}
