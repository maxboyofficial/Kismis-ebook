package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kismis Signature Brand Palette — Cobalt Blue & Sunset Orange
val KismisBlueLight = Color(0xFF166EF4)
val KismisBlueDark = Color(0xFF4C91FF)
val KismisBlueSoftLight = Color(0xFFE3EEFF)
val KismisBlueSoftDark = Color(0xFF15294A)

val KismisOrangeLight = Color(0xFFFF6B1A)
val KismisOrangeDark = Color(0xFFFF883D)
val KismisOrangeSoftLight = Color(0xFFFFEDE2)
val KismisOrangeSoftDark = Color(0xFF3E2212)

// Light (White) Theme Palette — Crisp Paper
val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFECEFF6)
val LightTextPrimary = Color(0xFF10131A)
val LightTextSecondary = Color(0xFF475063)
val LightOutline = Color(0xFF182030)

// Dark Theme Palette — Obsidian Glass
val DarkBackground = Color(0xFF0A0D14)
val DarkSurface = Color(0xFF121621)
val DarkSurfaceVariant = Color(0xFF1D2333)
val DarkTextPrimary = Color(0xFFF4F6FB)
val DarkTextSecondary = Color(0xFFB3BDCE)
val DarkOutline = Color(0xFF2B344A)

// Reader Paper Tones
val ReaderWhiteBg = Color(0xFFFCFDFE)
val ReaderWhiteText = Color(0xFF151820)
val ReaderSepiaBg = Color(0xFFF8F0DF)
val ReaderSepiaText = Color(0xFF3A2E21)
val ReaderDarkBg = Color(0xFF0D1018)
val ReaderDarkText = Color(0xFFE6EAF3)

// Ambient Orb Colors (Blue & Orange)
val LightOrbBlue = Color(0x2B166EF4)
val LightOrbOrange = Color(0x26FF6B1A)
val LightOrbSky = Color(0x1E38BDF8)

val DarkOrbBlue = Color(0x383B82F6)
val DarkOrbOrange = Color(0x2EFF7A2F)
val DarkOrbIndigo = Color(0x246366F1)
