package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import android.view.HapticFeedbackConstants
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.LibraryBooks
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.EbookEntity
import com.example.data.repository.OfflineSyncState
import com.example.ui.components.BookCoverView
import com.example.ui.components.FrostedGlassSurface
import com.example.ui.theme.LocalKismisGlassColors
import com.example.ui.theme.PlayfairDisplayFamily

private enum class LibraryOrgMode(val label: String, val icon: ImageVector) {
    ALL("All Books", Icons.Rounded.LibraryBooks),
    BOOKMARKS("Bookmarks", Icons.Rounded.Bookmark),
    GENRE("By Genre", Icons.Rounded.Category),
    AUTHOR("By Author", Icons.Rounded.Person),
    TAGS("Custom Tags", Icons.AutoMirrored.Rounded.Label)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LibraryScreen(
    downloadedBooks: List<EbookEntity>,
    bookmarkedBooks: List<EbookEntity>,
    allCustomTags: List<String>,
    offlineSyncState: OfflineSyncState = OfflineSyncState(),
    bottomNavInset: Dp = 118.dp,
    onBookClick: (EbookEntity) -> Unit,
    onRemoveDownload: (EbookEntity) -> Unit,
    onToggleBookmark: (EbookEntity) -> Unit,
    onUpdateBookTags: (EbookEntity, List<String>) -> Unit,
    onUpdateBookCategory: (EbookEntity, String) -> Unit,
    onImportTextFile: (Uri, String) -> Unit,
    onStartOfflineSync: () -> Unit = {},
    onPauseOfflineSync: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val context = LocalContext.current
    val view = LocalView.current

    var orgMode by remember { mutableStateOf(LibraryOrgMode.ALL) }
    var selectedGenreFilter by remember { mutableStateOf<String?>(null) }
    var selectedAuthorFilter by remember { mutableStateOf<String?>(null) }
    var selectedTagFilter by remember { mutableStateOf<String?>(null) }
    var organizingBook by remember { mutableStateOf<EbookEntity?>(null) }

    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val fileName = runCatching {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
                }
            }.getOrNull() ?: "Imported Book"
            onImportTextFile(uri, fileName)
        }
    }

    val allGenres = remember(downloadedBooks) {
        downloadedBooks.map { it.category }.distinct().sorted()
    }
    val allAuthors = remember(downloadedBooks) {
        downloadedBooks.map { it.author }.distinct().sorted()
    }

    val filteredBooks = remember(
        orgMode,
        downloadedBooks,
        bookmarkedBooks,
        selectedGenreFilter,
        selectedAuthorFilter,
        selectedTagFilter
    ) {
        when (orgMode) {
            LibraryOrgMode.ALL -> downloadedBooks
            LibraryOrgMode.BOOKMARKS -> bookmarkedBooks
            LibraryOrgMode.GENRE -> if (selectedGenreFilter == null) {
                downloadedBooks
            } else {
                downloadedBooks.filter { it.category.equals(selectedGenreFilter, ignoreCase = true) }
            }
            LibraryOrgMode.AUTHOR -> if (selectedAuthorFilter == null) {
                downloadedBooks
            } else {
                downloadedBooks.filter { it.author.equals(selectedAuthorFilter, ignoreCase = true) }
            }
            LibraryOrgMode.TAGS -> if (selectedTagFilter == null) {
                downloadedBooks.filter { it.tagList().isNotEmpty() }
            } else {
                downloadedBooks.filter { book ->
                    book.tagList().any { it.equals(selectedTagFilter, ignoreCase = true) }
                }
            }
        }
    }

    val groupedSections: List<Pair<String, List<EbookEntity>>> = remember(orgMode, filteredBooks) {
        when (orgMode) {
            LibraryOrgMode.GENRE -> filteredBooks
                .groupBy { it.category }
                .entries
                .sortedBy { it.key }
                .map { it.key to it.value }
            LibraryOrgMode.AUTHOR -> filteredBooks
                .groupBy { it.author }
                .entries
                .sortedBy { it.key }
                .map { it.key to it.value }
            else -> emptyList()
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val gridColumns = if (maxWidth >= 640.dp) 2 else 1

        LazyVerticalGrid(
            columns = GridCells.Fixed(gridColumns),
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = bottomNavInset),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { GridItemSpan(gridColumns) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Your Library",
                            style = MaterialTheme.typography.displaySmall.copy(
                                fontFamily = PlayfairDisplayFamily
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Organize by genre, author & custom tags",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    FrostedGlassSurface(
                        modifier = Modifier
                            .height(44.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("import_txt_button"),
                        shape = CircleShape,
                        elevated = true,
                        onClick = { openDocLauncher.launch(arrayOf("text/plain")) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FileOpen,
                                contentDescription = "Import text e-book",
                                tint = glass.brandOrange,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Import .TXT",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = glass.brandBlue
                            )
                        }
                    }
                }
            }

            // Stats Summary + Offline 1,000+ Archive Bar
            item(span = { GridItemSpan(gridColumns) }) {
                FrostedGlassSurface(
                    modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    contentPadding = 16.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            StatColumn(value = downloadedBooks.size.toString(), label = "Offline")
                            StatColumn(value = allGenres.size.toString(), label = "Genres")
                            StatColumn(value = allCustomTags.size.toString(), label = "Tags")
                            StatColumn(value = bookmarkedBooks.size.toString(), label = "Saved")
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(glass.brandBlueSoft)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DownloadDone,
                                contentDescription = null,
                                tint = glass.brandBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${downloadedBooks.size} Offline e-Books Ready",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Built directly into app database • No internet required",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Dynamic Organization Mode Bar
            item(span = { GridItemSpan(gridColumns) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LibraryOrgMode.entries.forEach { mode ->
                        val active = mode == orgMode
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (active) glass.brandBlue else glass.glassSurfaceElevated)
                                .border(
                                    1.1.dp,
                                    if (active) glass.brandBlue else glass.glassBorderStart,
                                    CircleShape
                                )
                                .minimumInteractiveComponentSize()
                                .clickable {
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                    orgMode = mode
                                }
                                .padding(horizontal = 14.dp, vertical = 9.dp)
                                .testTag("library_org_${mode.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = mode.icon,
                                    contentDescription = null,
                                    tint = if (active) Color.White else glass.brandBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold
                                    ),
                                    color = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Sub-filter pills for By Genre, By Author, Custom Tags
            item(span = { GridItemSpan(gridColumns) }) {
                AnimatedVisibility(visible = orgMode == LibraryOrgMode.GENRE && allGenres.isNotEmpty()) {
                    SubFilterChipsRow(
                        items = allGenres,
                        selectedItem = selectedGenreFilter,
                        allLabel = "All Genres",
                        onSelect = { selectedGenreFilter = it }
                    )
                }
                AnimatedVisibility(visible = orgMode == LibraryOrgMode.AUTHOR && allAuthors.isNotEmpty()) {
                    SubFilterChipsRow(
                        items = allAuthors,
                        selectedItem = selectedAuthorFilter,
                        allLabel = "All Authors",
                        onSelect = { selectedAuthorFilter = it }
                    )
                }
                AnimatedVisibility(visible = orgMode == LibraryOrgMode.TAGS) {
                    SubFilterChipsRow(
                        items = allCustomTags,
                        selectedItem = selectedTagFilter,
                        allLabel = "All Tagged",
                        onSelect = { selectedTagFilter = it }
                    )
                }
            }

            if (filteredBooks.isEmpty()) {
                item(span = { GridItemSpan(gridColumns) }) {
                    FrostedGlassSurface(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = 28.dp
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = orgMode.icon,
                                contentDescription = null,
                                tint = glass.brandBlue,
                                modifier = Modifier.size(34.dp)
                            )
                            Text(
                                text = when (orgMode) {
                                    LibraryOrgMode.TAGS -> "No books match this tag yet"
                                    LibraryOrgMode.BOOKMARKS -> "No bookmarked books yet"
                                    else -> "No matching books"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Tap the tag icon on any book card to assign genres or create custom tags.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else if (groupedSections.isNotEmpty()) {
                groupedSections.forEach { (sectionTitle, sectionBooks) ->
                    item(key = "header_$sectionTitle", span = { GridItemSpan(gridColumns) }) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = sectionTitle,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = PlayfairDisplayFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp
                                ),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "${sectionBooks.size} ${if (sectionBooks.size == 1) "book" else "books"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = glass.brandOrange
                            )
                        }
                    }
                    items(sectionBooks, key = { "${sectionTitle}_${it.id}" }) { book ->
                        LibraryBookCard(
                            book = book,
                            onBookClick = { onBookClick(book) },
                            onToggleBookmark = { onToggleBookmark(book) },
                            onOrganizeClick = { organizingBook = book },
                            onRemoveDownload = { onRemoveDownload(book) }
                        )
                    }
                }
            } else {
                items(filteredBooks, key = { it.id }) { book ->
                    LibraryBookCard(
                        book = book,
                        onBookClick = { onBookClick(book) },
                        onToggleBookmark = { onToggleBookmark(book) },
                        onOrganizeClick = { organizingBook = book },
                        onRemoveDownload = { onRemoveDownload(book) }
                    )
                }
            }
        }
    }

    // Organize Book (Genre & Custom Tags) Sheet
    val bookToOrganize = organizingBook?.let { current ->
        downloadedBooks.find { it.id == current.id } ?: current
    }
    if (bookToOrganize != null) {
        OrganizeBookSheet(
            book = bookToOrganize,
            existingTags = allCustomTags,
            onDismiss = { organizingBook = null },
            onCategorySelected = { category ->
                onUpdateBookCategory(bookToOrganize, category)
            },
            onTagsUpdated = { tags ->
                onUpdateBookTags(bookToOrganize, tags)
            }
        )
    }
}

@Composable
private fun SubFilterChipsRow(
    items: List<String>,
    selectedItem: String?,
    allLabel: String,
    onSelect: (String?) -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val view = LocalView.current
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "__all__") {
            val allSelected = selectedItem == null
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (allSelected) glass.brandOrangeSoft else glass.glassSurface)
                    .border(
                        1.dp,
                        if (allSelected) glass.brandOrange else glass.glassBorderEnd,
                        CircleShape
                    )
                    .clickable {
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        onSelect(null)
                    }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(
                    text = allLabel,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (allSelected) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                )
            }
        }

        items(items, key = { it }) { item ->
            val selected = selectedItem == item
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (selected) glass.brandOrangeSoft else glass.glassSurface)
                    .border(
                        1.dp,
                        if (selected) glass.brandOrange else glass.glassBorderEnd,
                        CircleShape
                    )
                    .clickable {
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        onSelect(if (selected) null else item)
                    }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(
                    text = item,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (selected) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LibraryBookCard(
    book: EbookEntity,
    onBookClick: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOrganizeClick: () -> Unit,
    onRemoveDownload: () -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val tags = remember(book.customTags) { book.tagList() }

    FrostedGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("library_book_${book.id}"),
        shape = RoundedCornerShape(22.dp),
        onClick = onBookClick,
        contentPadding = 12.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BookCoverView(
                book = book,
                modifier = Modifier
                    .width(64.dp)
                    .height(94.dp),
                cornerRadius = 12.dp
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = book.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = glass.brandBlue
                    )
                    Text(
                        text = "• ${if (book.progressPercent > 0) "${book.progressPercent}% read" else "Ready"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = book.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        lineHeight = 20.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = book.author,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (tags.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        tags.take(3).forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(glass.brandOrangeSoft)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "#$tag",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = glass.brandOrange
                                )
                            }
                        }
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = onOrganizeClick,
                    modifier = Modifier.testTag("organize_book_${book.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.EditNote,
                        contentDescription = "Organize genre and tags",
                        tint = glass.brandBlue
                    )
                }
                IconButton(onClick = onToggleBookmark) {
                    Icon(
                        imageVector = if (book.isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                        contentDescription = "Toggle bookmark",
                        tint = if (book.isBookmarked) glass.brandOrange else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (!book.isBundled) {
                    IconButton(onClick = onRemoveDownload) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Remove from library",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    IconButton(onClick = onBookClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.MenuBook,
                            contentDescription = "Open book",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun OrganizeBookSheet(
    book: EbookEntity,
    existingTags: List<String>,
    onDismiss: () -> Unit,
    onCategorySelected: (String) -> Unit,
    onTagsUpdated: (List<String>) -> Unit
) {
    val glass = LocalKismisGlassColors.current
    var newTagInput by remember { mutableStateOf("") }
    val currentTags = remember(book.customTags) { book.tagList() }
    val genreOptions = remember {
        listOf("Comedy", "Entertaining", "Fiction", "Mystery", "Sci-Fi", "Adventure", "Philosophy", "Classics")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = if (glass.isDark) Color(0xFF171B24) else Color(0xFFFCFDFE)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Organize \"${book.title}\"",
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = PlayfairDisplayFamily),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "Genre",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                genreOptions.forEach { genre ->
                    val selected = book.category.equals(genre, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) glass.brandBlue else glass.glassSurfaceElevated)
                            .border(
                                1.dp,
                                if (selected) glass.brandBlue else glass.glassBorderStart,
                                CircleShape
                            )
                            .clickable { onCategorySelected(genre) }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = genre,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Text(
                text = "Custom Tags",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = newTagInput,
                    onValueChange = { newTagInput = it },
                    placeholder = { Text("Create custom tag (e.g. Cozy)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("new_tag_input")
                )
                Button(
                    onClick = {
                        val trimmed = newTagInput.trim()
                        if (trimmed.isNotEmpty()) {
                            onTagsUpdated((currentTags + trimmed).distinct())
                            newTagInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = glass.brandOrange),
                    shape = CircleShape,
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("add_tag_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add tag", tint = Color.White)
                }
            }

            val combinedTagChoices = remember(currentTags, existingTags) {
                (currentTags + existingTags).distinct().sorted()
            }
            if (combinedTagChoices.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    combinedTagChoices.forEach { tag ->
                        val active = currentTags.any { it.equals(tag, ignoreCase = true) }
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (active) glass.brandOrangeSoft else glass.glassSurfaceElevated)
                                .border(
                                    1.dp,
                                    if (active) glass.brandOrange else glass.glassBorderStart,
                                    CircleShape
                                )
                                .clickable {
                                    val updated = if (active) {
                                        currentTags.filterNot { it.equals(tag, ignoreCase = true) }
                                    } else {
                                        currentTags + tag
                                    }
                                    onTagsUpdated(updated)
                                }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "#$tag",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (active) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                                )
                                if (active) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Remove $tag",
                                        tint = glass.brandOrange,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun StatColumn(value: String, label: String) {
    val glass = LocalKismisGlassColors.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = glass.brandBlue
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
