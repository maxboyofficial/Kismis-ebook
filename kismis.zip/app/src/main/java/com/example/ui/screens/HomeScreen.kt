package com.example.ui.screens

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.LibraryAdd
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.EbookEntity
import com.example.data.local.OfflineBookStorage
import com.example.data.repository.OfflineSyncPhase
import com.example.ui.components.BookCoverView
import com.example.ui.components.BookPreviewSheet
import com.example.ui.components.FrostedGlassSurface
import com.example.ui.components.WavySectionDivider
import com.example.ui.components.formatCompactCount
import com.example.ui.theme.LocalKismisGlassColors
import com.example.ui.theme.LocalKismisLiteMode
import com.example.ui.theme.PlayfairDisplayFamily
import com.example.ui.viewmodel.HomeCatalogState
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter

@Composable
fun HomeScreen(
    state: HomeCatalogState,
    isDarkTheme: Boolean,
    bottomNavInset: Dp = 118.dp,
    onToggleTheme: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleFilterExpanded: () -> Unit,
    onCategorySelected: (String) -> Unit,
    onLanguageSelected: (String) -> Unit,
    onRefreshOnline: () -> Unit,
    onLoadMoreOnline: () -> Unit,
    onUnlockThousandBooks: () -> Unit = {},
    onPauseOfflineSync: () -> Unit = {},
    onDownloadOffline: (EbookEntity) -> Unit,
    onBookClick: (EbookEntity) -> Unit,
    onToggleBookmark: (EbookEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val view = LocalView.current
    var previewBook by remember { mutableStateOf<EbookEntity?>(null) }
    val gridState = rememberLazyGridState()

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val gridColumns = when {
            maxWidth >= 960.dp -> 4
            maxWidth >= 600.dp -> 3
            else -> 2
        }

        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(gridColumns),
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = bottomNavInset
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { GridItemSpan(gridColumns) }, contentType = "header") {
                KismisHeaderBar(
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = onToggleTheme
                )
            }

            item(span = { GridItemSpan(gridColumns) }, contentType = "search") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SearchAndFilterRow(
                        query = state.searchQuery,
                        isFilterExpanded = state.isFilterExpanded,
                        activeCategory = state.selectedCategory,
                        activeLanguage = state.selectedLanguage,
                        onQueryChange = onSearchQueryChange,
                        onToggleFilter = onToggleFilterExpanded
                    )

                    AnimatedVisibility(
                        visible = state.isFilterExpanded || state.selectedCategory != "All" || state.selectedLanguage != "EN",
                        enter = expandVertically(spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
                        exit = shrinkVertically(spring(stiffness = Spring.StiffnessMedium)) + fadeOut()
                    ) {
                        CategoryFilterStrip(
                            categories = state.categories,
                            selectedCategory = state.selectedCategory,
                            languages = state.languages,
                            selectedLanguage = state.selectedLanguage,
                            onSelectCategory = onCategorySelected,
                            onSelectLanguage = onLanguageSelected
                        )
                    }
                }
            }

            if (state.continueReading != null && state.searchQuery.isBlank() && state.selectedCategory == "All") {
                item(span = { GridItemSpan(gridColumns) }, contentType = "continue") {
                    Column(
                        modifier = Modifier.widthIn(max = 820.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Continue Reading",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = PlayfairDisplayFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp
                                ),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "~",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = PlayfairDisplayFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = glass.brandOrange
                            )
                        }
                        ContinueReadingCard(
                            book = state.continueReading,
                            isLoading = state.downloadingBookId == state.continueReading.id,
                            onReadNow = { onBookClick(state.continueReading) }
                        )
                    }
                }

                item(span = { GridItemSpan(gridColumns) }, contentType = "divider") {
                    WavySectionDivider(modifier = Modifier.padding(vertical = 2.dp))
                }
            }

            item(span = { GridItemSpan(gridColumns) }, contentType = "section_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "All e-Books",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = PlayfairDisplayFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(glass.brandBlueSoft)
                                .padding(horizontal = 9.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (state.localCatalogCount > 0 && state.displayedBooks.size < state.localCatalogCount) {
                                    "${state.displayedBooks.size} / ${state.localCatalogCount}"
                                } else {
                                    "${state.displayedBooks.size}"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = glass.brandBlue
                            )
                        }
                        if (state.selectedCategory != "All") {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(glass.brandOrange)
                                    .clickable {
                                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                        onCategorySelected("All")
                                    }
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "${state.selectedCategory} ×",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(glass.brandOrangeSoft)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DownloadDone,
                            contentDescription = "All e-books offline ready",
                            tint = glass.brandOrange,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Offline Ready",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = glass.brandOrange
                        )
                    }
                }
            }

            if (state.displayedBooks.isEmpty()) {
                item(span = { GridItemSpan(gridColumns) }, contentType = "empty") {
                    FrostedGlassSurface(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = 24.dp
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (state.isLoadingOnline) "Fetching Project Gutenberg books…" else "No matching e-books",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = state.onlineError ?: "Try clearing your search or choosing another genre.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(
                    items = state.displayedBooks,
                    key = { it.id },
                    contentType = { "book_card" }
                ) { book ->
                    EbookGridCard(
                        book = book,
                        isDownloading = state.downloadingBookId == book.id,
                        onCardClick = { previewBook = book },
                        onReadClick = { onBookClick(book) },
                        onBookmarkClick = { onToggleBookmark(book) },
                        modifier = if (isLiteMode) {
                            Modifier
                        } else {
                            Modifier.animateItem(
                                fadeInSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                placementSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
                            )
                        }
                    )
                }

                if (state.hasNextPage) {
                    item(span = { GridItemSpan(gridColumns) }, contentType = "load_more") {
                        FrostedGlassSurface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .testTag("load_more_books_button"),
                            shape = CircleShape,
                            elevated = true,
                            onClick = onLoadMoreOnline,
                            contentPadding = 14.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (state.isLoadingMore) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = glass.brandBlue
                                    )
                                    Text(
                                        text = "  Loading more classics…",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = glass.brandBlue
                                    )
                                } else {
                                    Text(
                                        text = "Load More Books",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = glass.brandBlue
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        val activePreview = previewBook?.let { selected ->
            state.displayedBooks.find { it.id == selected.id } ?: selected
        }
        if (activePreview != null) {
            BookPreviewSheet(
                book = activePreview,
                isDownloading = state.downloadingBookId == activePreview.id,
                onDismiss = { previewBook = null },
                onReadClick = {
                    onBookClick(activePreview)
                    previewBook = null
                },
                onDownloadOfflineClick = { onDownloadOffline(activePreview) },
                onToggleBookmark = { onToggleBookmark(activePreview) }
            )
        }
    }
}

@Composable
private fun KismisHeaderBar(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val brandGradient = remember(glass.brandBlue, glass.brandOrange) {
        Brush.horizontalGradient(listOf(glass.brandBlue, glass.brandOrange))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Upgraded App Top Logo: Bespoke Blue & Orange squircle mark + gradient wordmark
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(14.dp),
                        ambientColor = glass.brandBlue.copy(alpha = 0.45f),
                        spotColor = glass.brandOrange.copy(alpha = 0.35f)
                    )
                    .clip(RoundedCornerShape(14.dp))
                    .border(
                        width = 1.4.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.85f),
                                glass.brandOrange.copy(alpha = 0.65f)
                            )
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kismis_icon_fg),
                    contentDescription = "Kismis Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = TextStyle(
                            fontFamily = PlayfairDisplayFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            letterSpacing = (-0.6).sp,
                            brush = brandGradient
                        )
                    )
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(glass.brandOrange)
                    )
                }
                Text(
                    text = "SMART READER",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = stringResource(R.string.app_subtitle),
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isDarkTheme) "Dark Theme" else "White Theme",
                    style = MaterialTheme.typography.labelSmall,
                    color = glass.brandOrange
                )
            }
            FrostedGlassSurface(
                modifier = Modifier
                    .size(44.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("header_theme_toggle"),
                shape = CircleShape,
                elevated = true,
                onClick = onToggleTheme
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isDarkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                        contentDescription = if (isDarkTheme) "Switch to White theme" else "Switch to Dark theme",
                        tint = if (isDarkTheme) glass.brandOrange else glass.brandBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchAndFilterRow(
    query: String,
    isFilterExpanded: Boolean,
    activeCategory: String,
    activeLanguage: String,
    onQueryChange: (String) -> Unit,
    onToggleFilter: () -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val hasActiveFilter = activeCategory != "All" || activeLanguage != "EN"
    val filterHighlighted = isFilterExpanded || hasActiveFilter
    val iconRotation by animateFloatAsState(
        targetValue = if (isFilterExpanded) 90f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "filter_icon_rot"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FrostedGlassSurface(
            modifier = Modifier
                .weight(1f)
                .height(50.dp),
            shape = CircleShape
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = "Search",
                    tint = glass.brandBlue,
                    modifier = Modifier.size(20.dp)
                )
                Box(modifier = Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Search books, authors, tags…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        ),
                        cursorBrush = SolidColor(glass.brandBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_input")
                    )
                }
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = { onQueryChange("") },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Clear search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        FrostedGlassSurface(
            modifier = Modifier
                .height(50.dp)
                .minimumInteractiveComponentSize()
                .testTag("filter_toggle_button"),
            shape = CircleShape,
            elevated = filterHighlighted,
            onClick = onToggleFilter
        ) {
            Box(
                modifier = Modifier
                    .background(
                        if (filterHighlighted) {
                            Brush.horizontalGradient(listOf(glass.brandBlue, glass.brandOrange))
                        } else {
                            SolidColor(Color.Transparent)
                        }
                    )
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = "Filter genres",
                        tint = if (filterHighlighted) Color.White else glass.brandBlue,
                        modifier = Modifier
                            .size(18.dp)
                            .graphicsLayer { rotationZ = iconRotation }
                    )
                    Text(
                        text = if (activeCategory != "All") activeCategory else "Genres",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = if (filterHighlighted) Color.White else MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                    if (hasActiveFilter) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryFilterStrip(
    categories: List<String>,
    selectedCategory: String,
    languages: List<String>,
    selectedLanguage: String,
    onSelectCategory: (String) -> Unit,
    onSelectLanguage: (String) -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val view = LocalView.current
    FrostedGlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        elevated = true,
        contentPadding = 8.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.forEach { category ->
                    val selected = category == selectedCategory
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                if (selected) {
                                    Brush.horizontalGradient(listOf(glass.brandBlue, glass.brandOrange))
                                } else {
                                    SolidColor(Color.Transparent)
                                }
                            )
                            .border(
                                width = if (selected) 0.dp else 1.dp,
                                color = if (selected) Color.Transparent else glass.glassBorderEnd,
                                shape = CircleShape
                            )
                            .minimumInteractiveComponentSize()
                            .clickable(
                                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                indication = ripple(bounded = true, color = glass.brandBlue)
                            ) {
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                onSelectCategory(category)
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("category_chip_${category.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = category,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold
                            ),
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Lang:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, end = 2.dp)
                )
                languages.forEach { lang ->
                    val selected = lang == selectedLanguage
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) glass.brandOrangeSoft else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (selected) glass.brandOrange else glass.glassBorderEnd,
                                shape = CircleShape
                            )
                            .clickable {
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                onSelectLanguage(lang)
                            }
                            .padding(horizontal = 11.dp, vertical = 5.dp)
                            .testTag("language_chip_${lang.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (lang == "All") "All Langs" else lang,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueReadingCard(
    book: EbookEntity,
    isLoading: Boolean,
    onReadNow: () -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val view = LocalView.current
    val animatedProgress by animateFloatAsState(
        targetValue = (book.progressPercent.coerceIn(0, 100) / 100f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "continue_progress"
    )

    FrostedGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("continue_reading_card"),
        shape = RoundedCornerShape(26.dp),
        elevated = true,
        onClick = onReadNow,
        contentPadding = 16.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BookCoverView(
                book = book,
                modifier = Modifier
                    .width(94.dp)
                    .height(136.dp),
                cornerRadius = 16.dp
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(glass.brandOrangeSoft)
                            .padding(horizontal = 9.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = book.category,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = glass.brandOrange
                        )
                    }
                    Text(
                        text = book.author,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = book.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        lineHeight = 22.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (book.description.isNotBlank()) {
                    Text(
                        text = book.description,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Reading Progress",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${book.progressPercent}%",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = glass.brandOrange
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(animatedProgress.coerceAtLeast(0.04f))
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(glass.brandBlue, glass.brandOrange)
                                    )
                                )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(listOf(glass.brandBlue, glass.brandOrange))
                        )
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = ripple(bounded = true, color = Color.White)
                        ) {
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            onReadNow()
                        }
                        .padding(horizontal = 18.dp, vertical = 9.dp)
                        .testTag("read_now_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = stringResource(R.string.read_now),
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EbookGridCard(
    book: EbookEntity,
    isDownloading: Boolean,
    onCardClick: () -> Unit,
    onReadClick: () -> Unit,
    onBookmarkClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val view = LocalView.current

    FrostedGlassSurface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ebook_card_${book.id}"),
        shape = RoundedCornerShape(22.dp),
        onClick = onCardClick,
        contentPadding = 12.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                BookCoverView(
                    book = book,
                    modifier = Modifier
                        .width(58.dp)
                        .height(86.dp),
                    cornerRadius = 11.dp
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = book.category.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = glass.brandOrange,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = if (book.isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                            contentDescription = "Bookmark ${book.title}",
                            tint = if (book.isBookmarked) glass.brandOrange else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable {
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                    onBookmarkClick()
                                }
                        )
                    }

                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            lineHeight = 18.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = book.author,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (book.isDownloaded) Icons.Rounded.DownloadDone else Icons.Rounded.CloudDownload,
                        contentDescription = if (book.isDownloaded) "Offline ready" else "Cloud book",
                        tint = if (book.isDownloaded) glass.brandBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = when {
                            book.progressPercent > 0 -> "${book.progressPercent}% read"
                            book.isDownloaded -> "Offline"
                            book.downloadCount > 0 -> formatCompactCount(book.downloadCount)
                            else -> "Cloud"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(
                            if (book.isDownloaded) glass.brandBlue else glass.brandBlueSoft
                        )
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = ripple(bounded = true, color = Color.White)
                        ) {
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            onReadClick()
                        }
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                        .testTag("read_button_${book.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDownloading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = if (book.isDownloaded) Color.White else glass.brandBlue
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.read_action),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (book.isDownloaded) Color.White else glass.brandBlue
                        )
                    }
                }
            }
        }
    }
}

