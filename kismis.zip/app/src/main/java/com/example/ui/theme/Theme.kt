package com.example.ui.theme

import android.app.Activity
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class AppThemeMode(val label: String) {
    LIGHT("White"),
    DARK("Dark"),
    SYSTEM("System")
}

@Immutable
data class KismisGlassColors(
    val isDark: Boolean,
    val glassSurface: Color,
    val glassSurfaceElevated: Color,
    val glassPillActive: Color,
    val glassBorderStart: Color,
    val glassBorderEnd: Color,
    val dockSurface: Color,
    val dockBorderStart: Color,
    val dockBorderEnd: Color,
    val dockSheenTop: Color,
    val dockSheenBottom: Color,
    val dockPillTop: Color,
    val dockPillBottom: Color,
    val dockPillBorder: Color,
    val dockContentInactive: Color,
    val dockContentActive: Color,
    val brandBlue: Color,
    val brandBlueSoft: Color,
    val brandOrange: Color,
    val brandOrangeSoft: Color,
    val orbPrimary: Color,
    val orbSecondary: Color,
    val orbTertiary: Color,
    val dividerWave: Color
)

val LocalKismisGlassColors = staticCompositionLocalOf {
    KismisGlassColors(
        isDark = false,
        glassSurface = Color.White.copy(alpha = 0.80f),
        glassSurfaceElevated = Color.White.copy(alpha = 0.92f),
        glassPillActive = Color.White.copy(alpha = 0.96f),
        glassBorderStart = Color(0xFF141821).copy(alpha = 0.28f),
        glassBorderEnd = Color(0xFF141821).copy(alpha = 0.14f),
        dockSurface = Color(0xFF121622).copy(alpha = 0.80f),
        dockBorderStart = Color.White.copy(alpha = 0.34f),
        dockBorderEnd = Color(0xFF07090E).copy(alpha = 0.78f),
        dockSheenTop = Color.White.copy(alpha = 0.16f),
        dockSheenBottom = Color.Black.copy(alpha = 0.24f),
        dockPillTop = Color.White.copy(alpha = 0.90f),
        dockPillBottom = Color.White.copy(alpha = 0.66f),
        dockPillBorder = Color.White.copy(alpha = 0.96f),
        dockContentInactive = Color.White.copy(alpha = 0.78f),
        dockContentActive = KismisBlueLight,
        brandBlue = KismisBlueLight,
        brandBlueSoft = KismisBlueSoftLight,
        brandOrange = KismisOrangeLight,
        brandOrangeSoft = KismisOrangeSoftLight,
        orbPrimary = LightOrbBlue,
        orbSecondary = LightOrbOrange,
        orbTertiary = LightOrbSky,
        dividerWave = Color(0xFFBAC3D4)
    )
}

private val KismisLightColorScheme = lightColorScheme(
    primary = KismisBlueLight,
    onPrimary = Color.White,
    primaryContainer = KismisBlueSoftLight,
    onPrimaryContainer = Color(0xFF0A2E6E),
    secondary = KismisOrangeLight,
    onSecondary = Color.White,
    secondaryContainer = KismisOrangeSoftLight,
    onSecondaryContainer = Color(0xFF6B2800),
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightOutline.copy(alpha = 0.26f)
)

private val KismisDarkColorScheme = darkColorScheme(
    primary = KismisBlueDark,
    onPrimary = Color.White,
    primaryContainer = KismisBlueSoftDark,
    onPrimaryContainer = Color(0xFFBBD6FF),
    secondary = KismisOrangeDark,
    onSecondary = Color.White,
    secondaryContainer = KismisOrangeSoftDark,
    onSecondaryContainer = Color(0xFFFFCBA8),
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color.White.copy(alpha = 0.28f)
)

val LocalKismisLiteMode = staticCompositionLocalOf { false }

val KismisShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun KismisTheme(
    themeMode: AppThemeMode = AppThemeMode.LIGHT,
    isLiteMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> systemDark
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !useDark
                    isAppearanceLightNavigationBars = !useDark
                }
            }
        }
    }

    val animSpec = tween<Color>(durationMillis = if (isLiteMode) 0 else 260)
    val baseScheme = if (useDark) KismisDarkColorScheme else KismisLightColorScheme

    val bg by animateColorAsState(baseScheme.background, animSpec, label = "bg")
    val surface by animateColorAsState(baseScheme.surface, animSpec, label = "surface")
    val onBg by animateColorAsState(baseScheme.onBackground, animSpec, label = "onBg")
    val onSurface by animateColorAsState(baseScheme.onSurface, animSpec, label = "onSurface")
    val primary by animateColorAsState(baseScheme.primary, animSpec, label = "primary")
    val secondary by animateColorAsState(baseScheme.secondary, animSpec, label = "secondary")
    val surfaceVar by animateColorAsState(baseScheme.surfaceVariant, animSpec, label = "surfaceVar")
    val onSurfaceVar by animateColorAsState(baseScheme.onSurfaceVariant, animSpec, label = "onSurfaceVar")

    val animatedScheme = baseScheme.copy(
        primary = primary,
        secondary = secondary,
        background = bg,
        surface = surface,
        onBackground = onBg,
        onSurface = onSurface,
        surfaceVariant = surfaceVar,
        onSurfaceVariant = onSurfaceVar
    )

    val glassSurface by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.14f) else Color.White.copy(alpha = 0.80f),
        animSpec, label = "glassSurface"
    )
    val glassElevated by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.21f) else Color.White.copy(alpha = 0.92f),
        animSpec, label = "glassElevated"
    )
    val glassPillActive by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.28f) else Color.White.copy(alpha = 0.98f),
        animSpec, label = "glassPillActive"
    )
    val borderStart by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.44f) else Color(0xFF141821).copy(alpha = 0.28f),
        animSpec, label = "borderStart"
    )
    val borderEnd by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.18f) else Color(0xFF141821).copy(alpha = 0.14f),
        animSpec, label = "borderEnd"
    )

    val dockSurface by animateColorAsState(
        if (useDark) Color(0xFF181C28).copy(alpha = 0.74f) else Color(0xFF121622).copy(alpha = 0.80f),
        animSpec, label = "dockSurface"
    )
    val dockBorderStart by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.36f) else Color.White.copy(alpha = 0.28f),
        animSpec, label = "dockBorderStart"
    )
    val dockBorderEnd by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.10f) else Color(0xFF06080D).copy(alpha = 0.78f),
        animSpec, label = "dockBorderEnd"
    )
    val dockPillTop by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.94f) else Color.White.copy(alpha = 0.88f),
        animSpec, label = "dockPillTop"
    )
    val dockPillBottom by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.74f) else Color.White.copy(alpha = 0.64f),
        animSpec, label = "dockPillBottom"
    )
    val dividerWave by animateColorAsState(
        if (useDark) Color.White.copy(alpha = 0.24f) else Color(0xFF1A1F2B).copy(alpha = 0.24f),
        animSpec, label = "dividerWave"
    )

    val glassColors = KismisGlassColors(
        isDark = useDark,
        glassSurface = glassSurface,
        glassSurfaceElevated = glassElevated,
        glassPillActive = glassPillActive,
        glassBorderStart = borderStart,
        glassBorderEnd = borderEnd,
        dockSurface = dockSurface,
        dockBorderStart = dockBorderStart,
        dockBorderEnd = dockBorderEnd,
        dockSheenTop = Color.White.copy(alpha = 0.16f),
        dockSheenBottom = Color.Black.copy(alpha = 0.24f),
        dockPillTop = dockPillTop,
        dockPillBottom = dockPillBottom,
        dockPillBorder = Color.White.copy(alpha = 0.96f),
        dockContentInactive = Color.White.copy(alpha = 0.78f),
        dockContentActive = KismisBlueLight,
        brandBlue = primary,
        brandBlueSoft = if (useDark) KismisBlueSoftDark else KismisBlueSoftLight,
        brandOrange = secondary,
        brandOrangeSoft = if (useDark) KismisOrangeSoftDark else KismisOrangeSoftLight,
        orbPrimary = if (useDark) DarkOrbBlue else LightOrbBlue,
        orbSecondary = if (useDark) DarkOrbOrange else LightOrbOrange,
        orbTertiary = if (useDark) DarkOrbIndigo else LightOrbSky,
        dividerWave = dividerWave
    )

    CompositionLocalProvider(
        LocalKismisGlassColors provides glassColors,
        LocalKismisLiteMode provides isLiteMode
    ) {
        MaterialTheme(
            colorScheme = animatedScheme,
            typography = Typography,
            shapes = KismisShapes,
            content = content
        )
    }
}
