package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.DevicePerformanceProfile
import com.example.data.local.EbookEntity
import com.example.data.local.KismisDatabase
import com.example.data.local.OfflineBookStorage
import com.example.data.local.PageTurnMode
import com.example.data.local.PerformanceMode
import com.example.data.local.ReaderFontStyle
import com.example.data.local.ReaderPaperMode
import com.example.data.local.ReaderPreferencesRepository
import com.example.data.local.ReaderPreferencesState
import com.example.data.repository.BookPaginationEngine
import com.example.data.repository.EbookRepository
import com.example.data.repository.OfflineSyncPhase
import com.example.data.repository.OfflineSyncState
import com.example.data.repository.PaginatedBook
import com.example.tts.KismisTtsController
import com.example.tts.TtsUiState
import com.example.tts.TtsVoicePreset
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainTab {
    HOME,
    LIBRARY,
    SETTINGS
}

data class HomeCatalogState(
    val searchQuery: String = "",
    val selectedCategory: String = "All",
    val categories: List<String> = listOf(
        "All", "Romance", "Mystery", "Horror", "Comedy", "Entertaining", "Fiction", "Sci-Fi", "Adventure", "Philosophy", "Drama"
    ),
    val selectedLanguage: String = "EN",
    val languages: List<String> = listOf("EN", "All", "FR", "DE", "ES", "PT"),
    val continueReading: EbookEntity? = null,
    val displayedBooks: List<EbookEntity> = emptyList(),
    val localCatalogCount: Int = 0,
    val offlineBookCount: Int = 0,
    val offlineStorageBytes: Long = 0L,
    val totalOnlineCount: Int = 0,
    val hasNextPage: Boolean = false,
    val isLoadingOnline: Boolean = false,
    val isLoadingMore: Boolean = false,
    val isUnlockingThousand: Boolean = false,
    val syncPhase: OfflineSyncPhase = OfflineSyncPhase.IDLE,
    val syncStatusMessage: String = "",
    val syncCurrentBookTitle: String = "",
    val thousandSyncProgress: Int = 0,
    val thousandSyncTarget: Int = 1050,
    val onlineError: String? = null,
    val downloadingBookId: String? = null,
    val isFilterExpanded: Boolean = false
)

data class ReaderUiState(
    val book: EbookEntity? = null,
    val paginatedBook: PaginatedBook? = null,
    val currentPage: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

@OptIn(FlowPreview::class)
class KismisViewModel(application: Application) : AndroidViewModel(application) {

    private val database = KismisDatabase.getInstance(application)
    private val repository = EbookRepository(application, database.ebookDao())
    private val prefsRepo = ReaderPreferencesRepository(application)

    val isHardwareLowRam: Boolean = DevicePerformanceProfile.isLowRamHardware(application)

    val preferences: StateFlow<ReaderPreferencesState> = prefsRepo.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReaderPreferencesState())

    val isLiteMode: StateFlow<Boolean> = preferences
        .map { prefs ->
            when (prefs.performanceMode) {
                PerformanceMode.AUTO -> isHardwareLowRam
                PerformanceMode.LITE -> true
                PerformanceMode.FULL -> false
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), isHardwareLowRam)

    private val _selectedTab = MutableStateFlow(MainTab.HOME)
    val selectedTab: StateFlow<MainTab> = _selectedTab

    private val _isSearchOverlayOpen = MutableStateFlow(false)
    val isSearchOverlayOpen: StateFlow<Boolean> = _isSearchOverlayOpen

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow("All")
    private val _selectedLanguage = MutableStateFlow("EN")
    private val _isFilterExpanded = MutableStateFlow(false)

    private val _onlineBooks = MutableStateFlow<List<EbookEntity>>(emptyList())
    private val _totalOnlineCount = MutableStateFlow(0)
    private val _hasNextPage = MutableStateFlow(false)
    private val _currentPage = MutableStateFlow(1)
    private val _isLoadingOnline = MutableStateFlow(false)
    private val _isLoadingMore = MutableStateFlow(false)
    private val _rawOfflineSyncState = MutableStateFlow(OfflineSyncState())
    private val _onlineError = MutableStateFlow<String?>(null)
    private val _downloadingBookId = MutableStateFlow<String?>(null)
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage

    private val _readerState = MutableStateFlow(ReaderUiState())
    val readerState: StateFlow<ReaderUiState> = _readerState

    private val ttsController = KismisTtsController(application) { targetPage ->
        if (_readerState.value.currentPage != targetPage) {
            onReaderPageChanged(targetPage)
        }
    }
    val ttsState: StateFlow<TtsUiState> = ttsController.state

    private var onlineFetchJob: Job? = null
    private var loadMoreJob: Job? = null
    private var thousandSyncJob: Job? = null
    private var readerObserverJob: Job? = null

    val allLocalBooks: StateFlow<List<EbookEntity>> = repository.allLocalBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadedBooks: StateFlow<List<EbookEntity>> = repository.downloadedBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkedBooks: StateFlow<List<EbookEntity>> = repository.bookmarkedBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlineSyncState: StateFlow<OfflineSyncState> = combine(
        _rawOfflineSyncState,
        repository.downloadedBookCount,
        repository.allLocalBooks.map { it.size }.distinctUntilChanged()
    ) { raw, liveOfflineCount, liveIndexedCount ->
        val storageBytes = if (raw.storageUsedBytes > 0L) raw.storageUsedBytes else repository.getOfflineStorageBytes()
        val effectivePhase = when {
            raw.isSyncing -> raw.phase
            liveOfflineCount >= raw.targetOfflineCount -> OfflineSyncPhase.COMPLETED
            else -> raw.phase
        }
        raw.copy(
            phase = effectivePhase,
            indexedCount = maxOf(raw.indexedCount, liveIndexedCount),
            offlineReadyCount = liveOfflineCount,
            storageUsedBytes = storageBytes
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OfflineSyncState())

    val allCustomTags: StateFlow<List<String>> = repository.allLocalBooks
        .map { books ->
            books.flatMap { it.tagList() }
                .distinct()
                .sorted()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private data class RemoteCatalogUi(
        val books: List<EbookEntity>,
        val totalCount: Int,
        val hasNextPage: Boolean,
        val isLoading: Boolean,
        val isLoadingMore: Boolean,
        val syncState: OfflineSyncState,
        val error: String?
    )

    private val remoteCatalogFlow = combine(
        _onlineBooks,
        _totalOnlineCount,
        _hasNextPage,
        _isLoadingOnline,
        _isLoadingMore,
        offlineSyncState,
        _onlineError
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        RemoteCatalogUi(
            books = values[0] as List<EbookEntity>,
            totalCount = values[1] as Int,
            hasNextPage = values[2] as Boolean,
            isLoading = values[3] as Boolean,
            isLoadingMore = values[4] as Boolean,
            syncState = values[5] as OfflineSyncState,
            error = values[6] as String?
        )
    }

    val homeState: StateFlow<HomeCatalogState> = combine(
        repository.allLocalBooks,
        repository.continueReadingBook,
        remoteCatalogFlow,
        _searchQuery,
        _selectedCategory,
        _selectedLanguage,
        _isFilterExpanded,
        _downloadingBookId
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val localBooks = values[0] as List<EbookEntity>
        val continueBook = values[1] as EbookEntity?
        val remote = values[2] as RemoteCatalogUi
        val query = values[3] as String
        val category = values[4] as String
        val language = values[5] as String
        val filterExpanded = values[6] as Boolean
        val downloadingId = values[7] as String?

        val localMap = localBooks.associateBy { it.id }
        val merged = buildList(localBooks.size + remote.books.size) {
            addAll(localBooks)
            remote.books.forEach { remoteBook ->
                if (!localMap.containsKey(remoteBook.id)) {
                    add(remoteBook)
                }
            }
        }.filter { book ->
            val matchesQuery = query.isBlank() ||
                book.title.contains(query, ignoreCase = true) ||
                book.author.contains(query, ignoreCase = true) ||
                book.category.contains(query, ignoreCase = true) ||
                book.description.contains(query, ignoreCase = true) ||
                book.shelves.contains(query, ignoreCase = true) ||
                book.customTags.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" ||
                book.category.equals(category, ignoreCase = true) ||
                book.shelves.contains(category, ignoreCase = true)
            val matchesLanguage = language.equals("All", ignoreCase = true) ||
                book.language.equals(language, ignoreCase = true)
            matchesQuery && matchesCategory && matchesLanguage
        }

        val sync = remote.syncState
        HomeCatalogState(
            searchQuery = query,
            selectedCategory = category,
            selectedLanguage = language,
            continueReading = continueBook ?: localBooks.firstOrNull(),
            displayedBooks = merged,
            localCatalogCount = localBooks.size,
            offlineBookCount = sync.offlineReadyCount,
            offlineStorageBytes = sync.storageUsedBytes,
            totalOnlineCount = remote.totalCount,
            hasNextPage = remote.hasNextPage,
            isLoadingOnline = remote.isLoading,
            isLoadingMore = remote.isLoadingMore,
            isUnlockingThousand = sync.isSyncing,
            syncPhase = sync.phase,
            syncStatusMessage = sync.statusMessage,
            syncCurrentBookTitle = sync.currentBookTitle,
            thousandSyncProgress = sync.offlineReadyCount,
            thousandSyncTarget = sync.targetOfflineCount,
            onlineError = remote.error,
            downloadingBookId = downloadingId,
            isFilterExpanded = filterExpanded
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeCatalogState())

    init {
        viewModelScope.launch {
            repository.ensureBundledBooksSeeded()
        }
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
    }

    fun openSearchOverlay(open: Boolean) {
        _isSearchOverlayOpen.value = open
    }

    fun toggleFilterExpanded() {
        _isFilterExpanded.update { !it }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
    }

    fun onLanguageSelected(language: String) {
        _selectedLanguage.value = language
    }

    fun refreshOnlineCatalog(
        query: String = _searchQuery.value,
        category: String = _selectedCategory.value,
        language: String = _selectedLanguage.value
    ) {
        onlineFetchJob?.cancel()
        loadMoreJob?.cancel()
        _onlineBooks.value = emptyList()
        _totalOnlineCount.value = 0
        _hasNextPage.value = false
        _onlineError.value = null
        _isLoadingOnline.value = false
        _isLoadingMore.value = false
        viewModelScope.launch {
            repository.ensureBundledBooksSeeded()
        }
    }

    fun loadMoreOnlineCatalog() {
        if (_isLoadingOnline.value || _isLoadingMore.value || !_hasNextPage.value) return
        val nextPage = _currentPage.value + 1
        loadMoreJob = viewModelScope.launch {
            _isLoadingMore.value = true
            val batchSize = if (isLiteMode.value) 2 else 4
            val result = repository.fetchGutendexBatch(
                startPage = nextPage,
                pageCount = batchSize,
                searchQuery = _searchQuery.value,
                categoryFilter = _selectedCategory.value,
                languageFilter = _selectedLanguage.value
            )
            result.onSuccess { pageData ->
                _currentPage.value = nextPage + batchSize - 1
                _onlineBooks.update { existing ->
                    val seenIds = existing.map { it.id }.toHashSet()
                    existing + pageData.books.filterNot { seenIds.contains(it.id) }
                }
                _totalOnlineCount.value = pageData.totalCount
                _hasNextPage.value = pageData.hasNextPage
            }.onFailure {
                _snackbarMessage.value = "Could not load more books right now."
            }
            _isLoadingMore.value = false
        }
    }

    /**
     * Resumable 2-phase offline sync: indexes 1,270+ catalog titles and downloads
     * 1,050+ full e-book texts into compressed local storage for full offline reading.
     */
    fun unlockThousandBooksCatalog() {
        startOfflineThousandSync()
    }

    fun startOfflineThousandSync() {
        if (_rawOfflineSyncState.value.isSyncing) return
        thousandSyncJob?.cancel()
        thousandSyncJob = viewModelScope.launch {
            val concurrency = if (isLiteMode.value) 5 else 9
            _rawOfflineSyncState.update {
                it.copy(
                    phase = OfflineSyncPhase.INDEXING_CATALOG,
                    isSyncing = true,
                    statusMessage = "Preparing offline sync…"
                )
            }
            val finalState = repository.syncThousandBooksOffline(
                targetOfflineCount = 1050,
                languageFilter = _selectedLanguage.value,
                concurrency = concurrency
            ) { progress ->
                _rawOfflineSyncState.value = progress
            }
            _rawOfflineSyncState.value = finalState
            when (finalState.phase) {
                OfflineSyncPhase.COMPLETED -> {
                    _snackbarMessage.value = "${finalState.offlineReadyCount} e-books synced & ready offline!"
                }
                OfflineSyncPhase.PAUSED_OFFLINE -> {
                    _snackbarMessage.value = "Sync paused — ${finalState.offlineReadyCount} books saved offline (${OfflineBookStorage.formatBytes(finalState.storageUsedBytes)})"
                }
                else -> Unit
            }
        }
    }

    fun pauseOfflineSync() {
        if (!_rawOfflineSyncState.value.isSyncing) return
        thousandSyncJob?.cancel()
        thousandSyncJob = null
        viewModelScope.launch {
            val count = repository.getDownloadedBookCountSnapshot()
            val bytes = repository.getOfflineStorageBytes()
            _rawOfflineSyncState.update {
                it.copy(
                    phase = OfflineSyncPhase.PAUSED_OFFLINE,
                    isSyncing = false,
                    offlineReadyCount = count,
                    storageUsedBytes = bytes,
                    currentBookTitle = "",
                    statusMessage = "Paused — $count / ${it.targetOfflineCount} books saved offline"
                )
            }
            _snackbarMessage.value = "Offline sync paused ($count books saved)"
        }
    }

    fun downloadBookOffline(book: EbookEntity) {
        viewModelScope.launch {
            _downloadingBookId.value = book.id
            val result = repository.downloadBookForOffline(book)
            _downloadingBookId.value = null
            result.onSuccess { saved ->
                _rawOfflineSyncState.update { it.copy(storageUsedBytes = repository.getOfflineStorageBytes()) }
                _snackbarMessage.value = "\"${saved.title}\" saved for offline reading"
            }.onFailure {
                _snackbarMessage.value = "Could not download e-book. Check connection."
            }
        }
    }

    fun openBookForReading(book: EbookEntity, onReadyToNavigate: (String) -> Unit) {
        ttsController.stop()
        viewModelScope.launch {
            _downloadingBookId.value = book.id
            _readerState.value = ReaderUiState(book = book, isLoading = true)
            val result = repository.ensureBookReadyForReading(book)
            _downloadingBookId.value = null

            result.onSuccess { readyBook ->
                val fontSize = preferences.value.fontSizeSp
                val paginated = withContext(Dispatchers.Default) {
                    BookPaginationEngine.paginate(readyBook.contentText, fontSize)
                }
                val safePage = readyBook.currentPage.coerceIn(0, (paginated.pages.size - 1).coerceAtLeast(0))
                _readerState.value = ReaderUiState(
                    book = readyBook,
                    paginatedBook = paginated,
                    currentPage = safePage,
                    isLoading = false
                )
                observeActiveBook(readyBook.id)
                onReadyToNavigate(readyBook.id)
            }.onFailure { err ->
                _readerState.value = ReaderUiState(
                    book = book,
                    isLoading = false,
                    errorMessage = err.message ?: "Failed to load book"
                )
                _snackbarMessage.value = "Could not download e-book. Check connection and try again."
            }
        }
    }

    fun loadBookInReaderIfNeeded(bookId: String) {
        if (_readerState.value.book?.id == bookId && _readerState.value.paginatedBook != null) {
            return
        }
        viewModelScope.launch {
            _readerState.update { it.copy(isLoading = true, errorMessage = null) }
            val existing = homeState.value.displayedBooks.find { it.id == bookId }
                ?: downloadedBooks.value.find { it.id == bookId }
            if (existing != null) {
                val res = repository.ensureBookReadyForReading(existing)
                res.onSuccess { ready ->
                    val fontSize = preferences.value.fontSizeSp
                    val paginated = withContext(Dispatchers.Default) {
                        BookPaginationEngine.paginate(ready.contentText, fontSize)
                    }
                    val safePage = ready.currentPage.coerceIn(0, (paginated.pages.size - 1).coerceAtLeast(0))
                    _readerState.value = ReaderUiState(
                        book = ready,
                        paginatedBook = paginated,
                        currentPage = safePage,
                        isLoading = false
                    )
                    observeActiveBook(ready.id)
                }.onFailure { err ->
                    _readerState.update { it.copy(isLoading = false, errorMessage = err.message) }
                }
            } else {
                _readerState.update { it.copy(isLoading = false, errorMessage = "Book not found") }
            }
        }
    }

    private fun observeActiveBook(bookId: String) {
        readerObserverJob?.cancel()
        readerObserverJob = viewModelScope.launch {
            repository.observeBook(bookId).collect { latest ->
                if (latest != null) {
                    _readerState.update { current ->
                        val preservedText = latest.contentText.ifBlank { current.book?.contentText.orEmpty() }
                        current.copy(book = latest.copy(contentText = preservedText))
                    }
                }
            }
        }
    }

    fun onReaderPageChanged(pageIndex: Int) {
        val current = _readerState.value
        val book = current.book ?: return
        val total = current.paginatedBook?.pages?.size ?: 1
        _readerState.update { it.copy(currentPage = pageIndex) }
        viewModelScope.launch {
            repository.updateProgress(book.id, pageIndex, total)
        }
    }

    fun toggleBookmark(book: EbookEntity) {
        viewModelScope.launch {
            repository.toggleBookmark(book)
        }
    }

    fun updateBookTags(book: EbookEntity, tags: List<String>) {
        viewModelScope.launch {
            repository.updateCustomTags(book, tags)
        }
    }

    fun updateBookCategory(book: EbookEntity, category: String) {
        viewModelScope.launch {
            repository.updateCategory(book, category)
        }
    }

    fun removeBookFromDownloads(book: EbookEntity) {
        viewModelScope.launch {
            repository.removeBook(book.id)
            _snackbarMessage.value = "Removed \"${book.title}\" from downloads"
        }
    }

    fun clearUnusedCache() {
        viewModelScope.launch {
            repository.clearUnusedCache()
            _snackbarMessage.value = "Cleared unused cached catalog entries"
        }
    }

    fun importLocalTextFile(uri: Uri, displayName: String) {
        viewModelScope.launch {
            val result = repository.importLocalTextBook(uri, displayName)
            result.onSuccess { book ->
                _snackbarMessage.value = "Imported \"${book.title}\""
            }.onFailure {
                _snackbarMessage.value = "Could not import file. Choose a plain .txt book."
            }
        }
    }

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    // TTS Controls
    fun startTtsFromCurrentPage() {
        val pages = _readerState.value.paginatedBook?.pages ?: return
        ttsController.playBookFromPage(pages, _readerState.value.currentPage)
    }

    fun startTtsForSelection(selectedText: String) {
        if (selectedText.isBlank()) {
            _snackbarMessage.value = "Select at least one paragraph or passage to read aloud"
            return
        }
        ttsController.playSelectedText(selectedText, _readerState.value.currentPage)
    }

    fun toggleTtsPlayPause() = ttsController.togglePlayPause()
    fun skipTtsNextSentence() = ttsController.skipNextSentence()
    fun skipTtsPreviousSentence() = ttsController.skipPreviousSentence()
    fun skipTtsNextParagraph() = ttsController.skipNextParagraph()
    fun skipTtsPreviousParagraph() = ttsController.skipPreviousParagraph()
    fun stopTts() = ttsController.stop()
    fun setTtsSpeechRate(rate: Float) = ttsController.setSpeechRate(rate)
    fun setTtsSpeechPitch(pitch: Float) = ttsController.setSpeechPitch(pitch)
    fun applyTtsPreset(preset: TtsVoicePreset) = ttsController.applyPreset(preset)
    fun previewTtsVoice() = ttsController.previewSelectedVoice()
    fun setTtsSleepTimer(minutes: Int?) = ttsController.setSleepTimer(minutes)
    fun selectTtsVoice(voiceId: String) = ttsController.selectVoice(voiceId)

    // Theme & Reading Preferences
    fun setThemeMode(mode: AppThemeMode) = viewModelScope.launch {
        prefsRepo.setThemeMode(mode)
    }

    fun toggleLightDarkTheme() = viewModelScope.launch {
        val next = if (preferences.value.themeMode == AppThemeMode.DARK) {
            AppThemeMode.LIGHT
        } else {
            AppThemeMode.DARK
        }
        prefsRepo.setThemeMode(next)
    }

    fun setReaderPaperMode(mode: ReaderPaperMode) = viewModelScope.launch {
        prefsRepo.setReaderPaperMode(mode)
    }

    fun setFontSize(sizeSp: Float) = viewModelScope.launch {
        prefsRepo.setFontSize(sizeSp)
        val activeBook = _readerState.value.book ?: return@launch
        val text = repository.readBookTextIfAvailable(activeBook)
        if (!text.isNullOrBlank()) {
            val repaginated = withContext(Dispatchers.Default) {
                BookPaginationEngine.paginate(text, sizeSp)
            }
            val ratio = if ((_readerState.value.paginatedBook?.pages?.size ?: 1) > 1) {
                _readerState.value.currentPage.toFloat() /
                    (_readerState.value.paginatedBook!!.pages.size - 1).toFloat()
            } else 0f
            val newPage = (ratio * (repaginated.pages.size - 1)).toInt()
                .coerceIn(0, (repaginated.pages.size - 1).coerceAtLeast(0))
            _readerState.update {
                it.copy(paginatedBook = repaginated, currentPage = newPage)
            }
        }
    }

    fun setLineHeight(multiplier: Float) = viewModelScope.launch {
        prefsRepo.setLineHeight(multiplier)
    }

    fun setReaderFontStyle(style: ReaderFontStyle) = viewModelScope.launch {
        prefsRepo.setReaderFontStyle(style)
    }

    fun setPageTurnMode(mode: PageTurnMode) = viewModelScope.launch {
        prefsRepo.setPageTurnMode(mode)
    }

    fun setBlurIntensity(intensity: Float) = viewModelScope.launch {
        prefsRepo.setBlurIntensity(intensity)
    }

    fun setPerformanceMode(mode: PerformanceMode) = viewModelScope.launch {
        prefsRepo.setPerformanceMode(mode)
    }

    override fun onCleared() {
        ttsController.release()
        super.onCleared()
    }
}
