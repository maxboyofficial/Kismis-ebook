package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryBooks
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.local.EbookEntity
import com.example.ui.theme.LocalKismisGlassColors
import com.example.ui.theme.LocalKismisLiteMode
import com.example.ui.theme.PlayfairDisplayFamily
import com.example.ui.viewmodel.MainTab
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Lightweight, high-FPS radial backdrop with soft Blue & Orange ambient glows.
 * Avoids full-screen offscreen RenderEffect blur passes on every frame so scrolling
 * and page transitions stay consistently smooth at 60-120fps.
 */
@Composable
fun AmbientGlassBackdrop(
    blurIntensity: Float = 1.0f,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val alphaScale = blurIntensity.coerceIn(0.3f, 1.3f)

    if (isLiteMode) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            glass.orbPrimary.copy(alpha = (glass.orbPrimary.alpha * 0.45f).coerceAtMost(0.18f)),
                            MaterialTheme.colorScheme.background,
                            glass.orbSecondary.copy(alpha = (glass.orbSecondary.alpha * 0.35f).coerceAtMost(0.14f))
                        )
                    )
                )
        )
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val blueCenter = Offset(w * 0.16f, h * 0.12f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glass.orbPrimary.copy(alpha = (glass.orbPrimary.alpha * alphaScale).coerceAtMost(0.45f)),
                        Color.Transparent
                    ),
                    center = blueCenter,
                    radius = w * 0.75f
                ),
                radius = w * 0.75f,
                center = blueCenter
            )

            val orangeCenter = Offset(w * 0.88f, h * 0.36f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glass.orbSecondary.copy(alpha = (glass.orbSecondary.alpha * alphaScale).coerceAtMost(0.40f)),
                        Color.Transparent
                    ),
                    center = orangeCenter,
                    radius = w * 0.68f
                ),
                radius = w * 0.68f,
                center = orangeCenter
            )

            val lowerCenter = Offset(w * 0.35f, h * 0.86f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glass.orbTertiary.copy(alpha = (glass.orbTertiary.alpha * alphaScale).coerceAtMost(0.35f)),
                        Color.Transparent
                    ),
                    center = lowerCenter,
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = lowerCenter
            )
        }
    }
}

/**
 * Crisp Apple-style frosted glass surface with snappy spring press physics,
 * tactile haptic feedback, and responsive Material ripple indication.
 * Automatically switches to low-overdraw mode when [LocalKismisLiteMode] is active.
 */
@Composable
fun FrostedGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    elevated: Boolean = false,
    onClick: (() -> Unit)? = null,
    contentPadding: Dp = 0.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val view = LocalView.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (!isLiteMode && isPressed && onClick != null) 0.968f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "glass_press_scale"
    )

    val fillColor = if (elevated) glass.glassSurfaceElevated else glass.glassSurface
    val sheenTop = if (glass.isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.55f)
    val sheenBottom = if (glass.isDark) Color.White.copy(alpha = 0.04f) else Color.White.copy(alpha = 0.10f)

    val borderBrush = Brush.linearGradient(
        colors = listOf(glass.glassBorderStart, glass.glassBorderEnd)
    )

    Surface(
        modifier = modifier
            .then(
                if (!isLiteMode) {
                    Modifier
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .shadow(
                            elevation = if (glass.isDark) 10.dp else 8.dp,
                            shape = shape,
                            ambientColor = if (glass.isDark) Color.Black else Color(0xFF141821).copy(alpha = 0.16f),
                            spotColor = if (glass.isDark) Color.Black else Color(0xFF141821).copy(alpha = 0.14f)
                        )
                } else {
                    Modifier
                }
            )
            .clip(shape)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = ripple(bounded = true, color = glass.brandBlue),
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            onClick()
                        }
                    )
                } else {
                    Modifier
                }
            ),
        shape = shape,
        color = fillColor,
        border = BorderStroke(if (glass.isDark) 1.dp else 1.2.dp, borderBrush)
    ) {
        Box(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(sheenTop, sheenBottom)))
                .padding(contentPadding),
            content = content
        )
    }
}

/**
 * Dark Frosted Glass Dock surface with crisp specular border and internal
 * Blue & Orange vibrancy refraction.
 */
@Composable
fun DockFrostedSurface(
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val view = LocalView.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (!isLiteMode && isPressed && onClick != null) 0.94f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "dock_press_scale"
    )

    Surface(
        modifier = modifier
            .then(
                if (!isLiteMode) {
                    Modifier
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .shadow(
                            elevation = 16.dp,
                            shape = shape,
                            ambientColor = Color.Black.copy(alpha = 0.34f),
                            spotColor = Color.Black.copy(alpha = 0.28f)
                        )
                } else {
                    Modifier
                }
            )
            .clip(shape)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = ripple(bounded = true, color = Color.White),
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            onClick()
                        }
                    )
                } else {
                    Modifier
                }
            ),
        shape = shape,
        color = glass.dockSurface,
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.verticalGradient(listOf(glass.dockBorderStart, glass.dockBorderEnd))
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (!isLiteMode) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(glass.brandBlue.copy(alpha = 0.18f), Color.Transparent),
                            center = Offset(size.width * 0.22f, size.height * 0.5f),
                            radius = size.height * 1.1f
                        ),
                        radius = size.height * 1.1f,
                        center = Offset(size.width * 0.22f, size.height * 0.5f)
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(glass.brandOrange.copy(alpha = 0.16f), Color.Transparent),
                            center = Offset(size.width * 0.80f, size.height * 0.45f),
                            radius = size.height * 1.0f
                        ),
                        radius = size.height * 1.0f,
                        center = Offset(size.width * 0.80f, size.height * 0.45f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to glass.dockSheenTop,
                            0.45f to Color.Transparent,
                            1f to glass.dockSheenBottom
                        )
                    ),
                content = content
            )
        }
    }
}

@Composable
fun WavySectionDivider(
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(14.dp)
    ) {
        val path = Path()
        val midY = size.height / 2f
        val amplitude = 2.6.dp.toPx()
        val waveLength = 22.dp.toPx()

        path.moveTo(0f, midY)
        var x = 0f
        while (x <= size.width) {
            val y = midY + amplitude * sin((x / waveLength) * 2f * PI.toFloat())
            path.lineTo(x, y)
            x += 4f
        }
        drawPath(
            path = path,
            color = glass.dividerWave,
            style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

@Composable
fun FloatingFrostedBottomBar(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()

    val tabs = remember {
        listOf(
            Triple(MainTab.HOME, "Home", Icons.Rounded.Home),
            Triple(MainTab.LIBRARY, "Library", Icons.Rounded.LibraryBooks),
            Triple(MainTab.SETTINGS, "Settings", Icons.Rounded.Settings)
        )
    }
    val selectedIndex = tabs.indexOfFirst { it.first == selectedTab }.coerceAtLeast(0)

    var isScrubbing by remember { mutableStateOf(false) }
    var dragVelocityStretch by remember { mutableFloatStateOf(0f) }
    var lastHapticTabIndex by remember { mutableIntStateOf(selectedIndex) }

    val pillFillBrush = remember(glass.dockPillTop, glass.dockPillBottom) {
        Brush.verticalGradient(
            0f to glass.dockPillTop,
            0.55f to glass.dockPillTop.copy(alpha = 0.82f),
            1f to glass.dockPillBottom
        )
    }
    val pillBorderBrush = remember(glass.dockPillBorder, glass.brandOrange) {
        Brush.verticalGradient(
            listOf(
                glass.dockPillBorder,
                glass.brandOrange.copy(alpha = 0.28f)
            )
        )
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DockFrostedSurface(
            modifier = Modifier
                .weight(1f)
                .height(66.dp),
            shape = CircleShape
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(5.dp)
            ) {
                val segmentWidth = maxWidth / tabs.size
                val segmentWidthPx = with(density) { segmentWidth.toPx() }
                val maxPillOffsetPx = (segmentWidthPx * (tabs.size - 1)).coerceAtLeast(1f)

                var scrubPillPx by remember { mutableFloatStateOf(segmentWidthPx * selectedIndex) }
                val pillOffsetAnim = remember { Animatable(segmentWidthPx * selectedIndex) }

                LaunchedEffect(selectedIndex, segmentWidthPx, isScrubbing) {
                    if (!isScrubbing) {
                        val targetPx = (segmentWidthPx * selectedIndex).coerceIn(0f, maxPillOffsetPx)
                        if (isLiteMode) {
                            pillOffsetAnim.snapTo(targetPx)
                        } else {
                            pillOffsetAnim.animateTo(
                                targetValue = targetPx,
                                animationSpec = spring(
                                    dampingRatio = 0.78f,
                                    stiffness = 620f
                                )
                            )
                        }
                    }
                }

                val pillScaleX by animateFloatAsState(
                    targetValue = if (isScrubbing) 1.07f + dragVelocityStretch else 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "pill_lens_scale_x"
                )
                val pillScaleY by animateFloatAsState(
                    targetValue = if (isScrubbing) 1.11f - (dragVelocityStretch * 0.35f) else 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "pill_lens_scale_y"
                )

                val gestureModifier = Modifier.pointerInput(tabs.size, segmentWidthPx) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val downIndex = (down.position.x / segmentWidthPx)
                            .toInt()
                            .coerceIn(0, tabs.lastIndex)

                        var dragged = false
                        var latestX = down.position.x
                        var prevX = down.position.x
                        lastHapticTabIndex = selectedIndex

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                dragVelocityStretch = 0f
                                val targetIdx = if (dragged) {
                                    ((latestX - segmentWidthPx / 2f) / segmentWidthPx)
                                        .roundToInt()
                                        .coerceIn(0, tabs.lastIndex)
                                } else {
                                    downIndex
                                }
                                if (dragged) {
                                    val releasePx = scrubPillPx
                                    coroutineScope.launch {
                                        pillOffsetAnim.snapTo(releasePx)
                                        isScrubbing = false
                                    }
                                } else {
                                    isScrubbing = false
                                }
                                onTabSelected(tabs[targetIdx].first)
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                break
                            }

                            val dx = abs(change.position.x - down.position.x)
                            val holdElapsed = (change.uptimeMillis - down.uptimeMillis) > 110L
                            if (!dragged && (dx > viewConfiguration.touchSlop * 0.4f || holdElapsed)) {
                                dragged = true
                                scrubPillPx = (change.position.x - segmentWidthPx / 2f)
                                    .coerceIn(0f, maxPillOffsetPx)
                                isScrubbing = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }

                            if (dragged) {
                                change.consume()
                                latestX = change.position.x
                                val stepDelta = abs(latestX - prevX)
                                prevX = latestX
                                dragVelocityStretch = (stepDelta * 0.0045f).coerceIn(0f, 0.09f)

                                scrubPillPx = (latestX - segmentWidthPx / 2f)
                                    .coerceIn(0f, maxPillOffsetPx)

                                val hoveredIdx = (latestX / segmentWidthPx)
                                    .toInt()
                                    .coerceIn(0, tabs.lastIndex)
                                if (hoveredIdx != lastHapticTabIndex) {
                                    lastHapticTabIndex = hoveredIdx
                                    onTabSelected(tabs[hoveredIdx].first)
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                }
                            }
                        }
                    }
                }

                val pillShadowPx = with(density) { (if (isScrubbing) 12.dp else 5.dp).toPx() }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(gestureModifier)
                ) {
                    // GPU-translated Frosted White Movable Pill (zero layout pass during scroll/animation)
                    Box(
                        modifier = Modifier
                            .width(segmentWidth)
                            .fillMaxHeight()
                            .graphicsLayer {
                                translationX = if (isScrubbing) scrubPillPx else pillOffsetAnim.value
                                scaleX = pillScaleX
                                scaleY = pillScaleY
                                if (!isLiteMode) {
                                    shadowElevation = pillShadowPx
                                    shape = CircleShape
                                    ambientShadowColor = Color.White.copy(alpha = 0.30f)
                                    spotShadowColor = Color.Black.copy(alpha = 0.25f)
                                }
                            }
                            .clip(CircleShape)
                            .background(pillFillBrush)
                            .border(
                                width = 1.1.dp,
                                brush = pillBorderBrush,
                                shape = CircleShape
                            )
                    )

                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        tabs.forEach { (tab, label, icon) ->
                            val isSelected = tab == selectedTab
                            val contentColor by animateColorAsState(
                                targetValue = if (isSelected) glass.dockContentActive else glass.dockContentInactive,
                                animationSpec = tween(if (isLiteMode) 0 else 150),
                                label = "tab_color_$label"
                            )
                            val iconScale by animateFloatAsState(
                                targetValue = if (isSelected && !isLiteMode) 1.10f else 1f,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMedium
                                ),
                                label = "tab_scale_$label"
                            )

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(CircleShape)
                                    .minimumInteractiveComponentSize()
                                    .testTag("nav_tab_${tab.name.lowercase()}"),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = contentColor,
                                    modifier = Modifier
                                        .size(21.dp)
                                        .graphicsLayer {
                                            scaleX = iconScale
                                            scaleY = iconScale
                                        }
                                )
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 10.sp
                                    ),
                                    color = contentColor,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Detached Search Button with Frosted White Inner Disc
        DockFrostedSurface(
            modifier = Modifier
                .size(64.dp)
                .minimumInteractiveComponentSize()
                .testTag("floating_search_button"),
            shape = CircleShape,
            onClick = onSearchClick
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(listOf(glass.dockPillTop, glass.dockPillBottom))
                        )
                        .border(1.dp, glass.dockPillBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search e-Books",
                        tint = glass.brandOrange,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

/**
 * Tablet / Foldable left-side Apple-style dark frosted Navigation Rail with
 * movable frosted white pill and detached Search disc.
 */
@Composable
fun FloatingFrostedNavigationRail(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()

    val tabs = remember {
        listOf(
            Triple(MainTab.HOME, "Home", Icons.Rounded.Home),
            Triple(MainTab.LIBRARY, "Library", Icons.Rounded.LibraryBooks),
            Triple(MainTab.SETTINGS, "Settings", Icons.Rounded.Settings)
        )
    }
    val selectedIndex = tabs.indexOfFirst { it.first == selectedTab }.coerceAtLeast(0)

    var isScrubbing by remember { mutableStateOf(false) }
    var lastHapticTabIndex by remember { mutableIntStateOf(selectedIndex) }

    val pillFillBrush = remember(glass.dockPillTop, glass.dockPillBottom) {
        Brush.verticalGradient(
            0f to glass.dockPillTop,
            0.55f to glass.dockPillTop.copy(alpha = 0.82f),
            1f to glass.dockPillBottom
        )
    }
    val pillBorderBrush = remember(glass.dockPillBorder, glass.brandOrange) {
        Brush.verticalGradient(
            listOf(
                glass.dockPillBorder,
                glass.brandOrange.copy(alpha = 0.28f)
            )
        )
    }

    Column(
        modifier = modifier
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp)
            .width(84.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        DockFrostedSurface(
            modifier = Modifier
                .width(78.dp)
                .height(252.dp),
            shape = RoundedCornerShape(39.dp)
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp)
            ) {
                val segmentHeight = maxHeight / tabs.size
                val segmentHeightPx = with(density) { segmentHeight.toPx() }
                val maxPillOffsetPx = (segmentHeightPx * (tabs.size - 1)).coerceAtLeast(1f)

                var scrubPillPx by remember { mutableFloatStateOf(segmentHeightPx * selectedIndex) }
                val pillOffsetAnim = remember { Animatable(segmentHeightPx * selectedIndex) }

                LaunchedEffect(selectedIndex, segmentHeightPx, isScrubbing) {
                    if (!isScrubbing) {
                        val targetPx = (segmentHeightPx * selectedIndex).coerceIn(0f, maxPillOffsetPx)
                        if (isLiteMode) {
                            pillOffsetAnim.snapTo(targetPx)
                        } else {
                            pillOffsetAnim.animateTo(
                                targetValue = targetPx,
                                animationSpec = spring(dampingRatio = 0.78f, stiffness = 620f)
                            )
                        }
                    }
                }

                val pillScaleX by animateFloatAsState(
                    targetValue = if (isScrubbing) 1.07f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "rail_pill_scale_x"
                )
                val pillScaleY by animateFloatAsState(
                    targetValue = if (isScrubbing) 1.09f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "rail_pill_scale_y"
                )

                val gestureModifier = Modifier.pointerInput(tabs.size, segmentHeightPx) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val downIndex = (down.position.y / segmentHeightPx)
                            .toInt()
                            .coerceIn(0, tabs.lastIndex)

                        var dragged = false
                        var latestY = down.position.y
                        lastHapticTabIndex = selectedIndex

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                val targetIdx = if (dragged) {
                                    ((latestY - segmentHeightPx / 2f) / segmentHeightPx)
                                        .roundToInt()
                                        .coerceIn(0, tabs.lastIndex)
                                } else {
                                    downIndex
                                }
                                if (dragged) {
                                    val releasePx = scrubPillPx
                                    coroutineScope.launch {
                                        pillOffsetAnim.snapTo(releasePx)
                                        isScrubbing = false
                                    }
                                } else {
                                    isScrubbing = false
                                }
                                onTabSelected(tabs[targetIdx].first)
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                break
                            }

                            val dy = abs(change.position.y - down.position.y)
                            val holdElapsed = (change.uptimeMillis - down.uptimeMillis) > 110L
                            if (!dragged && (dy > viewConfiguration.touchSlop * 0.4f || holdElapsed)) {
                                dragged = true
                                scrubPillPx = (change.position.y - segmentHeightPx / 2f)
                                    .coerceIn(0f, maxPillOffsetPx)
                                isScrubbing = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }

                            if (dragged) {
                                change.consume()
                                latestY = change.position.y
                                scrubPillPx = (latestY - segmentHeightPx / 2f)
                                    .coerceIn(0f, maxPillOffsetPx)

                                val hoveredIdx = (latestY / segmentHeightPx)
                                    .toInt()
                                    .coerceIn(0, tabs.lastIndex)
                                if (hoveredIdx != lastHapticTabIndex) {
                                    lastHapticTabIndex = hoveredIdx
                                    onTabSelected(tabs[hoveredIdx].first)
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                }
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(gestureModifier)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(segmentHeight)
                            .graphicsLayer {
                                translationY = if (isScrubbing) scrubPillPx else pillOffsetAnim.value
                                scaleX = pillScaleX
                                scaleY = pillScaleY
                            }
                            .clip(RoundedCornerShape(32.dp))
                            .background(pillFillBrush)
                            .border(
                                width = 1.1.dp,
                                brush = pillBorderBrush,
                                shape = RoundedCornerShape(32.dp)
                            )
                    )

                    Column(modifier = Modifier.fillMaxSize()) {
                        tabs.forEach { (tab, label, icon) ->
                            val isSelected = tab == selectedTab
                            val contentColor by animateColorAsState(
                                targetValue = if (isSelected) glass.dockContentActive else glass.dockContentInactive,
                                animationSpec = tween(if (isLiteMode) 0 else 150),
                                label = "rail_tab_color_$label"
                            )
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(32.dp))
                                    .minimumInteractiveComponentSize()
                                    .testTag("nav_rail_${tab.name.lowercase()}"),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = contentColor,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 10.sp
                                    ),
                                    color = contentColor,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        DockFrostedSurface(
            modifier = Modifier
                .size(64.dp)
                .minimumInteractiveComponentSize()
                .testTag("floating_search_button"),
            shape = CircleShape,
            onClick = onSearchClick
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(listOf(glass.dockPillTop, glass.dockPillBottom))
                        )
                        .border(1.dp, glass.dockPillBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search e-Books",
                        tint = glass.brandOrange,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun BookCoverView(
    book: EbookEntity,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp
) {
    val isLiteMode = LocalKismisLiteMode.current
    val context = LocalContext.current
    val shape = RoundedCornerShape(cornerRadius)
    val localDrawableId = remember(book.coverResName) {
        when (book.coverResName) {
            "img_cover_wonderland" -> R.drawable.img_cover_wonderland
            "img_cover_earnest" -> R.drawable.img_cover_earnest
            "img_cover_sherlock" -> R.drawable.img_cover_sherlock
            "img_cover_timemachine" -> R.drawable.img_cover_timemachine
            else -> null
        }
    }

    Box(
        modifier = modifier
            .then(
                if (!isLiteMode) {
                    Modifier.shadow(
                        elevation = 6.dp,
                        shape = shape,
                        ambientColor = Color(book.accentColorHex).copy(alpha = 0.22f)
                    )
                } else {
                    Modifier
                }
            )
            .clip(shape)
            .background(Color(book.accentColorHex))
    ) {
        when {
            localDrawableId != null -> {
                Image(
                    painter = painterResource(id = localDrawableId),
                    contentDescription = "${book.title} cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            !book.coverUrl.isNullOrBlank() -> {
                val request = remember(book.coverUrl, isLiteMode) {
                    ImageRequest.Builder(context)
                        .data(book.coverUrl)
                        .size(200, 300)
                        .allowRgb565(true)
                        .crossfade(if (isLiteMode) 0 else 150)
                        .build()
                }
                AsyncImage(
                    model = request,
                    contentDescription = "${book.title} cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            else -> {
                val baseColor = Color(book.accentColorHex)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    baseColor,
                                    baseColor.copy(alpha = 0.72f),
                                    Color(0xFF141720)
                                )
                            )
                        )
                        .padding(10.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.MenuBook,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.24f),
                        modifier = Modifier
                            .size(34.dp)
                            .align(Alignment.TopEnd)
                    )
                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = PlayfairDisplayFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color.White,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(6.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.28f),
                            Color.Black.copy(alpha = 0.14f),
                            Color.Transparent
                        )
                    )
                )
        )
    }
}
