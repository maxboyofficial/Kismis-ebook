package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.EbookEntity
import com.example.data.local.PageTurnMode
import com.example.data.local.ReaderFontStyle
import com.example.data.local.ReaderPaperMode
import com.example.data.local.ReaderPreferencesState
import com.example.tts.TtsUiState
import com.example.tts.TtsVoicePreset
import com.example.ui.components.FrostedGlassSurface
import com.example.ui.theme.LocalKismisGlassColors
import com.example.ui.theme.LocalKismisLiteMode
import com.example.ui.theme.LoraSerifFamily
import com.example.ui.theme.PlayfairDisplayFamily
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.ui.theme.ReaderDarkBg
import com.example.ui.theme.ReaderDarkText
import com.example.ui.theme.ReaderSepiaBg
import com.example.ui.theme.ReaderSepiaText
import com.example.ui.theme.ReaderWhiteBg
import com.example.ui.theme.ReaderWhiteText
import com.example.ui.viewmodel.ReaderUiState
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    readerState: ReaderUiState,
    preferences: ReaderPreferencesState,
    ttsState: TtsUiState,
    isAppDark: Boolean,
    onBack: () -> Unit,
    onPageChanged: (Int) -> Unit,
    onToggleBookmark: (EbookEntity) -> Unit,
    onPaperModeChange: (ReaderPaperMode) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onLineHeightChange: (Float) -> Unit,
    onFontStyleChange: (ReaderFontStyle) -> Unit,
    onPageTurnModeChange: (PageTurnMode) -> Unit,
    onPlayBookFromCurrentPage: () -> Unit,
    onPlaySelectedPassage: (String) -> Unit,
    onToggleTtsPlayPause: () -> Unit,
    onSkipNextSentence: () -> Unit,
    onSkipPreviousSentence: () -> Unit,
    onSkipNextParagraph: () -> Unit,
    onSkipPreviousParagraph: () -> Unit,
    onStopTts: () -> Unit,
    onTtsRateChange: (Float) -> Unit,
    onTtsPitchChange: (Float) -> Unit = {},
    onApplyTtsPreset: (TtsVoicePreset) -> Unit = {},
    onPreviewTtsVoice: () -> Unit = {},
    onSetTtsSleepTimer: (Int?) -> Unit = {},
    onSelectTtsVoice: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalKismisGlassColors.current
    val isLiteMode = LocalKismisLiteMode.current
    val scope = rememberCoroutineScope()

    var showHud by remember { mutableStateOf(true) }
    var showChaptersSheet by remember { mutableStateOf(false) }
    var showAppearanceSheet by remember { mutableStateOf(false) }
    var showTtsControlsSheet by remember { mutableStateOf(false) }
    var showPassageSelectorSheet by remember { mutableStateOf(false) }

    BackHandler {
        if (ttsState.isActive) onStopTts()
        onBack()
    }

    val effectiveDark = when (preferences.readerPaperMode) {
        ReaderPaperMode.AUTO -> isAppDark
        ReaderPaperMode.WHITE -> false
        ReaderPaperMode.SEPIA -> false
        ReaderPaperMode.DARK -> true
    }

    val targetPaperBg = when (preferences.readerPaperMode) {
        ReaderPaperMode.AUTO -> if (isAppDark) ReaderDarkBg else ReaderWhiteBg
        ReaderPaperMode.WHITE -> ReaderWhiteBg
        ReaderPaperMode.SEPIA -> ReaderSepiaBg
        ReaderPaperMode.DARK -> ReaderDarkBg
    }
    val targetPaperText = when (preferences.readerPaperMode) {
        ReaderPaperMode.AUTO -> if (isAppDark) ReaderDarkText else ReaderWhiteText
        ReaderPaperMode.WHITE -> ReaderWhiteText
        ReaderPaperMode.SEPIA -> ReaderSepiaText
        ReaderPaperMode.DARK -> ReaderDarkText
    }

    val paperBg by animateColorAsState(targetPaperBg, tween(240), label = "paper_bg")
    val paperText by animateColorAsState(targetPaperText, tween(240), label = "paper_text")

    val readingFontFamily = when (preferences.readerFontStyle) {
        ReaderFontStyle.SERIF -> LoraSerifFamily
        ReaderFontStyle.SANS -> PlusJakartaSansFamily
        ReaderFontStyle.DISPLAY -> PlayfairDisplayFamily
    }

    val paginated = readerState.paginatedBook
    val pages = paginated?.pages ?: emptyList()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(paperBg)
    ) {
        when {
            readerState.isLoading -> {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = glass.brandBlue)
                    Text(
                        text = "Preparing your e-book…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = paperText.copy(alpha = 0.72f)
                    )
                }
            }

            readerState.errorMessage != null -> {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = readerState.errorMessage,
                        style = MaterialTheme.typography.bodyLarge,
                        color = paperText
                    )
                    FrostedGlassSurface(
                        shape = CircleShape,
                        onClick = onBack,
                        contentPadding = 12.dp
                    ) {
                        Text(
                            text = "Go Back",
                            style = MaterialTheme.typography.labelLarge,
                            color = glass.brandBlue,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
            }

            pages.isNotEmpty() -> {
                if (preferences.pageTurnMode == PageTurnMode.HORIZONTAL_PAGER) {
                    val pagerState = rememberPagerState(
                        initialPage = readerState.currentPage.coerceIn(0, pages.lastIndex),
                        pageCount = { pages.size }
                    )

                    LaunchedEffect(readerState.currentPage, pages.size) {
                        val target = readerState.currentPage.coerceIn(0, pages.lastIndex)
                        if (pagerState.currentPage != target && !pagerState.isScrollInProgress) {
                            pagerState.animateScrollToPage(target)
                        }
                    }

                    LaunchedEffect(pagerState) {
                        snapshotFlow { pagerState.currentPage }.collect { settledPage ->
                            onPageChanged(settledPage)
                        }
                    }

                    HorizontalPager(
                        state = pagerState,
                        beyondViewportPageCount = 0,
                        modifier = Modifier.fillMaxSize()
                    ) { pageIdx ->
                        val page = pages[pageIdx]
                        val pageOffset = ((pagerState.currentPage - pageIdx) + pagerState.currentPageOffsetFraction).absoluteValue
                        val paragraphs = remember(page.text) {
                            page.text.split(Regex("""\n\s*\n""")).filter { it.isNotBlank() }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .then(
                                    if (!isLiteMode) {
                                        Modifier.graphicsLayer {
                                            val scale = 1f - (pageOffset.coerceIn(0f, 1f) * 0.04f)
                                            scaleX = scale
                                            scaleY = scale
                                            alpha = 1f - (pageOffset.coerceIn(0f, 1f) * 0.28f)
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) { showHud = !showHud }
                                .statusBarsPadding()
                                .navigationBarsPadding()
                                .padding(
                                    start = 24.dp,
                                    end = 24.dp,
                                    top = 68.dp,
                                    bottom = if (ttsState.isActive && !showHud) 92.dp else 72.dp
                                )
                        ) {
                            Column(
                                modifier = Modifier
                                    .widthIn(max = 680.dp)
                                    .fillMaxSize()
                                    .align(Alignment.TopCenter)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                if (page.isChapterStart) {
                                    Text(
                                        text = page.chapterTitle,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontFamily = PlayfairDisplayFamily,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = glass.brandBlue
                                    )
                                }

                                val activeOffset = if (page.isChapterStart) 1 else 0
                                paragraphs.forEachIndexed { pIdx, para ->
                                    val isSpokenParagraph = ttsState.isActive &&
                                        !ttsState.isSelectionMode &&
                                        ttsState.currentPageIndex == pageIdx &&
                                        ttsState.currentParagraphIndex == (pIdx + activeOffset)

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                if (isSpokenParagraph) glass.brandOrange.copy(alpha = 0.13f) else Color.Transparent
                                            )
                                            .padding(
                                                horizontal = if (isSpokenParagraph) 8.dp else 0.dp,
                                                vertical = if (isSpokenParagraph) 6.dp else 0.dp
                                            )
                                    ) {
                                        Text(
                                            text = para,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontFamily = readingFontFamily,
                                                fontSize = preferences.fontSizeSp.sp,
                                                lineHeight = (preferences.fontSizeSp * preferences.lineHeightMultiplier).sp
                                            ),
                                            color = paperText
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "${pageIdx + 1} / ${pages.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = paperText.copy(alpha = 0.45f),
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 4.dp)
                            )
                        }
                    }
                } else {
                    val listState = rememberLazyListState(
                        initialFirstVisibleItemIndex = readerState.currentPage.coerceIn(0, pages.lastIndex)
                    )
                    LaunchedEffect(listState) {
                        snapshotFlow { listState.firstVisibleItemIndex }.collect { idx ->
                            onPageChanged(idx)
                        }
                    }

                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { showHud = !showHud },
                        contentPadding = PaddingValues(
                            start = 24.dp,
                            end = 24.dp,
                            top = 96.dp,
                            bottom = 128.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        items(pages, key = { it.pageIndex }) { page ->
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    modifier = Modifier
                                        .widthIn(max = 680.dp)
                                        .fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    if (page.isChapterStart) {
                                        Text(
                                            text = page.chapterTitle,
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontFamily = PlayfairDisplayFamily,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = glass.brandBlue
                                        )
                                    }
                                    Text(
                                        text = page.text,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontFamily = readingFontFamily,
                                            fontSize = preferences.fontSizeSp.sp,
                                            lineHeight = (preferences.fontSizeSp * preferences.lineHeightMultiplier).sp
                                        ),
                                        color = paperText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Top Frosted Glass HUD
        AnimatedVisibility(
            visible = showHud,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            val currentBook = readerState.book
            val currentChapter = pages.getOrNull(readerState.currentPage)?.chapterTitle ?: ""
            FrostedGlassSurface(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                shape = CircleShape,
                elevated = true,
                contentPadding = 6.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            if (ttsState.isActive) onStopTts()
                            onBack()
                        },
                        modifier = Modifier.testTag("reader_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = currentBook?.title ?: "Reading",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (currentChapter.isNotBlank()) {
                            Text(
                                text = currentChapter,
                                style = MaterialTheme.typography.labelSmall,
                                color = glass.brandOrange,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // TTS Read-Aloud Trigger Button
                        IconButton(
                            onClick = { showTtsControlsSheet = true },
                            modifier = Modifier.testTag("reader_tts_button")
                        ) {
                            Icon(
                                imageVector = if (ttsState.isPlaying) Icons.Rounded.GraphicEq else Icons.Rounded.RecordVoiceOver,
                                contentDescription = "Read aloud",
                                tint = if (ttsState.isActive) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (currentBook != null) {
                            IconButton(
                                onClick = { onToggleBookmark(currentBook) },
                                modifier = Modifier.testTag("reader_bookmark_button")
                            ) {
                                Icon(
                                    imageVector = if (currentBook.isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = if (currentBook.isBookmarked) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        IconButton(
                            onClick = { showChaptersSheet = true },
                            modifier = Modifier.testTag("reader_chapters_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.FormatListBulleted,
                                contentDescription = "Chapters",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Compact Non-Obstructive Floating TTS Mini-Player Pill
        AnimatedVisibility(
            visible = ttsState.isActive,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(
                    start = 14.dp,
                    end = 14.dp,
                    bottom = if (showHud) 104.dp else 14.dp
                )
        ) {
            FrostedGlassSurface(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .testTag("tts_mini_player"),
                shape = CircleShape,
                elevated = true,
                contentPadding = 6.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(
                            onClick = onSkipPreviousSentence,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                Icons.Rounded.SkipPrevious,
                                contentDescription = "Previous sentence",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(glass.brandOrange)
                                .clickable(onClick = onToggleTtsPlayPause)
                                .testTag("tts_play_pause_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (ttsState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (ttsState.isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        IconButton(
                            onClick = onSkipNextSentence,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                Icons.Rounded.SkipNext,
                                contentDescription = "Next sentence",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showTtsControlsSheet = true }
                            .padding(horizontal = 8.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = buildString {
                                append(ttsState.activePreset.label)
                                append(" • ${String.format("%.2gx", ttsState.speechRate)}")
                                ttsState.sleepTimerMinutes?.let { append(" • ${it}m timer") }
                            },
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = glass.brandOrange,
                            maxLines = 1
                        )
                        Text(
                            text = ttsState.currentSpokenText.ifBlank {
                                "${ttsState.currentSegmentIndex + 1}/${ttsState.totalSegments}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showTtsControlsSheet = true },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Tune,
                                contentDescription = "TTS settings",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = onStopTts,
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("tts_stop_button")
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Stop reading aloud",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Frosted Glass HUD
        AnimatedVisibility(
            visible = showHud && pages.isNotEmpty(),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            val total = pages.size.coerceAtLeast(1)
            val current = readerState.currentPage.coerceIn(0, total - 1)
            val percent = (((current + 1).toFloat() / total.toFloat()) * 100f).toInt().coerceIn(1, 100)

            FrostedGlassSurface(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                elevated = true,
                contentPadding = 12.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Page ${current + 1} of $total",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$percent%",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = glass.brandBlue
                            )
                        }
                        if (total > 1) {
                            Slider(
                                value = current.toFloat(),
                                onValueChange = { onPageChanged(it.toInt()) },
                                valueRange = 0f..(total - 1).toFloat(),
                                colors = SliderDefaults.colors(
                                    thumbColor = glass.brandOrange,
                                    activeTrackColor = glass.brandBlue
                                ),
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(glass.brandBlueSoft)
                            .minimumInteractiveComponentSize()
                            .clickable { showAppearanceSheet = true }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("reader_appearance_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.TextFields,
                                contentDescription = "Typography & theme",
                                tint = glass.brandBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Aa",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = glass.brandBlue
                            )
                        }
                    }
                }
            }
        }

        // TTS Controls & Voice Sheet
        if (showTtsControlsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showTtsControlsSheet = false },
                containerColor = if (effectiveDark) Color(0xFF171B24) else Color(0xFFFCFDFE)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Read Aloud (TTS)",
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = PlayfairDisplayFamily)
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(glass.brandBlueSoft)
                                .clickable { onPreviewTtsVoice() }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("tts_preview_voice_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.VolumeUp,
                                    contentDescription = "Test voice",
                                    tint = glass.brandBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Test Voice",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = glass.brandBlue
                                )
                            }
                        }
                    }

                    if (ttsState.errorMessage != null) {
                        Text(
                            text = ttsState.errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = glass.brandOrange
                        )
                    }

                    if (ttsState.currentSpokenText.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(glass.brandOrangeSoft)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "“${ttsState.currentSpokenText}”",
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 19.sp),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Whole Book vs Select Passage buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onPlayBookFromCurrentPage()
                                showTtsControlsSheet = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = glass.brandBlue),
                            shape = CircleShape,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("tts_read_book_button")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("Read Book", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                showTtsControlsSheet = false
                                showPassageSelectorSheet = true
                            },
                            shape = CircleShape,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("tts_select_passage_button")
                        ) {
                            Text("Select Passage", fontWeight = FontWeight.Bold, color = glass.brandOrange)
                        }
                    }

                    // Paragraph & Sentence Skip Controls
                    if (ttsState.isActive) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onSkipPreviousParagraph) {
                                Icon(Icons.Rounded.FastRewind, contentDescription = "Previous paragraph")
                            }
                            IconButton(onClick = onSkipPreviousSentence) {
                                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous sentence")
                            }
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(glass.brandOrange)
                                    .clickable(onClick = onToggleTtsPlayPause),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (ttsState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = "Play or pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            IconButton(onClick = onSkipNextSentence) {
                                Icon(Icons.Rounded.SkipNext, contentDescription = "Next sentence")
                            }
                            IconButton(onClick = onSkipNextParagraph) {
                                Icon(Icons.Rounded.FastForward, contentDescription = "Next paragraph")
                            }
                        }
                    }

                    // Voice Style Presets
                    Text("Voice Preset", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TtsVoicePreset.entries.forEach { preset ->
                            val selected = preset == ttsState.activePreset
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandOrange else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onApplyTtsPreset(preset) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("tts_preset_${preset.name.lowercase()}")
                            ) {
                                Text(
                                    text = preset.label,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Speed Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Reading Speed", style = MaterialTheme.typography.labelLarge)
                        Text("${String.format("%.2fx", ttsState.speechRate)}", color = glass.brandOrange, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = ttsState.speechRate,
                        onValueChange = onTtsRateChange,
                        valueRange = 0.7f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = glass.brandOrange,
                            activeTrackColor = glass.brandBlue
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0.8f, 0.95f, 1.15f, 1.35f, 1.65f).forEach { speed ->
                            val selected = kotlin.math.abs(ttsState.speechRate - speed) < 0.06f
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlueSoft else MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, if (selected) glass.brandBlue else Color.Transparent, CircleShape)
                                    .clickable { onTtsRateChange(speed) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${speed}x",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) glass.brandBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Voice Pitch Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Voice Tone / Pitch", style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = when {
                                ttsState.speechPitch < 0.92f -> "Warm Deep (${String.format("%.2f", ttsState.speechPitch)})"
                                ttsState.speechPitch > 1.06f -> "Crisp Bright (${String.format("%.2f", ttsState.speechPitch)})"
                                else -> "Natural (${String.format("%.2f", ttsState.speechPitch)})"
                            },
                            color = glass.brandBlue,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Slider(
                        value = ttsState.speechPitch,
                        onValueChange = onTtsPitchChange,
                        valueRange = 0.75f..1.35f,
                        colors = SliderDefaults.colors(
                            thumbColor = glass.brandBlue,
                            activeTrackColor = glass.brandOrange
                        )
                    )

                    // Voice Selector
                    if (ttsState.availableVoices.isNotEmpty()) {
                        Text("Narrator Voice", style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ttsState.availableVoices.forEach { voice ->
                                val selected = voice.id == ttsState.selectedVoiceId
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (selected) glass.brandBlue else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { onSelectTtsVoice(voice.id) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = if (voice.isNetwork) "${voice.displayName} • Cloud" else voice.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    // Sleep Timer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Bedtime,
                                contentDescription = null,
                                tint = glass.brandOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Text("Sleep Timer", style = MaterialTheme.typography.labelLarge)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(null to "Off", 10 to "10m", 20 to "20m", 30 to "30m").forEach { (mins, label) ->
                                val selected = ttsState.sleepTimerMinutes == mins ||
                                    (mins != null && ttsState.sleepTimerMinutes != null &&
                                        kotlin.math.abs(ttsState.sleepTimerMinutes - mins) <= 5 &&
                                        mins == 10 && ttsState.sleepTimerMinutes <= 10)
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (selected) glass.brandOrangeSoft else MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, if (selected) glass.brandOrange else Color.Transparent, CircleShape)
                                        .clickable { onSetTtsSleepTimer(mins) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (selected) glass.brandOrange else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        // Passage Selection Sheet (pick specific paragraphs from current page to read aloud)
        if (showPassageSelectorSheet && pages.isNotEmpty()) {
            val currentPage = pages[readerState.currentPage.coerceIn(0, pages.lastIndex)]
            val paragraphs = remember(currentPage.text) {
                currentPage.text.split(Regex("""\n\s*\n""")).filter { it.isNotBlank() }
            }
            val selectedIndices = remember(currentPage.pageIndex) { mutableStateListOf<Int>() }

            ModalBottomSheet(
                onDismissRequest = { showPassageSelectorSheet = false },
                containerColor = if (effectiveDark) Color(0xFF171B24) else Color(0xFFFCFDFE)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Select Text to Read Aloud",
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = PlayfairDisplayFamily)
                    )
                    Text(
                        text = "Tap one or more paragraphs from this page:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    LazyColumn(
                        modifier = Modifier.height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(paragraphs.indices.toList()) { idx ->
                            val isSelected = idx in selectedIndices
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (isSelected) glass.brandBlueSoft else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) glass.brandBlue else Color.Transparent,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable {
                                        if (isSelected) selectedIndices.remove(idx) else selectedIndices.add(idx)
                                    }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = if (isSelected) glass.brandBlue else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = paragraphs[idx],
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            val chosenText = selectedIndices
                                .sorted()
                                .mapNotNull { paragraphs.getOrNull(it) }
                                .joinToString("\n\n")
                            onPlaySelectedPassage(chosenText)
                            showPassageSelectorSheet = false
                        },
                        enabled = selectedIndices.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = glass.brandOrange),
                        shape = CircleShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("read_selected_passage_confirm")
                    ) {
                        Text(
                            text = "Read Selected (${selectedIndices.size})",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }

        // Chapters Table of Contents Sheet
        if (showChaptersSheet && paginated != null) {
            ModalBottomSheet(
                onDismissRequest = { showChaptersSheet = false },
                containerColor = if (effectiveDark) Color(0xFF171B24) else Color(0xFFFCFDFE)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Chapters",
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = PlayfairDisplayFamily),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    LazyColumn(
                        modifier = Modifier.height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(paginated.chapters) { chapter ->
                            val isCurrent = pages.getOrNull(readerState.currentPage)?.chapterTitle == chapter.title
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (isCurrent) glass.brandBlueSoft else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    )
                                    .clickable {
                                        scope.launch {
                                            onPageChanged(chapter.startPageIndex)
                                            showChaptersSheet = false
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = chapter.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                    ),
                                    color = if (isCurrent) glass.brandBlue else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "p. ${chapter.startPageIndex + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        // Reader Appearance Sheet ("Aa")
        if (showAppearanceSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAppearanceSheet = false },
                containerColor = if (effectiveDark) Color(0xFF171B24) else Color(0xFFFCFDFE)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Reading Appearance",
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = PlayfairDisplayFamily)
                    )

                    Text("Paper Surface", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReaderPaperMode.entries.forEach { mode ->
                            val selected = mode == preferences.readerPaperMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlue else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onPaperModeChange(mode) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Font Size", style = MaterialTheme.typography.labelLarge)
                        Text("${preferences.fontSizeSp.toInt()} sp", color = glass.brandBlue)
                    }
                    Slider(
                        value = preferences.fontSizeSp,
                        onValueChange = onFontSizeChange,
                        valueRange = 14f..26f,
                        colors = SliderDefaults.colors(
                            thumbColor = glass.brandOrange,
                            activeTrackColor = glass.brandBlue
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Line Spacing", style = MaterialTheme.typography.labelLarge)
                        Text(String.format("%.2fx", preferences.lineHeightMultiplier), color = glass.brandBlue)
                    }
                    Slider(
                        value = preferences.lineHeightMultiplier,
                        onValueChange = onLineHeightChange,
                        valueRange = 1.3f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = glass.brandOrange,
                            activeTrackColor = glass.brandBlue
                        )
                    )

                    Text("Typeface", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReaderFontStyle.entries.forEach { style ->
                            val selected = style == preferences.readerFontStyle
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlueSoft else MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, if (selected) glass.brandBlue else Color.Transparent, CircleShape)
                                    .clickable { onFontStyleChange(style) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = style.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) glass.brandBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Text("Navigation Mode", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PageTurnMode.entries.forEach { mode ->
                            val selected = mode == preferences.pageTurnMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) glass.brandBlue else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onPageTurnModeChange(mode) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}
