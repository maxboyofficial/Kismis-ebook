package com.example

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

object DevicePerformanceProfile {
    fun isLowRamHardware(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val isSystemLowRam = am?.isLowRamDevice == true
        val memoryClassMb = am?.memoryClass ?: 256
        val maxHeapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)
        return isSystemLowRam || memoryClassMb <= 192 || maxHeapMb <= 256L
    }
}

class KismisApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        val isLowRam = DevicePerformanceProfile.isLowRamHardware(this)
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(if (isLowRam) 0.10 else 0.18)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("kismis_cover_cache"))
                    .maxSizeBytes(if (isLowRam) 20L * 1024 * 1024 else 48L * 1024 * 1024)
                    .build()
            }
            .allowRgb565(true)
            .respectCacheHeaders(false)
            .crossfade(if (isLowRam) 0 else 150)
            .build()
    }
}
