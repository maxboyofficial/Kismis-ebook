package com.example.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.repository.BookPage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

data class TtsSegment(
    val index: Int,
    val pageIndex: Int,
    val paragraphIndex: Int,
    val text: String,
    val spokenText: String
)

data class TtsVoiceOption(
    val id: String,
    val displayName: String,
    val localeLabel: String,
    val isHighQuality: Boolean,
    val isNetwork: Boolean
)

enum class TtsVoicePreset(
    val label: String,
    val rate: Float,
    val pitch: Float
) {
    NATURAL("Natural", 1.0f, 1.0f),
    STORYTELLER("Storyteller", 0.95f, 0.94f),
    CALM_NIGHT("Calm Night", 0.88f, 0.90f),
    CRISP_FAST("Crisp Fast", 1.30f, 1.02f)
}

data class TtsUiState(
    val isReady: Boolean = false,
    val isActive: Boolean = false,
    val isPlaying: Boolean = false,
    val isPaused: Boolean = false,
    val isSelectionMode: Boolean = false,
    val currentSegmentIndex: Int = 0,
    val totalSegments: Int = 0,
    val currentSpokenText: String = "",
    val currentParagraphIndex: Int = -1,
    val currentPageIndex: Int = 0,
    val speechRate: Float = 0.98f,
    val speechPitch: Float = 0.96f,
    val activePreset: TtsVoicePreset = TtsVoicePreset.STORYTELLER,
    val selectedVoiceId: String? = null,
    val availableVoices: List<TtsVoiceOption> = emptyList(),
    val sleepTimerMinutes: Int? = null,
    val errorMessage: String? = null
)

class KismisTtsController(
    context: Context,
    private val onPageSyncRequested: (Int) -> Unit
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private var tts: TextToSpeech? = null
    private var segments: List<TtsSegment> = emptyList()
    private var activeSessionToken: String = ""
    private var highestQueuedIndex: Int = -1
    private var sleepTimerJob: Job? = null

    @Suppress("DEPRECATION")
    private var legacyFocusListener: AudioManager.OnAudioFocusChangeListener? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _state = MutableStateFlow(TtsUiState())
    val state: StateFlow<TtsUiState> = _state

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val localeResult = engine.setLanguage(Locale.getDefault())
                if (localeResult == TextToSpeech.LANG_MISSING_DATA ||
                    localeResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    engine.setLanguage(Locale.US)
                }

                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setSpeechRate(_state.value.speechRate)
                engine.setPitch(_state.value.speechPitch)

                val rankedVoices = buildRankedVoices(engine)
                // Automatically prefer the highest-quality local voice over robotic defaults
                val bestLocal = rankedVoices.firstOrNull { !it.isNetwork && it.isHighQuality }
                    ?: rankedVoices.firstOrNull()
                if (bestLocal != null) {
                    runCatching {
                        engine.voices?.firstOrNull { it.name == bestLocal.id }?.let { v ->
                            engine.voice = v
                        }
                    }
                }
                val activeVoiceId = bestLocal?.id ?: runCatching { engine.voice?.name }.getOrNull()

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        scope.launch {
                            handleUtteranceStarted(utteranceId)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        scope.launch {
                            handleUtteranceCompleted(utteranceId)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        scope.launch {
                            if (utteranceId?.startsWith(activeSessionToken) == true) {
                                _state.update {
                                    it.copy(
                                        isPlaying = false,
                                        errorMessage = "Speech playback interrupted"
                                    )
                                }
                            }
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        scope.launch {
                            if (utteranceId?.startsWith(activeSessionToken) == true) {
                                _state.update {
                                    it.copy(
                                        isPlaying = false,
                                        errorMessage = "TTS error ($errorCode)"
                                    )
                                }
                            }
                        }
                    }
                })

                _state.update {
                    it.copy(
                        isReady = true,
                        availableVoices = rankedVoices,
                        selectedVoiceId = activeVoiceId,
                        errorMessage = null
                    )
                }
            } else {
                _state.update {
                    it.copy(
                        isReady = false,
                        errorMessage = "Text-to-Speech engine unavailable on this device"
                    )
                }
            }
        }
    }

    fun playBookFromPage(pages: List<BookPage>, startPageIndex: Int) {
        if (pages.isEmpty()) return
        val builtSegments = buildSegmentsFromPages(pages)
        if (builtSegments.isEmpty()) return

        val firstSegOnPage = builtSegments.indexOfFirst { it.pageIndex >= startPageIndex }
            .takeIf { it >= 0 } ?: 0

        segments = builtSegments
        _state.update {
            it.copy(
                isActive = true,
                isSelectionMode = false,
                totalSegments = builtSegments.size,
                errorMessage = null
            )
        }
        startQueueFrom(firstSegOnPage)
    }

    fun playSelectedText(selectedText: String, pageIndex: Int) {
        val cleaned = selectedText.trim()
        if (cleaned.isEmpty()) return
        val builtSegments = splitTextIntoSegments(
            text = cleaned,
            pageIndex = pageIndex,
            startIndex = 0
        )
        if (builtSegments.isEmpty()) return

        segments = builtSegments
        _state.update {
            it.copy(
                isActive = true,
                isSelectionMode = true,
                totalSegments = builtSegments.size,
                errorMessage = null
            )
        }
        startQueueFrom(0)
    }

    fun previewSelectedVoice() {
        val engine = tts
        if (engine == null || !_state.value.isReady) return
        if (_state.value.isPlaying) return
        val sampleId = "preview_${UUID.randomUUID()}"
        engine.speak(
            "Hello, I am your Kismis reading companion. Sit back and enjoy your book.",
            TextToSpeech.QUEUE_FLUSH,
            Bundle(),
            sampleId
        )
    }

    fun togglePlayPause() {
        val current = _state.value
        if (!current.isActive) return
        if (current.isPlaying) {
            pausePlayback()
        } else {
            startQueueFrom(current.currentSegmentIndex)
        }
    }

    private fun pausePlayback() {
        activeSessionToken = ""
        tts?.stop()
        abandonAudioFocus()
        _state.update { it.copy(isPlaying = false, isPaused = true) }
    }

    fun skipNextSentence() {
        if (segments.isEmpty()) return
        val next = (_state.value.currentSegmentIndex + 1).coerceAtMost(segments.lastIndex)
        startQueueFrom(next)
    }

    fun skipPreviousSentence() {
        if (segments.isEmpty()) return
        val prev = (_state.value.currentSegmentIndex - 1).coerceAtLeast(0)
        startQueueFrom(prev)
    }

    fun skipNextParagraph() {
        if (segments.isEmpty()) return
        val currentIdx = _state.value.currentSegmentIndex.coerceIn(0, segments.lastIndex)
        val curPara = segments[currentIdx].paragraphIndex
        val curPage = segments[currentIdx].pageIndex
        val nextIdx = segments.indexOfFirst {
            it.index > currentIdx && (it.paragraphIndex != curPara || it.pageIndex != curPage)
        }.takeIf { it >= 0 } ?: segments.lastIndex
        startQueueFrom(nextIdx)
    }

    fun skipPreviousParagraph() {
        if (segments.isEmpty()) return
        val currentIdx = _state.value.currentSegmentIndex.coerceIn(0, segments.lastIndex)
        val curPara = segments[currentIdx].paragraphIndex
        val curPage = segments[currentIdx].pageIndex

        val currentParaStart = segments.indexOfFirst {
            it.pageIndex == curPage && it.paragraphIndex == curPara
        }.coerceAtLeast(0)

        val targetIdx = if (currentIdx > currentParaStart) {
            currentParaStart
        } else {
            val prevSegIdx = (currentParaStart - 1).coerceAtLeast(0)
            val prevSeg = segments[prevSegIdx]
            segments.indexOfFirst {
                it.pageIndex == prevSeg.pageIndex && it.paragraphIndex == prevSeg.paragraphIndex
            }.coerceAtLeast(0)
        }
        startQueueFrom(targetIdx)
    }

    fun stop() {
        activeSessionToken = ""
        highestQueuedIndex = -1
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        tts?.stop()
        abandonAudioFocus()
        segments = emptyList()
        _state.update {
            it.copy(
                isActive = false,
                isPlaying = false,
                isPaused = false,
                currentSegmentIndex = 0,
                totalSegments = 0,
                currentSpokenText = "",
                currentParagraphIndex = -1,
                sleepTimerMinutes = null
            )
        }
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.6f, 2.2f)
        tts?.setSpeechRate(clamped)
        _state.update { it.copy(speechRate = clamped) }
        if (_state.value.isPlaying) {
            startQueueFrom(_state.value.currentSegmentIndex)
        }
    }

    fun setSpeechPitch(pitch: Float) {
        val clamped = pitch.coerceIn(0.70f, 1.40f)
        tts?.setPitch(clamped)
        _state.update { it.copy(speechPitch = clamped) }
        if (_state.value.isPlaying) {
            startQueueFrom(_state.value.currentSegmentIndex)
        }
    }

    fun applyPreset(preset: TtsVoicePreset) {
        tts?.setSpeechRate(preset.rate)
        tts?.setPitch(preset.pitch)
        _state.update {
            it.copy(
                activePreset = preset,
                speechRate = preset.rate,
                speechPitch = preset.pitch
            )
        }
        if (_state.value.isPlaying) {
            startQueueFrom(_state.value.currentSegmentIndex)
        }
    }

    fun selectVoice(voiceId: String) {
        val engine = tts ?: return
        val targetVoice = runCatching { engine.voices?.firstOrNull { it.name == voiceId } }.getOrNull()
        if (targetVoice != null) {
            engine.voice = targetVoice
            _state.update { it.copy(selectedVoiceId = targetVoice.name) }
            if (_state.value.isPlaying) {
                startQueueFrom(_state.value.currentSegmentIndex)
            } else {
                previewSelectedVoice()
            }
        }
    }

    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        if (minutes == null || minutes <= 0) {
            _state.update { it.copy(sleepTimerMinutes = null) }
            return
        }
        _state.update { it.copy(sleepTimerMinutes = minutes) }
        sleepTimerJob = scope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000L)
                remaining -= 1
                _state.update { it.copy(sleepTimerMinutes = if (remaining > 0) remaining else null) }
            }
            if (_state.value.isPlaying) {
                pausePlayback()
            }
        }
    }

    /**
     * Queues the target sentence immediately (QUEUE_FLUSH) plus up to 2 lookahead
     * sentences (QUEUE_ADD) so playback transitions seamlessly without inter-sentence stutter.
     */
    private fun startQueueFrom(startIndex: Int) {
        val engine = tts
        if (engine == null || !_state.value.isReady) {
            _state.update { it.copy(errorMessage = "TTS engine is still initializing or unavailable") }
            return
        }
        if (segments.isEmpty()) return

        requestAudioFocus()
        val safeIdx = startIndex.coerceIn(0, segments.lastIndex)
        val token = UUID.randomUUID().toString()
        activeSessionToken = token

        updateActiveSegmentUi(safeIdx)

        val endIdx = (safeIdx + 2).coerceAtMost(segments.lastIndex)
        highestQueuedIndex = endIdx

        for (i in safeIdx..endIdx) {
            val seg = segments[i]
            val mode = if (i == safeIdx) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            engine.speak(seg.spokenText, mode, Bundle(), "${token}_$i")
        }
    }

    private fun handleUtteranceStarted(utteranceId: String?) {
        if (utteranceId == null || activeSessionToken.isEmpty() || !utteranceId.startsWith(activeSessionToken)) return
        val startedIdx = utteranceId.substringAfterLast("_").toIntOrNull() ?: return
        if (startedIdx in segments.indices) {
            updateActiveSegmentUi(startedIdx)
        }
    }

    private fun handleUtteranceCompleted(utteranceId: String?) {
        if (utteranceId == null || activeSessionToken.isEmpty() || !utteranceId.startsWith(activeSessionToken)) return
        if (!_state.value.isPlaying) return
        val finishedIdx = utteranceId.substringAfterLast("_").toIntOrNull() ?: return

        // Top up lookahead queue so next sentence is always pre-buffered
        val nextToQueue = highestQueuedIndex + 1
        if (nextToQueue in segments.indices) {
            highestQueuedIndex = nextToQueue
            val seg = segments[nextToQueue]
            tts?.speak(seg.spokenText, TextToSpeech.QUEUE_ADD, Bundle(), "${activeSessionToken}_$nextToQueue")
        }

        if (finishedIdx >= segments.lastIndex) {
            abandonAudioFocus()
            _state.update {
                it.copy(
                    isPlaying = false,
                    isPaused = false,
                    currentSegmentIndex = segments.lastIndex.coerceAtLeast(0)
                )
            }
        }
    }

    private fun updateActiveSegmentUi(index: Int) {
        val segment = segments.getOrNull(index) ?: return
        _state.update {
            it.copy(
                isActive = true,
                isPlaying = true,
                isPaused = false,
                currentSegmentIndex = index,
                currentSpokenText = segment.text,
                currentParagraphIndex = segment.paragraphIndex,
                currentPageIndex = segment.pageIndex,
                errorMessage = null
            )
        }
        if (!_state.value.isSelectionMode) {
            onPageSyncRequested(segment.pageIndex)
        }
    }

    private fun buildSegmentsFromPages(pages: List<BookPage>): List<TtsSegment> {
        val result = mutableListOf<TtsSegment>()
        pages.forEach { page ->
            val pageText = if (page.isChapterStart) {
                "${page.chapterTitle}.\n\n${page.text}"
            } else {
                page.text
            }
            val pageSegments = splitTextIntoSegments(
                text = pageText,
                pageIndex = page.pageIndex,
                startIndex = result.size
            )
            result.addAll(pageSegments)
        }
        return result
    }

    private fun splitTextIntoSegments(
        text: String,
        pageIndex: Int,
        startIndex: Int
    ): List<TtsSegment> {
        val list = mutableListOf<TtsSegment>()
        val paragraphs = text.split(Regex("""\n\s*\n"""))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        // Split sentences cleanly while avoiding mid-sentence breaks after common titles/abbreviations
        val sentenceRegex = Regex(
            """(?<!\b(?:Mr|Mrs|Ms|Dr|Prof|St|Sr|Jr|Lt|Capt|Col|Gen|Rev|Hon|Sgt|Maj|No|Vol|vs|etc))(?<!\b[A-Z])(?<=[.!?]["”’)]?)\s+(?=[A-Z0-9"“‘(\[])"""
        )

        paragraphs.forEachIndexed { paraIdx, paragraph ->
            val sentences = paragraph.split(sentenceRegex)
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            val items = if (sentences.isEmpty()) listOf(paragraph) else sentences
            items.forEach { rawSentence ->
                val spoken = prepareForNaturalSpeech(rawSentence)
                if (spoken.isNotBlank()) {
                    list.add(
                        TtsSegment(
                            index = startIndex + list.size,
                            pageIndex = pageIndex,
                            paragraphIndex = paraIdx,
                            text = rawSentence,
                            spokenText = spoken
                        )
                    )
                }
            }
        }
        return list
    }

    private fun prepareForNaturalSpeech(raw: String): String {
        var cleaned = raw
            // Strip Gutenberg italics underscores and decorative bracket tags
            .replace(Regex("""\[Illustration[^\]]*\]""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\*[\s\*]+\*"""), "")
            .replace(Regex("""_{2,}|-{3,}"""), "")
            .replace(Regex("""_([^_]+)_"""), "$1")
            // Convert ALL-CAPS chapter/act headers into natural spoken cadence
            .replace(Regex("""\bCHAPTER\s+([IVXLCDM]+)\b""", RegexOption.IGNORE_CASE)) { m ->
                "Chapter ${romanToDecimalOrKeep(m.groupValues[1])}."
            }
            .replace(Regex("""\bACT\s+([IVXLCDM]+)\b""", RegexOption.IGNORE_CASE)) { m ->
                "Act ${romanToDecimalOrKeep(m.groupValues[1])}."
            }
            // Give em-dashes and double-hyphens a slight breath pause
            .replace(" -- ", ", ")
            .replace("—", ", ")
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (cleaned.all { !it.isLetterOrDigit() }) return ""
        return cleaned
    }

    private fun romanToDecimalOrKeep(roman: String): String {
        val map = mapOf('I' to 1, 'V' to 5, 'X' to 10, 'L' to 50, 'C' to 100, 'D' to 500, 'M' to 1000)
        val upper = roman.uppercase(Locale.US)
        var total = 0
        var prev = 0
        for (ch in upper.reversed()) {
            val v = map[ch] ?: return roman
            if (v < prev) total -= v else total += v
            prev = v
        }
        return if (total in 1..200) total.toString() else roman
    }

    private fun buildRankedVoices(engine: TextToSpeech): List<TtsVoiceOption> {
        val defaultLang = Locale.getDefault().language
        return runCatching {
            engine.voices
                ?.asSequence()
                ?.filter { voice ->
                    val notInstalled = voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                    val langMatch = voice.locale.language == defaultLang || voice.locale.language == "en"
                    !notInstalled && langMatch
                }
                ?.sortedWith(
                    compareBy<Voice>(
                        { it.locale.language != defaultLang },
                        { it.isNetworkConnectionRequired }, // prefer reliable low-latency offline HD voices first
                        { -it.quality },
                        { it.latency },
                        { it.name }
                    )
                )
                ?.take(16)
                ?.map { voice ->
                    val highQ = voice.quality >= Voice.QUALITY_HIGH ||
                        voice.name.contains("neural", ignoreCase = true) ||
                        voice.name.contains("studio", ignoreCase = true) ||
                        voice.name.contains("wavenet", ignoreCase = true)
                    TtsVoiceOption(
                        id = voice.name,
                        displayName = formatVoiceLabel(voice, highQ),
                        localeLabel = voice.locale.displayName,
                        isHighQuality = highQ,
                        isNetwork = voice.isNetworkConnectionRequired
                    )
                }
                ?.toList()
                ?: emptyList()
        }.getOrDefault(emptyList())
    }

    private fun formatVoiceLabel(voice: Voice, isHighQuality: Boolean): String {
        val lang = voice.locale.displayLanguage.ifBlank { voice.locale.language }
        val country = voice.locale.country
        val shortCode = voice.name
            .substringAfterLast("-")
            .substringBefore("#")
            .uppercase(Locale.US)
            .take(6)
        val qualityBadge = when {
            voice.name.contains("studio", ignoreCase = true) -> "Studio"
            voice.name.contains("neural", ignoreCase = true) -> "Neural"
            isHighQuality -> "HD"
            else -> shortCode
        }
        val localePart = if (country.isNotBlank()) "$lang ($country)" else lang
        return "$localePart • $qualityBadge"
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val listener = AudioManager.OnAudioFocusChangeListener { focusChange ->
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS ||
                focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
            ) {
                scope.launch {
                    if (_state.value.isPlaying) pausePlayback()
                }
            }
        }
        legacyFocusListener = listener
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener(listener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(listener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            legacyFocusListener?.let { am.abandonAudioFocus(it) }
        }
        legacyFocusListener = null
    }

    fun release() {
        sleepTimerJob?.cancel()
        scope.cancel()
        tts?.stop()
        tts?.shutdown()
        tts = null
        abandonAudioFocus()
    }
}
